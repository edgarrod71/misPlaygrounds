import UIKit
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true // para manejo de funciones y closures en Queues Asincrónicos

var str = "Hello, playground"

let separador = { // este closure actúa como método si se agrega ()
    print("--------------------------------------")
}

//////////////////////////////////////////////////////////////////////
// SECCIÓN DE 1 PARÁMETRO de closure EN LA FUNCIÓN sin retorno VOID //
//////////////////////////////////////////////////////////////////////

func viaje(acción: (_ marca: String) -> Void) { // función que recibe un parámetro () -> ()
    print("me monto al carro")
    acción("ferrari")
    print("voy a trabajar")
}

let manejando = { (marca: String) in // closure básico asignado a la variable manejando
    print("voy a la ciudad en un \(marca)")
}

manejando("lambo")  // closure en acción
separador()

// VARIANTES SOBRE CLOSURES

// 1) Como se espera...
viaje(acción: manejando) // A. aquí toma como parámetro << manejando >>
separador()

// 2) A pie pelado
viaje(acción: { (marca) in // sin el parámetro, pero con el identificador "unresolved"
    print("B. Cómo me llaman eso no importa \(marca)")
}); separador()

// 3) Sin parámetros y seguido de la función (trailing)
viaje() { (marca) in  // aquí se puede definir sin etiqueta ni variable
    print("C. ahí está el placer \(marca)")
}; separador()

// 4) e incluso sin paréntesis (trailing)
viaje { (marca) in
    print("D. yo te vengo a  voy a buscar \(marca)")
}; separador()


// OJO que aquí se define la función prepararComida donde toma el segundo parámetro como un closure.
func prepararComida(plato: String, pasos cocinar: (String) -> Void) {
    print("1. comprar los ingredientes")
    cocinar(plato)
    print("4. servir y disfrutar"); separador()
}

// ejecutamos prepararComida(plato: "FRENCH FRIES") { (plato: String) in // se puede quitar la descripción de tipo String
prepararComida(plato: "FRENCH FRIES") { plato in // curioso, tanto como en el primer parámetro como en el segundo, la variable debe ser la misma, si la cambias, da error...
    print("2. lavar y pelar")
    print(plato)
    print("3.poner a fuego lento")
}

let tamales = { (plato: String) in
    print("2. buscar y arreglar las hojas")
    print(plato)
    print("3. montar la olla de tamales")
}

// ejecutamos un plato súper colombiano
prepararComida(plato: "TAMALES SANTANDEREANOS", pasos: tamales)


let velocidadesMax = { (velocidad: Int) in
    print("el cambio de velocidades está en \(velocidad)")
}

func construyeCarro(marca: String, cambios: Int, velocidades: (Int) -> Void) {
    print("a construir \(marca)")
    velocidades(cambios)
}

construyeCarro(marca: "pichirilo", cambios: 6, velocidades: velocidadesMax)
separador()


func hacerPizza(agregaIngredientes: (Int) -> Void) {
    print("La masa está lista.\nLa base está óptima")
    agregaIngredientes(3)
}

hacerPizza { (cIngredientes: Int) in
    let ingredientes = ["jamón", "salami", "cebollas", "piña"]
    for i in 0..<cIngredientes {
        let ingre = ingredientes[i]
        print("le añado \(ingre)")
    }
}
separador()


func arreglar(item: String, cuentaPP: (Int) -> Void) {
    print("He arreglado su \(item)")
    cuentaPP(4_500_000)
}
arreglar(item: "techo") { (factura: Int) in
    print("Me está pidiendo $\(factura) por eso? Exagerado!")
}
separador()

func estudioHistoria(revisaNotas: (String) -> Void) {
    let notas = "Napoleón era un tipo bajo, y muerto."
    for N in 1820...1822 {
        revisaNotas("\(notas) en \(N)")
    }
}
estudioHistoria { (notes: String) in
    print("leyendo mis notas: \(notes)")
}
separador()

func pedirDirecciones(hasta destino: String, luego siga: ([String]) -> Void) {
    let direcciones = [
        "Siga adelante",
        "Gire a la izquierda en la calle 10",
        "Gire a la derecha hasta la Avenida principal",
        "Ha llegado al destino \(destino)" ]
    siga(direcciones)
}
pedirDirecciones(hasta: "El Cristo Petrolero") { (direcciones: [String]) in
    print("Sube al carro y...")
    for dirección in direcciones {
        print(dirección)
    }
}
separador()



//////////////////////////////////////////////////////////////////////
//  SECCIÓN DE 1 PARÁMETRO tipo closure EN LA FUNCIÓN con RETORNO   //
//////////////////////////////////////////////////////////////////////

func pasea(lugar: (String) -> String) {
    print("voy DE PASEO...")
    let voyDestino = lugar("Medellín")
    print("estoy en el carro y \(voyDestino) \n LLEGUÉ!")
}
// pasea { (sitio: String) -> String in
pasea { sitio in   // aquí también podemos obviar los tipos String
    "estoy dirigiéndome a \(sitio)"  // podemos "abolir" return
}; separador()

pasea { "voy en moto a \($0)" }  // podemos quitar la variable sitio

//////////////////////////////////////////////////////////////////////
// Sección func REDUCE con retorno, PARÁMETRO closure CON retorno //
//////////////////////////////////////////////////////////////////////

func reduce(arrInt: [Int], usando closure: (Int, Int) -> Int) -> Int {
    let cElem = arrInt.count // primero, cuántos Elementos tiene arrInt
    var total = cElem != 0 ? arrInt[0] : 0 // hay elementos en arreglo?, tomamos el total del primer elemento; si no, que devuelva cero
    if cElem > 1 {
        // recorramos los demás elementos a partir del segundo elemento elem[1] //for V in elementos[1...] { // Swift 3 no acepta esto
        for val in arrInt[1...cElem-1] {
            total = closure(total, val)
        }
    }
    return total
}

let numerillos: [Int] = [10, 20, 30, 40]

var suma = reduce(arrInt: numerillos, usando: { (totalEje, siguiente) in
    totalEje + siguiente
})

suma = reduce(arrInt: numerillos) { $0 + $1 }

suma = reduce(arrInt: numerillos, usando: +)  // wow suma
suma = reduce(arrInt: numerillos, usando: *)  // wow factores

separador()

func manipular(numeros: [Int], usando algoritmo: (Int) -> Int) {
    for numero in numeros {
        let result = algoritmo(numero)
        print("Manipulando \(numero) produce \(result)")
    }
}
// manipular(numeros: [1, 2, 3]) { (number: Int) -> Int in
manipular(numeros: [1, 2, 3]) { number in  // obviado los Int
    number * number  // y el return
}; separador()

manipular(numeros: [1, 2, 3]) { $0 * $0 }; separador()

manipular(numeros: [1, 2, 3], usando: { $0 }); separador() // REVISA ESTO


/////////////////////////////////////////////////////////////////////////
// Sección func con o sin parámetros RETORNA closure Void, String, Int //
/////////////////////////////////////////////////////////////////////////

func retorneNumAleatorio() -> () -> Int {
    let función = { Int(arc4random_uniform(10)) + 1 } // en un closure podemos obviar "return"
    return función
}
retorneNumAleatorio()() // ojo, es función de función, permisible pero no recomendable

let generador = retorneNumAleatorio()
let aleatorio1 = generador()

func dameAleatorio(entre: Int) -> (UInt32) -> Int {
    return { Int(arc4random_uniform($0)) + entre }
}  // Fernando, taz una cuchilla!
dameAleatorio(entre: 100)(200)




// func viajandoA() -> (String) -> Void {
func viajandoA() -> (String) -> Bool {
    return {
        print("me dirijo a \($0)")
        return true
    }
}

let destinoA = viajandoA()
destinoA("Moscú")

let destinoB = viajandoA()("California") // se puede, pero el compilador chilla cuando es Void
destinoB
separador()

// este es un ejemplo más claro.  Como no retorna nada, se usa print y se implementa la captura de valores mediante C
func formaViajar(kms: Int) -> (String, Character) -> Void {
    var C = 1 // para que se almacene C, debe estar fuera del closure
    if kms < 5 {
        return { // aquí $1 retorna el segundo parámetro $1 y no se maneja como tupla (por qué?)
            print("\(C). Si toma sólo \(kms), voy a pie clase \($1).")
            C += 1 // al incrementar dentro del closure, C se vuelve static
        }
    } else if kms < 20 {
        return {
            print("\(C). Son \(kms), voy en cicla a \($0), clase \($1).")
            C += 1
        }
    } else {
        return { // atento, aquí se maneja como una tupla de dos datos pues son distintos tipos (String, Character) y sólo se usa $0
            print("\(C). \(kms)? Está lejos, manejaré hasta \($0).")
            C += 1
        }
    }
}

let métodoViaje = formaViajar(kms: 19)
métodoViaje("Medellín", "A")
métodoViaje("Cartagena", "B")
métodoViaje("Valledupar", "C")

// formaViajarStr, distancia con switch retorna un String
func formaViajarStr(distancia: Int) -> (String) -> String {
    switch distancia {
    case 0...5: return {
        "Si toma sólo \(distancia), voy a pie hasta \($0)." }
    case 6...20: return {
        "Si toma \(distancia), voy en cicla hasta \($0)." }
    default: return {
        "\(distancia)? Está retirado, mejor conduzco hasta \($0)." }
    }
}

let metodoViaje = formaViajarStr(distancia: 300)
print(metodoViaje("Bogotá"))
separador()

// mejoré la implementación que hice de números aleatorios usando captura de closures
func fullRandom(min: Int) -> (UInt32) -> Int {
    var numAnterior = min // inicia con el valor mínimo, para qué poner en 0?
    return {
        var nuevoNum: Int
        repeat {
            nuevoNum = dameAleatorio(entre: min)($0)
        } while numAnterior == nuevoNum
        numAnterior = nuevoNum // aquí actualizamos la variable (static)
        return nuevoNum
    }
}

var nums001 = [Int]()
let generadorFull = fullRandom(min: 10)
for _ in 1...20 {
    nums001.append(generadorFull(20))
} // funciona perfecto de esta forma
print(nums001)

var nums002 = [Int]()
for _ in 1...90 {
    nums002.append(fullRandom(min: 71)(123))
} // nótese que aquí no se almacena el numAnterior, pareciera que arroja la suma entre los parámetros como máximo
print(nums002)
print(nums002.filter { $0 >= (71 + 123)}) // comprobación de mi teoría
separador()



// Para entender mejor las capturas en closures traduzco parte del artículo: https://alisoftware.github.io/swift/closures/2016/07/25/closure-capture-1/
// como maneja funciones y capturas en closures dentro de Queues Asíncronos, hay que poner al principio del códiog esta línea, sin ésta, el código Queue no sirve:
//  PlaygroundPage.current.needsIndefiniteExecution = true


// En Swift, los closures capturan las variables que referencian: las variables declaradas fuera del closure pero que se usan dentro del closure las "retiene" por defecto, y así asegurar que sigan "vivas" cuando se ejecute el closure.

class Pokemon: CustomDebugStringConvertible {
    var nombre: String
    init (nombre: String) {
        self.nombre = nombre
    }
    var debugDescription: String { return "dD: Pokemon <\(self.nombre)>" }
    deinit {
        print("deinit: \(self) escapó!")
    }
}

// @escaping es un atributo que se puede aplicar a un parámetro de función. Indica que el parámetro es un closure que puede "escapar" o sobrevivir más allá del alcance de la función en la que se pasa como argumento.  Significa que puede ser mantenido "vivo" y usado fuera del alcance de la función en la que se define. Esto es útil en situaciones en las que el closure se pasa como argumento a otra función y se almacena para su uso posterior, como en casos de devolución de llamada (callbacks) asíncronos.

final class Modelo {
    func carga(completion: @escaping ([String]) -> Void ) {
        // si queremos que el código de esta función siga vivo, usa @escaping
    }
}

final class ViewController: UIViewController {
    var modelo: Modelo! = Modelo()

    private func display (items: [String]) {
        // código
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        modelo.carga(completion: { [unowned self] (items) in
            self.display(items: items)
        })
    }
}


// Declaramos una función que toma un closure como parámetro, para que se ejecute algunos segundos después (usando GCD). Así la usaremos para mostrar cómo este closure captura las variables definidas afuera.

func delay(_ segundos: Int, closure: @escaping () -> () ) {
    let timeNow = DispatchTime.now() + .seconds(segundos)
    DispatchQueue.main.asyncAfter(deadline: timeNow, execute: {
        print("\(segundos) seg. 🕑🕒🕓🕔🕕")
        closure()
    })
}

func demo001() {
    let poke0 = Pokemon(nombre: "MewTwo")
    print("Antes del Closure: \(poke0)")
    delay(1) {
        print("Dentro del closure \(poke0)") // poke0 es la referencia dentro de este closure, está definido afuera de este closure, así que poke0 seguirá vivo mientras este closure viva.
    }
    print("Fuera del Closure: \(poke0)")
}
demo001()
// Es interesante notar que el closure se ejecuta 1 segundo después de que el código de la función termina… esto porque el Pokemon MewTwo sigue vivo 1 segundo más, prueba de esto se ve en la ejecución del destructor deinit.

separador()

func lanzaPQBola() {
    var poke1 = Pokemon(nombre: "Pikachú")  // poke1 toma la instancia de clase Pokemon con el nombre Pikachú
    print("antes del closure: \(poke1)") // al imprimir, de poke1 se imprime debugDescription pues usa el protocolo CustomDebugStringConvertible
    delay(3) {  // cuando se ejecuta delay, todavía conserva en el tiempo
        print("dentro del closure \(poke1)") // la instancia gracias
    }  // a la captura dentro del closure.
    poke1 = Pokemon(nombre: "Petrochú") // al asignar una nueva instancia, se activa el deinit de la clase que contiene "Pikachú"
    print("\(poke1) final de la función, chau, chau")
}
lanzaPQBola()

func demo003() {
    var valor: Int = 12
    print("ANTES DEL CLOSURE: \(valor)")
    delay(2) {
        print("ADENTRO DEL CLOSURE \(valor)")
    }
    valor = 45231
    print("\(valor) SALIENDO DE DEMO003")
}
demo003()

separador()

/////// CAPTURANDO LA VARIABLE COMO UNA COPIA DE CONSTANTE ///////

// Si quiere capturar el valor de una variable en el momento de creación del closure, en vez de tener que evaluar sólo cuando se ejecute el closure, puede usar una lista de captura.  Las listas de captura se escriben entre corchetes justo después de la apertura del closure (y antes de los argumentos / tipo retorno del closure si existe alguno).  En vez de una referencia a la variable misma, puede usarse la lista de captura [varLocal = var_Capturar] a continuación se muestra cómo:

func demo005() {
    var valor = 1971
    print("5️⃣ Antes del closure: \(valor)")
    delay(5) { [valorConst = valor] in
        print("5️⃣ Dentro del closure: \(valorConst)")
    }
    valor = 91439275
    print("5️⃣ Después del closure: \(valor)")
}
demo005()
separador()

func demo006() {
    var singer = Pokemon(nombre: "Axel Rose")
    print("🔫🌹 Antes del closure: \(singer)")
    delay(6) { [cantante = singer] in
        print("🔫🌹 I don't need your civil war. \(cantante)")
    }
    singer = Pokemon(nombre: "Bon Jovi")
    print("🔫🌹 It's my Life!: \(singer)")
}
demo006()
separador()

func demo007() {
    var pokecito = Pokemon(nombre: "Mew")
    print("➡️ Pokemon inicial \(pokecito)\n")

    delay(7) { [pokeCapturado = pokecito] in
        print("closure 🅰️, capturado en momento de creación: \(pokeCapturado)")
        print("closure 🅰️, var evaluada en momento de ejecución: \(pokecito)")
        pokecito = Pokemon(nombre: "Pikachú")
        print("closure 🅰️, ahora pokecito es: \(pokecito)")
    }

    pokecito = Pokemon(nombre: "MewTwo")
    print("🔁 reciclando pokecito ahora es \(pokecito)")

    delay(7) { [pokeCapturao = pokecito] in
        print("closure 🅱️, capturado en momento de creación: \(pokeCapturao)")
        print("closure 🅱️, var evaluada en momento de ejecución: \(pokecito)")
        pokecito = Pokemon(nombre: "Charizard")
        print("closure 🅱️, ahora pokecito es: \(pokecito)")
    }
}
demo007()

// Si no he entendido lo anterior, puedo hacerlo más simple: 

var i = 2
var closure01 = { (str: String) in var C = "🍰"; for _ in 1..<i { C += "🍰" }
    print("\(str) 🍰x\(i): \(C)") }
i = 25
closure01("hola desde closure 1")

// esto imprime 5 y no 2, es porque Swift por defecto captura referencias y no valores.  Para cambiar este comportamiento y capturar el valor, se usa una lista de captura así:

i = 5 /// Capturará sólo 5
var closure02 = { [i] (str: String) in var C = "🎂"; for _ in 1..<i { C += "🎂" }
    print("\(str) 🎂x\(i): \(C)") }
i = 33 // no captura 33 pues [i] lo toma por valor y no por referencia
closure02("saludos desde closure 2")

// El uso de [i] permite capturar el valor de i en el momento que se crea el closure en vez de esperar a una ejecución posterior, por eso capturó i = 5 y no i = 33.  Puedo agregar parámetros en captura así como en referencia.

// Un ejemplo más usando una clase básica.

class Ermitaño {
    var asesino: String = "El Doctor lo hizo? 🚑"
}

var quien = Ermitaño() // Asignación original
var closureQuien = { [quien] in print(quien.asesino)}
quien = Ermitaño() // Asignación actual
quien.asesino = "El Chef es el asesino serial 🍳"
closureQuien()

// Si omites la lista de captura [quien], el ejemplo imprimirá "El Chef es el asesino serial 🍳" pues no tendrá forma de capturar el valor.


// Cuando se trabaja con clases, una lista de captura puede añadir modificadores para capturar elementos, especialmente weak. unowned, unowned(safe) y unowned(unsafe).  Usará este modificador cuando queira capturar 'self' sin ciclos de referencia.  El siguiente ejemplo, la lista de captura permite cpaturar la referencia de 'self' como un unowned (en vez de strong), evitando así ciclos de referencia.

class Paginita {
    var text: String? = ""
    var nombre: String = ""
    lazy var comoHTML: () -> String = { [unowned self] in
        if let contenido = self.text {
            return "<\(self.nombre)>\(contenido)"
        } else {
            return "<\(self.nombre) />"
        }
    }
}
// TODO: Implementar el uso


/////-------------------------------------

// MARK:  AUTOCLOSURE

// Un autoclosure es un closure que se crea automáticamente para envolver una expresión que se pasa como argumento a una función. No requiere ningún argumento y, cuando se llama, devuelve el valor de la expresión que contiene. Esta conveniencia sintáctica le permite omitir llaves alrededor del parámetro de una función escribiendo una expresión normal en lugar de un cierre explícito.

// Atención: El uso excesivo de cierres automáticos puede hacer que su código sea difícil de entender. El contexto y el nombre de la función deben dejar claro que se está aplazando la evaluación.

func hazOperacion(_ operacion: @autoclosure () -> Void) {
    print("Antes de la operación autoclosure")
    operacion()
    print("Después de la operación autoclosure")
}

hazOperacion( print("Haciendo la operación autoclosure") )



let dispatchQ = DispatchQueue.main
var finalT = DispatchTime.now() + .seconds(8)
dispatchQ.asyncAfter(deadline: finalT) {
    print("hola! después de 10 segundos")
}

// dispatchQ.async

extension DispatchQueue { // Cheverísimo hack!
    func asyncLuego(deadline: DispatchTime, _ execute: @escaping @autoclosure () -> Void) {
        asyncAfter(deadline: deadline, execute: execute)
    }
}

finalT = DispatchTime.now() + DispatchTimeInterval.seconds(7)
dispatchQ.asyncLuego(deadline: finalT, print("Ajúa! Fercho primero!") )






