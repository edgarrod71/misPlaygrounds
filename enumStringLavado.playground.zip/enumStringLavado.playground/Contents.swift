//: Playground - noun: a place where people can play
import UIKit


public struct OpcionesLavado: OptionSet, CustomStringConvertible {

    private let _rawValue: Int // no asignable públicamente

    public var rawValue: Int { return _rawValue }

    public init(rawValue: Int) { self._rawValue = rawValue }

    /// Enumeración basado en etiquetas tipo string
    private enum EtiquetaLavado: String {
        case aguaBajo, caliente, cicloSuave, centrifugado

        // Returna un diccionario [hash: rawValue]
        static var memberDict: Dictionary<Int, String> = [aguaBajo, caliente, cicloSuave, centrifugado].reduce([:]) {
            var dict = $0;
            dict[$1.hashValue] = "\($1)";
            return dict
        }
    }

    // Simple flags are built from built-shifted enumeration hash values
    public static let lowWater = OpcionesLavado(rawValue: 1 << EtiquetaLavado.aguaBajo.hashValue)
    public static let lowHeat = OpcionesLavado(rawValue: 1 << EtiquetaLavado.caliente.hashValue)
    public static let gentleCycle = OpcionesLavado(rawValue: 1 << EtiquetaLavado.cicloSuave.hashValue)
    public static let tumbleDry = OpcionesLavado(rawValue: 1 << EtiquetaLavado.centrifugado.hashValue)

    // Compound sets cannot be initialized with strings
    // as their math cannot be established from positions
    public static let energyStar: OpcionesLavado = [.lowWater, .lowHeat]
    public static let gentleStar: OpcionesLavado = energyStar.union(gentleCycle)

    // String based initialization
    public init(strings: [String]) {
        let set: OpcionesLavado = strings
            .flatMap({ EtiquetaLavado(rawValue: $0) }) // to enumeration
            .map({ 1 << $0.hashValue }) // to Int, to flag
            .flatMap({ OpcionesLavado(rawValue: $0) }) // to option set
            .reduce([]) { $0.union($1) } // joined
        _rawValue = set.rawValue
    }

    /// returns set members as strings
    public var description: String {
        let members = EtiquetaLavado.memberDict.reduce([]) {
            return (rawValue & 1 << $1.key) != 0
                ? $0 + [$1.value] : $0
        }
        return members.joined(separator: ", ")
    }
}

let array = ["cicloSuave", "centrifugado"]
let optionSet = OpcionesLavado(strings: array) // gentleCycle, tumbleDry


struct ShippingOptions: OptionSet {
    let rawValue: Int

    static let nextDay    = ShippingOptions(rawValue: 1 << 0)
    static let secondDay  = ShippingOptions(rawValue: 1 << 1)
    static let priority   = ShippingOptions(rawValue: 1 << 2)
    static let standard   = ShippingOptions(rawValue: 1 << 3)

    static let express: ShippingOptions = [.nextDay, .secondDay]
    static let all: ShippingOptions = [.express, .priority, .standard]
}

// Crear una instancia de ShippingOptions utilizando las opciones disponibles
let selectedOptions: ShippingOptions = [.nextDay, .priority]

// Verificar si una opción específica está seleccionada
if selectedOptions.contains(.nextDay) {
    print("Next day shipping is selected")
}

// Verificar si todas las opciones están seleccionadas
if selectedOptions == .all {
    print("All shipping options are selected")
}

// Comprobar las opciones seleccionadas utilizando un switch
switch selectedOptions {
case [.nextDay]:
    print("Next day shipping is selected")
case [.priority]:
    print("Priority shipping is selected")
case [.all]:
    print("All shipping options are selected")
case [.nextDay, .priority]:
    print("ajúa")
default:
    print("Other combination of shipping options is selected")
}
