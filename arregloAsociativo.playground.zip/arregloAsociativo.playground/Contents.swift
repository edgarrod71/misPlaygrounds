//: Playground - noun: a place where people can play
import UIKit
import PlaygroundSupport

enum Enum {
    case foo(Int)
    case bar(String)
    case snog(Int)
}

let items: [Enum] = [.foo(1), .bar("hi"), .foo(2), .bar("Fer"), .snog(10), .foo(3)]

let filtered = items.filter({ // podemos filtrarlos mediante un switch en vez de if anidado
    switch $0 {
    case .foo: return true
    default: return false
    }
})

filtered

func midamosDuracion(codigo: () -> Void) -> TimeInterval {
    let inicio = Date()
    codigo()
    let fin = Date()
    return fin.timeIntervalSince(inicio)
}

let numes = [Int](0...19999)
numes.count

let numesPrimos1 = numes.filter { num in
    if (0...1) ~= num { return false }
    let mitad = num >> 1
    for i in 2..<mitad + 1 {
        if num % i == 0 {
            return false
        }
    }
    return true
}

let numesPrimosOld = numes.filter { num in
    if (0...1) ~= num { return false }
    for i in 2..<num {
        if num % i == 0 {
            return false
        }
    }
    return true
}

var dura = midamosDuracion {
    let primos = numesPrimosOld
}

dura = midamosDuracion {
    let primos = numesPrimos1
}




///let raiz = Int(sqrt(Double(numes.count)))

/// esta estructura es interesante pero inútil
//let numesPrimosFast = numes.filter { num in
//    if (0...1) ~= num { return false }
//    if (2..<raiz) ~= num {
//        for i in 2..<num {
//            if num % i == 0 {
//                return false
//            }
//        }
//    } else {
//        for i in 2..<raiz {
//            if num % i == 0 {
//                return false
//            }
//        }
//    }
//    return true
//}



/// COOL BUT SLOW
//let numesFiltra = numes.filter { num in
//    func divi(_ n: Int) -> Bool {
//        for (_, i) in (2..<num).enumerated() {
//            if num % i == 0 {
//                return false
//            }
//        }
//        return true
//    }
//    return (0...1) ~= num ? false : divi(num)
//}

let filtered2 = items.filter({
    for case .bar in [$0] {
        return true
    }
    return false
})
filtered2

extension Enum {
    var isFoo: Bool {
        switch self {
        case .foo: return true;
        default: return false
        }
    }
}

let filtered3 = items.filter({ $0.isFoo })
filtered3

extension Enum {
    static func ~= (lhs: Enum, rhs: Enum) -> Bool {
        let lhsCase = Array(Mirror(reflecting: lhs).children)
        let rhsCase = Array(Mirror(reflecting: rhs).children)
        return lhsCase[0].0 == rhsCase[0].0
    }
}


let filtered4 = items.filter({ $0 ~= .foo(0) })
print(filtered4)

extension Enum {
    var caseName: String {
        return "\(Array(Mirror(reflecting: self).children)[0].0!)"
    }
}


/// Lo siguiente es una implementación de una estructura ArregloAsociativo, que permite asociar dos elementos de tipo ElemPar de manera bidireccional. La estructura utiliza un DispatchQueue para garantizar la seguridad en entornos de subprocesos y proporciona un subscript personalizado para permitir el acceso a los elementos asociados.

/// Una "colección" de elementos asociables
public struct ArregloAsociativo<ElemPar: Hashable>: CustomStringConvertible, ExpressibleByDictionaryLiteral {

    public init() {} /// Módulo construíble desde afuera

    public typealias DictEmparejado = [ElemPar: ElemPar]//Dictionary<ElemPar, ElemPar>

    /// El diccionario de asociación bidireccional de vuelta
    private var backingDict: DictEmparejado = [:]

    /// La versión que se actualiza sincrónicamente así que no hay desgaste para el usuario al trabajar en sus formas.
    private var userFacingDict: DictEmparejado = [:]

    /// Da soporte de seguridad en hilos (pake no se bloquee)
    private var colaAcceso = DispatchQueue(label: "org.sadun.2WayArray", attributes: [.concurrent])

    /// Permite acceso emparejado
    public subscript(elemA: ElemPar) -> ElemPar? {
        get {
            return colaAcceso.sync {
                return backingDict[elemA]
            }
        }

        set(newItemB) {
            return colaAcceso.sync(flags: [.barrier]) {

                // Nada de op para el mismo valor
                let itemB = backingDict[elemA] // buscamos si existe elemA
                guard itemB != newItemB else { return } // y si existe, regrese

                switch (itemB, newItemB) {
                case (let item2?, let newItem2?): // variables temporales????

                    // Desinfecta newItem2 si está emparejado
                    let nuevoElem1 = backingDict[newItem2] // sostenemos newItem2
                    backingDict.removeValue(forKey: newItem2)    // borramos
                    userFacingDict.removeValue(forKey: newItem2) // borramos
                    if nuevoElem1 != nil { // si todavía existen rastros
                        let newItem1: ElemPar! = nuevoElem1
                        backingDict.removeValue(forKey: newItem1)
                        userFacingDict.removeValue(forKey: newItem1)
                    }

                    // Desinfectamos item2
                    backingDict.removeValue(forKey: item2)
                    userFacingDict.removeValue(forKey: item2)

                    // Introduce un nuevo par
                    backingDict[newItem2] = elemA
                    backingDict[elemA] = newItem2
                    userFacingDict[elemA] = newItem2

                case (let item2?, nil): // remueve key y value pues value ≠ nil
                    backingDict.removeValue(forKey: elemA)
                    backingDict.removeValue(forKey: item2)
                    userFacingDict.removeValue(forKey: elemA)
                    userFacingDict.removeValue(forKey: item2)

                case (_, let newItem2?):
                    backingDict[newItem2] = elemA
                    backingDict[elemA] = newItem2
                    userFacingDict[elemA] = newItem2

                case (_, _):
                    fallthrough

                default:
                    assertionFailure("Should never get here")
                }
            }
        }
    }

    // Soporte literal en conformancia con los diccionarios
    public typealias Key = ElemPar
    public typealias Value = ElemPar

    /// OBLIGATORIO por ExpressibleByDictionaryLiteral.  Permite la inicialización literal de cualquier diccionario
    public init(dictionaryLiteral elements: (ElemPar, ElemPar)...) {
        self.init()
        for (item1, item2) in elements {
            self[item1] = item2
        }
    }

    /// Retorna una versión reducida sin duplicados
    public var diccionarioRepresentado: [ElemPar: ElemPar] {
        return userFacingDict
    }

    /// Provee descripción al usuario
    public var description: String { // DEBE estar según CustomStringConvertible
        return "\(diccionarioRepresentado)"
    }
}

/// Para uso público en el caso de uso más común
public typealias PairedStrings = ArregloAsociativo<String>


// Creamos una instancia de PairedStrings (AssociativeArray<String>)
var pairedStrings = PairedStrings(dictionaryLiteral: /*("uva", "purpura"),*/ ("guanabana", "blanca"))

// Asociar elementos de tipo String de manera bidireccional
pairedStrings["manzana"] = "verde"
pairedStrings["banano"] = "amarillo"
pairedStrings["cereza"] = "roja"
pairedStrings["cereza"] = "roja"
pairedStrings["cereza"] = "roja"
pairedStrings["cereza"] = "roja"

// Acceder a los elementos asociados
print(pairedStrings["manzana"]!)  // Imprimirá "verde"
print(pairedStrings["amarillo"]!)    // Imprimirá "banano"
print(pairedStrings["roja"]!) // Imprimirá "cereza"
//print(pairedStrings["uva"]!) // Imprimirá "banana"

// Imprimir la representación del diccionario
print(pairedStrings.diccionarioRepresentado)


