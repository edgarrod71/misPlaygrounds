import UIKit

/// Operador de exponenciación
infix operator ^^

extension IntegerArithmetic {
    static func ^^(base: Self, expo: Int) -> Self {
        let repite = repeatElement(base, count: expo)
        for i in repite {
            print("\(i)")
        }
        repite[0]
        return repeatElement(base, count: expo).reduce(1 as! Self, *)
    }
}

let a = 412 ^^ 5
