import PlaygroundSupport
import UIKit
import Foundation
import CoreGraphics

var Str:String!
var DD:Double!
var II:Int?
var BB:Bool?
var optionalName: String?
var vegetalStr:String! = "hey"

var cad = "Sólo me faltabas tú para ser feliz"

enum Errorcito: Error {
    case rangoInvalido(String)
    case sinRaiz(String)
}


Str = Locale.current.decimalSeparator! // ,

let NNN = 4444.55555

NNN.description

var textField1: String? = "0,03"

// Crear un NumberFormatter con estilo decimal y configurarlo para usar coma como separador decimal
let numF = NumberFormatter()
numF.locale = Locale(identifier: "es_ES")
numF.numberStyle = .decimal
numF.decimalSeparator = ","
numF.groupingSeparator = "."
numF.generatesDecimalNumbers = true

// Obtener el texto actual del textField y convertirlo a un valor Double
if let text = textField1, var number = numF.number(from: text)?.doubleValue {
    // Hacer los cálculos aquí, usando el valor number como Double
    number = number * 3.14
    // Convertir el resultado de vuelta a un String con el formato inicial
    let result = numF.string(from: NSNumber(value: number))
    
    // Asignar el resultado al textField
    textField1 = result
}

func numToStr(num: NSNumber, decSep: String? = nil) -> String? {
    let F = NumberFormatter()
    let S = decSep ?? Locale.current.decimalSeparator ?? "."
    F.decimalSeparator = S
    F.numberStyle = .decimal
    let result = F.string(from: num)
    return result
}

let numString = numToStr(num: 5.5, decSep: ",")

if let d = Decimal(string: "8.8", locale: .current) {
    d
    print(d)
    type(of: d)
}

if let d = Decimal(string: "8,8", locale: Locale(identifier: "es_ES_POSIX")) {
    d
    print(d)
}

func StrToDouble(str: String, decSep: String? = nil) -> Double? {
    let S = decSep ?? Locale.current.decimalSeparator ?? "."
    
    let F = NumberFormatter()
    F.decimalSeparator = S
    F.generatesDecimalNumbers = true
    F.numberStyle = .decimal
    
    switch S {
    case ".":
        return F.number(from: str.replacingOccurrences(of: ",", with: "."))?.doubleValue
    case ",":
        return F.number(from: str.replacingOccurrences(of: ".", with: ","))?.doubleValue
    default:
        return nil
    }
}

let doble11 = StrToDouble(str: "5,5", decSep: nil)
let doble12 = StrToDouble(str: "5.5", decSep: ",")

let comma: String = ","
let chComma: Character? = comma[comma.startIndex] // comma.characters.first!
var edit1: String! = "0,,"
var label1: String! = ""

var S = edit1!
let cCommas = S.components(separatedBy: comma).count > 2

switch edit1!.characters.count {
case 0:
//    S = "0"
    edit1 = "0"
case 1:
    if edit1 == comma {
//        S = "0"
        edit1 = "0"
    }
case 2:
    if (S.characters.first == "0") && (S.characters.last != chComma) {
        edit1!.characters.remove(at: S.startIndex)
    }
    fallthrough
default:
    // if edit1!.characters.filter({ $0 == chComma }).count > 1 {
    if edit1!.components(separatedBy: comma).count > 2 {
        edit1!.characters.removeLast()
    }
    //S = edit1!
}

label1 = edit1!











