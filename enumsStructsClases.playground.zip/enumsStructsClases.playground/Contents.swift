// import PlaygroundSupport
import UIKit
import Foundation
import CoreGraphics

var str:String!
var dd:Double!
var ii:Int?
var bb:Bool?
var optionalName: String?


enum dias_sem {
    case Lunes, Martes, Miercoles, Jueves, Viernes

}

var dia = dias_sem.Miercoles;
dia = .Viernes
var dia_fest: dias_sem = .Lunes
dia

//enum EmailValError: CaseIterable { // desde la versión 4.2
//    case empty
//    case inválido, sinDominio
//}

extension Double {
    var km: Double { return self * 1_000.0 }
    var m: Double { return self }
    var cm: Double { return self / 100.0 }
    var mm: Double { return self / 1_000.0 }
    var ft: Double { return self / 3.28084 }
}
let unaPulgada = 25.4.mm
let unaPStr = String(format: "%.5f", unaPulgada)
"Una pulgada es \(unaPStr) metros"

let tresPies = 3.ft
"Tres pies son \(String(format: "%.8f", tresPies)) metros"

let maraton = 42.km + 195.m
"Una maratón mide \(String(format: "%.2f", maraton.mm)) kilómetros"



struct Punto {
    var x = 0.0, y = 0.0
}

struct Size {
    var ancho = 0.0, alto = 0.0
}

struct Rect {
    var origen = Punto()
    var tamaño = Size()
}

let rectUnico = Rect(origen: Punto(x: 4, y: 5), tamaño: Size(ancho: 20.m, alto: 40.km))

extension Rect {
    init(centro: Punto, tamaño: Size) {
        let cX = centro.x - tamaño.ancho / 2
        let cY = centro.y - tamaño.alto / 2
        self.init(origen: Punto(x: cX, y: cY), tamaño: tamaño)
    }
    func area() -> Double { // no necesita mutating pues no se modifica la clase en sí
        return self.tamaño.ancho * self.tamaño.alto
    }
}

var rectCentral = Rect(centro: Punto(x: 12, y: 30), tamaño: Size(ancho: 30.m, alto: 50.m))
rectCentral.area()



extension Int {
    func repite(tarea: () -> Void) {
        for _ in 0..<self {
            tarea()
        }
    }
    mutating func cuadrado() {
        self = self * self
    }
}
4.repite {
    print("Hola! - ", terminator: "!!")
}
print("")

var cuadra = 4
cuadra.cuadrado()
cuadra.cuadrado()

extension Int { // intenté implementar algo nuevo... no da error pero es useless
    static func cuadrado(_ funcion: @escaping @autoclosure () -> Int) {
        funcion()
    }
}
cuadra.cuadrado()

extension String {
    var count: Int {
        return self.characters.count
    }
}

"Aleluya".count

// Nested Types
extension Int {
    enum Tipo {
        case negativo, cero, positivo
    }
    var tipo: Tipo {
        switch self {
        case let x where x > 0:
            return .positivo
        case let x where x < 0:
            return .negativo
        default:
            return .cero
        }
    }
}

cuadra.tipo
0.tipo
(-1).tipo

extension Character {
    enum Operacion: Character {
        case none = " ", suma = "+", resta = "-", multi = "x", divis = "/", raiz = "√"
    }
    var operacion: Operacion {
        switch self {
            case "+": return .suma
            case "-": return .resta
            case "x": return .multi
            case "/": return .divis
            case "√": return .raiz
        default: return .none
        }
    }
}

Character("√").operacion
let primerChar = "x".startIndex // 'subscript' is unavailable:
"x"[primerChar].operacion // cannot subscript String with an Int
let opera: Character.Operacion = .suma


enum Math {
    static let pi = 3.141592653589793
    static let e = 2.718281828459045235360287
    static let raiz16 = 16 / 4
}
Math.pi
Math.raiz16


enum errorContrasenia: Error {
    case corta, obvio
}

func checaContrasenia(_ contrasenia: String) throws -> String {
    if contrasenia == "123456" {
        throw errorContrasenia.obvio
    }
    switch contrasenia.characters.count {
    case 0..<5:
        throw errorContrasenia.corta
    case 6..<10:
        return "Ok"
    default:
        return "Bien!"
    }
}


enum Errorcito: Error {
    case rangoInvalido(String)
    case sinRaiz(String)
}

var cito = Errorcito.rangoInvalido("Completa el rango")
cito = .rangoInvalido("No Aplica")
cito = .sinRaiz("")
cito = .rangoInvalido("")

extension Errorcito: LocalizedError {
    var errorDescripcion: String? {
        switch self {
        case .rangoInvalido("Completa el rango"):
            str = "bueno pues, completa rango"
        case .rangoInvalido("No Aplica"):
            str = "N/A"
        case .sinRaiz("Noooo"):
            str = "planta un árbol"
        default:
            str = "Error no especificado"
        }
        return str
    }
}
cito
cito.errorDescripcion


enum Retorna<T> {
    case sinProblema(T), error(Error)
}
var retorno: Retorna = .sinProblema("yupi!")

// Sintaxis normal de Swift
guard case .sinProblema("Yepes!") = retorno
    else { fatalError() }



enum Actividad {
    case aburrido
    case hablando(sobre: String)
    case jugando(num_apuesta: Int)
    case durmiendo(soñando: Bool)
}

var que_hace = Actividad.hablando(sobre: "Futbol")
que_hace = .jugando(num_apuesta: 2034)
que_hace = .aburrido
que_hace = .hablando(sobre: "Porno")
que_hace = .durmiendo(soñando: false)

switch que_hace {
case .aburrido:
    str = "Bueno, ponte a jugar"
case .hablando(let deQue):
    str = "Bueno, qué piensas sobre \(deQue)"
case .jugando(let cuanto):
    str = "Y por qué no me invitaste a apostar \(cuanto)"
case .durmiendo(let sueño):
    str = sueño ? "con pajaritos" : "estabas despierto pues!"
}


// hay una definición similar "mi primera" en el archivo Practica Mayo
public enum RangoCartas: Int {
    case Dos = 2
    case Tres, Cuatro, Cinco, Seis, Siete, Ocho, Nueve, Diez
    case Jota, Reina, Rey, AS
    public var toChar: String {  // abajo hay otra implementación parecida
        var enLetra: String = ""  // podría llamarse de cualquier forma
        switch self {
        case .Jota: enLetra = "J"
        case .Reina: enLetra = "Q"
        case .Rey: enLetra = "K"
        case .AS: enLetra = "A"
        default: enLetra = String(describing: self.rawValue)
        }
        return enLetra
    }
}

let carta = RangoCartas.Rey
let valorCarta = carta.toChar
let h_valorCarta = carta.hashValue // Int, posición real desde cero
let r_valorCarta = carta.rawValue  // Int, definida por algún elemento
// rawValue siendo 1 devuelve nil, pues no está en el rango
var convertedRank: RangoCartas! = RangoCartas.init(rawValue: 1) // Rango aquí es Optional
convertedRank = RangoCartas.init(rawValue: 3)! // Tres no es String sino Rango
convertedRank = RangoCartas.init(rawValue: 4)
convertedRank?.toChar  // "4" es de tipo String
let tresDescrito = RangoCartas.init(rawValue: 3)?.toChar



/// WOW, I like it, but it seems doesn't work :( << I solved it!!!! :D >>
extension RangoCartas: Comparable {
    public static func < (lhs: RangoCartas, rhs: RangoCartas) -> Bool {
        switch (lhs, rhs) {
        case (_, _) where lhs == rhs:
            str = "\(lhs):\(lhs.rawValue) vs. \(rhs):\(rhs.rawValue)"
            return false // entre izquierda y derecha no hay iguales
//        case (.AS, _):  // cualquiera de los 2 cases va... funcionan aunque son redundantes
//            str = "\(lhs):\(lhs.rawValue) vs. \(rhs):\(rhs.rawValue)"
//            return false
//        case (_, _) where lhs.hashValue == AS.hashValue: // el máximo (.AS) no tiene mayor para compararse
//            str = "\(lhs):\(lhs.rawValue) vs. \(rhs):\(rhs.rawValue)"
//            return false
        default:
            str = "\(lhs):\(lhs.rawValue) vs. \(rhs):\(rhs.rawValue)"
            return lhs.hashValue < rhs.hashValue
        }
    }
}

extension RangoCartas: CustomStringConvertible {
    public var description: String { // CustomStringConvertible "pide" que la
        switch self {             // variable "sea" description, obligatorio!
        case .Jota: return "Jota"
        case .Reina: return "Reina"
        case .Rey: return "Rey"
        case .AS: return "AS"
        default: return "\(self.rawValue)"
        }
    }
}

let carta1 = RangoCartas.Reina
let carta2 = RangoCartas.AS
carta1.description

if carta1 == carta2 {
    str = "igual"
} else if carta1 < carta2 {
    str = "menor que"
} else if carta1 > carta2 {
    str = "mayor que"
}

public enum PaloCarta: String {// podría ser String y manejarlo mediante un array
    case picas, corazones, diamantes, tréboles

    var toChar: Character {
        switch self {
        case .picas: return "♠︎"
        case .corazones: return "♡"
        case .diamantes: return "♢"
        default: return "♣︎"
        }
    }
}

extension PaloCarta: Comparable {
    public static func < (lhs: PaloCarta, rhs: PaloCarta) -> Bool {
        switch (lhs, rhs) {
        case (_, _) where lhs == rhs: return false
        case (.picas, _), (.corazones, .diamantes),
             (.corazones, .tréboles), (.diamantes, .tréboles):
            return false
        default: return true
        }
    }
}

extension PaloCarta: CustomStringConvertible {
    public var description: String {
        switch self {
        case .picas: return "picas"
        case .corazones: return "corazones"
        case .diamantes: return "diamantes"
        case .tréboles: return "tréboles"
        }
    }
}

public struct CartaJugadora: Equatable {//, Hashable {
    public let rango: RangoCartas
    public let tipoC: PaloCarta

    init(rango: RangoCartas, tipoC: PaloCarta) {
        self.rango = rango; self.tipoC = tipoC
    }

    public var hashValue: Int {
        var hash = 5381   // hash puede ser cualquier número
        hash = ((hash << 5) &+ hash) &+ rango.hashValue
        hash = ((hash << 5) &+ hash) &+ tipoC.hashValue
        return hash
    }
//    public var hashValue: Int {  // podría usarse esto que es más simple
//        return rango.hashValue ^ tipoC.hashValue

    public static func == (lhs: CartaJugadora, rhs: CartaJugadora) -> Bool {
        return lhs.rango == rhs.rango && lhs.tipoC == rhs.tipoC
    }}

extension CartaJugadora: Comparable {
    public static func < (lhs: CartaJugadora, rhs: CartaJugadora) -> Bool {
        return lhs.rango == rhs.rango ? lhs.tipoC < rhs.tipoC : lhs.rango < rhs.rango
    }
    public static func > (lhs: CartaJugadora, rhs: CartaJugadora) -> Bool {
        return lhs.rango == rhs.rango ? lhs.tipoC > rhs.tipoC : lhs.rango > rhs.rango
    }
}

extension CartaJugadora: CustomStringConvertible {
    public var description: String {
        return "\(rango) de \(tipoC)"
    }
    // la variable short no pertenece a CustomStringConvertible pero me gustó dejarla aquí.
    public var short: String {
        return "\(tipoC.toChar)\(rango.toChar)"
    }
}

let cartaAC = CartaJugadora(rango: .AS, tipoC: .corazones)
cartaAC.hashValue

// PARA ACTIVAR ESTE CÓDIGO, HAY QUE CAMBIAR TIPOCARTA INT POR STRING
for C in 2...14 {
    var fila: String = ""
    for T in [PaloCarta.picas.rawValue,
              PaloCarta.tréboles.description,  // la misma m...
              PaloCarta.diamantes.rawValue,
              PaloCarta.corazones.rawValue] {
        let cartaX = CartaJugadora(rango: RangoCartas.init(rawValue: C)!, tipoC: PaloCarta.init(rawValue: T)!)

        // esta línea es medio-"horrorosa"
        let CH = cartaX.description.characters  // Asigno a CH como "puntero"
        let idx = Int(CH.distance(from: CH.startIndex, to: CH.index(of: " ")!))
        let tabu = idx > 1 ? "    \t" : " \t\t"
        fila.append("\(cartaX.description)\(tabu)")
    }
    print(fila)
}

// este FOR funciona tanto para Int como para String pues se maneja directamente los cases del enum
for T in [PaloCarta.picas, .corazones, .tréboles, .diamantes] {
    var cade: String = ""
    for C in 2...14 {
        let cartaX = CartaJugadora(rango: RangoCartas.init(rawValue: C)!, tipoC: T)
        cade.append("\(cartaX.short)\t")
    }
    print(cade)  // por defecto está description
}

//for T in 0..<4 {
//    for C in 2...14 {
//        let cartaX = CartaJugadora(rango: Rango.init(rawValue: C)!, tipoC: TipoCarta(rawValue: T)!)
//        print(cartaX)
//    }
//}



enum cuentaPersonal {
    case credito(cantidad: Int64, id: UInt)
    case debito(cantidad: Int64, id: UInt)
}

let cuentas: [cuentaPersonal] = [cuentaPersonal.credito(cantidad: -1000, id: 1),
                                .debito(cantidad: 1000, id: 2),
                                .credito(cantidad: -1000000, id: 3)]

// OJO: construcción regular
for cuenta in cuentas {
    if case var .credito(cantidad, id) = cuenta {
        print("canti \(cantidad) id: \(id)")
    }
}

// OJO: usando coincidencia de patrones
for case let .credito(cantidad, id) in cuentas {
    print("cantidad \(cantidad) id: \(id)")
}

let vistas: [UIView] = [UIButton(), UILabel(), UIScrollView(), UILabel()]

// Un ejemplo usando la cláusula where
for view in vistas where view is UILabel {
    print("la vista \(view.self) tiene frame: \(view.self.frame.origin)")
}


enum Genero {
    case noBinario
    case masculino
    case femenino
}

struct Persone {
    let nombre: String
    let genero: Genero
}

let famosos = [Persone(nombre: "Fernando", genero: .masculino),
               Persone(nombre: "Jenny", genero: .femenino),
               Persone(nombre: "Pitico", genero: .noBinario)]

for usuario in famosos where usuario.genero == .noBinario {
    print("\(usuario.nombre) es de género: \(usuario.genero)")
}

// OJO: usando switch

for usuario in famosos {
    switch usuario.genero {
    case .masculino: print("\t\(usuario.nombre) es Mascu")
    case .femenino: print("\t\(usuario.nombre) es Femen")
    case .noBinario: print("\t\(usuario.nombre) es Mariq")
    }
}

// OJO: usando cambio de tipo

for usuario in famosos {
    switch (usuario.genero, usuario.nombre) {
    case (.masculino, "Fernando"): print("\t\t\(usuario.nombre) hola!")
    default: break
    }
}



// Throwing!!!

enum ErrorColl: Error {
    case Empty
}

enum ErrorM: Error {
    case FaltanCaracteres(cuantos: Int)
}

func joinKeys(lhs: String, rhs: String) throws -> String {
    let cuentaMin = 5
    if lhs.isEmpty || rhs.isEmpty { throw ErrorColl.Empty }
    if lhs.characters.count < cuentaMin || rhs.characters.count < cuentaMin {
        throw ErrorM.FaltanCaracteres(cuantos: cuentaMin)
    }
    return lhs + rhs
}

do {
    try joinKeys(lhs: "Fernando", rhs: " Put me UP")
} catch is ErrorColl {
    str = "Uno de los parámetros está Vacío"
} catch ErrorM.FaltanCaracteres(let faltan) { // let cuantos crea una variable
    str = "Caracteres mínimos \(faltan)"
}

// Convirtiendo Errores a Valores Opcionales
try? joinKeys(lhs: "Fernando", rhs: " Will Work till Death")

// Desactivando Propagación de Errores
try! joinKeys(lhs: "Colombia", rhs: " Tierra Querida")


//extern NSErrorDomain const MiDominioError;
//typedef NS_ERROR_ENUM(MiDominioError, MiError) {
//    errorEspecifico1 = 0,
//    errorEspecifico2 = 1
//}
//
//func customError() throws {
//    throw NSError(
//        domain: MiDominioError,
//        code: MiError.errorEspecifico2.rawValue,
//        userInfo: [
//            NSLocalizedDescriptionKey: "A customized error from MyErrorDomain."
//        ]
//    )
//}
//
//do {
//    try customError()
//} catch MiError.errorEspecifico1 {
//    print("Caught specific error #1")
//} catch let error as MiError where error.code == .errorEspecifico2 {
//    print("Caught specific error #2, ", error.localizedDescription)
//    // Prints "Caught specific error #2. A customized error from MyErrorDomain."
//} catch let error {
//    fatalError("Some other error: \(error)")
//}

func copiaArchivo() {
    let adminArchivos = FileManager.default
    let desdeURL = URL(fileURLWithPath: "/Users/fernandodager/prueba.m")
    let haciaURL = URL(fileURLWithPath: "/Users/fernandodager/prueba.m.new")
    desdeURL.path

    do {
        try adminArchivos.setAttributes([.posixPermissions: 0o777], ofItemAtPath: desdeURL.path)
        try adminArchivos.copyItem(at: desdeURL, to: haciaURL)
    } catch CocoaError.fileNoSuchFile {
        print("Error: No existe tal archivo")
    } catch CocoaError.fileReadUnsupportedScheme {
        print("Error: esquema no soportado, debiera ser 'file:\\'")
    } catch let errorillo as NSError { // sólo con catch ya tiene una variable interna error
        print("Error1: \(errorillo.localizedDescription)")
        print("Error2: \(errorillo.domain)")
        print("Error3: \(CocoaError.Code.self)")
    }
}
// copiaArchivo()


typealias JSON = [String: Any?]

struct Cuenta {
    let udid: String
    let token: String
}
/*  Lo que viene muestra cómo construir usando 'guard'.
    Recuerda que 'guard' funciona a la inversa de un 'if'.  guarda variables en contexto para usarlas después de la condición.  Cuidado con guard, pues requiere de más tiempo para compilar. */
extension Cuenta {
    init?(json: JSON) {
        guard let udid = json["udid"] as? String,
            let token = json["token"] as? String else {
                return nil
        }
        self.udid = udid
        self.token = token
    }
}

let json: JSON = ["udid": "1234-adfsdfg-12312f-asfsa", "token": nil]
let cuenta = Cuenta(json: json)

// Definimos una tupla como nuevo tipo de dato...
typealias fnResultado = (tyNombre: String, tyLongitud: Int)

func longitudNombre(nombre: String = "Fernando") -> fnResultado {
    return (nombre, nombre.characters.count)
}
longitudNombre()


/* Múltiples valores de retorno en funciones
    Podemos usar una tupla como retorno de una función.  Es un mecanismo útil, pero si tienes más de un valor en retorno es tiempo de pensar en Struct como mejor opción.
    Sólo usa typealias para simplificar. */

typealias ElementosError = (elem: [String], error: Error?)

func descargar(desde indice: Int, con offset: Int) -> ElementosError {
    guard indice < 100 else { // si el índice es menor a 100 devuelva tupla con arreglo vacío y NSError
        return ([], NSError(domain: "com.vialyx.course", code: -987, userInfo: nil))
    } // En caso contrario, arme el arreglo y devuelva nil como Error?
    let elementos = Array(repeating: "result_\(indice)", count: offset)
    return (elementos, nil)
}
let tupla = descargar(desde: 200, con: 3)

/*  Funciones Anidadas
    El siguiente ejemplo es simple y entendible:
*/
func subir() -> ElementosError {
    func bajar() -> ElementosError {
        return (["Rar", "Zip"], nil)
    }
    let entregar: () -> ElementosError = bajar
    return entregar()
}
let tupla1 = subir()


/* Parámetros variádicos
 
    Aceptan cero o más valores.  Los valores de parámetro variádico están disponibles en un arreglo en el cuerpo de la función.  El parámetro variádico debe ser el último parámetro en la declaración de la función '...'.
    Los variádicos no pueden tener in-out 'inout'.
*/
typealias usuario = String

func dameUsuarios(con IDs: Int...) -> [usuario] {
    return ["Edgar", "Fernando"]
}
dameUsuarios(con: 123, 234, 345)

/* Parámetros in-out
 
    No pueden tener valores por defecto.  Los valores de las funciones son constantes por defecto, si se desea una función que pueda modificar sus parámetros debe declararse el parámetro como inout.
    es como en Pascal pornerle var al parámetro
*/

func actualiza(usuario: inout String) -> Error? {
    usuario = "Fernando" // se supone que no se puede modificar
    return nil
}
str = "Edgar"
actualiza(usuario: &str!)
str

var llamaFernando: (inout String) -> Error? = actualiza // función como tipo de dato

str = "Jenny"
llamaFernando(&str!)
str


struct Multa {
    let id: String = UUID().uuidString
    let fecha: Date? = Date()
    var nombre: String = ""
    var valor: NSNumber? = NSNumber(value: 0.0)
}

typealias EFServiceRetrieveResult = () -> Void
typealias EFServicePurchaseResult = () -> Void

class IAPService {
    func cargarProductos() {}
    func cargarProductos(completion: @escaping EFServiceRetrieveResult) {}
    func comprar(idProducto: String, completion: @escaping EFServicePurchaseResult) {}
}

var multaCimitarra = Multa()
multaCimitarra.nombre = "Fernando"
multaCimitarra.valor = 50_000

var multaBarranca = multaCimitarra
multaBarranca.valor = 10_000

multaCimitarra.valor
multaBarranca.valor

"\(multaCimitarra.valor == multaBarranca.valor)"



struct Automovil {
    let vin: String
    var placa: String?
}

var nuevoCarro = Automovil(vin: "mazeratti", placa: nil)
nuevoCarro.placa = "EFA234"

let car = nuevoCarro

//class EProcesoPago {
//    var vista: UIView?
//    private lazy var vistaInterna: UIView? = { [unowned self] in
//        guard let `vista` = view else {
//            return UIView(frame: .zero)
//        }
//        return vista
//    }()
//}

struct Pin {
    var valor: String {
        willSet {
            print("nuevo valor del pin \(newValue)")
        }
        didSet {
            print("anterior valor del pin \(oldValue)")
        }
    }
}

var pin = Pin(valor: "1212")
pin.valor = "91439275"


struct PropertyStruct {
    static var cacas: String = "Petro"
    static var socialismo: Double {
        return 21.0
    }
    var pais: String
    mutating func cambio(pais: String) {
        self.pais = pais
    }
}

PropertyStruct.cacas = "vale verga" // se puede modificar sin declarar una nueva clase
var pStruct = PropertyStruct(pais: "Colombia")
pStruct.cambio(pais: "Vete a Cuba")

enum PropertyEnum {
    static var cacas: String = "Maduro"
    static var socialismo: Double {
        return -21.0
    }
    case pais(String)
    mutating func cambio(pais: String) {
        switch self {
        case .pais(let p):
            self = .pais("De \(p) se debe pasar a \(pais)")
        }
    }
}

PropertyEnum.cacas = "Kirshner la perra"
var pEnum: PropertyEnum
pEnum = .pais("Colombia")
pEnum.cambio(pais: "Cuba")
pEnum = .pais("NorCorea")

/*
 La clase "PropertyClass" en el ejemplo proporcionado tiene varias variables de clase, que son propiedades que pertenecen a la clase en sí misma en lugar de a instancias individuales de la clase. Estas variables de clase tienen los siguientes beneficios:

 Acceso directo: Las variables de clase se pueden acceder directamente a través del nombre de la clase, sin necesidad de crear una instancia de la clase. Esto significa que puedes acceder a las variables de clase sin tener que crear objetos individuales de la clase "PropertyClass".

 Compartidas entre todas las instancias: Las variables de clase son compartidas entre todas las instancias de la clase. Esto significa que todas las instancias de "PropertyClass" comparten el mismo valor para las variables de clase. Si se modifica el valor de una variable de clase, ese cambio se reflejará en todas las instancias de la clase.

 Almacenamiento de valores: Las variables de clase pueden almacenar valores, como en el caso de "storedTypeProperty" que tiene un valor de "1". Estos valores se mantienen en la memoria durante la vida útil de la aplicación y se pueden acceder y modificar según sea necesario.

 Propiedades calculadas: Las variables de clase también pueden ser propiedades calculadas, como en el caso de "computedTypeProperty" y "overrideableComputedTypeProperty". Estas propiedades calculadas permiten realizar cálculos o lógica para obtener un valor en función de otros factores. En el ejemplo, "computedTypeProperty" siempre devuelve el valor 10.0, mientras que "overrideableComputedTypeProperty" es una propiedad calculada que puede ser sobrescrita en subclases.

 En resumen, las variables de clase en la clase "PropertyClass" proporcionan un mecanismo para almacenar y acceder a valores compartidos entre todas las instancias de la clase, así como para realizar cálculos o lógica para obtener valores específicos. Esto puede ser útil en situaciones donde se necesita compartir información o comportamiento entre todas las instancias de una clase.
 
 */

class PropertyClass {
    static var cacas: String = "Maduro"
    static var socialismo: Double {
        return -21.0
    }
    class var overridenClassProp: Double {
        return 3.1415
    }
}

PropertyClass.cacas = "AMLO desquiciado"
PropertyClass.overridenClassProp


// Definiendo una clase base.
/* Las clases de Swift no se heredan de una clase universal.  Al definirlas, se convierten en la clase base de la cual podrá construir todo lo demás.
 */

class Reproductor {
    var reproduce: Bool = false

    func reproducir() {
        reproduce = true
    }

    func detener() {
        reproduce = false
    }

    func restaurarse(reproduce: Bool) {
        self.reproduce = reproduce
    }
}

// Subclases.
/* Es el acto de crear una nueva clase a partir de otra.  La subclase hereda características de la base existente, la cual puede redefinir.
 */

class ReproductorVideo: Reproductor {

    var archivo: String = ""
    var ancho: Int = 0
    var alto: Int = 0
}

// Overriding.
/* Una subclase puede proveer una implementación de un método de instancia, propiedad de instancia, propiedad de tipo, o subscript que puede heredar de una superclase.  A esto se le conoce como overriding, "anulamiento", "cambio de orden".
 */

class ReproductorAudio: Reproductor {
    // Overriding Property Observers
    override var reproduce: Bool {
        didSet {
            print("\(self) ha reproducido!")
        }
    }
    // Overriding métodos
    override func restaurarse(reproduce: Bool) {
        print("\(self) restaura la ejecución: \(reproducir)")
    }
}

//  Impidiendo Overrides
/*  Puedes impedir un método, propiedad, o subscript de ser overriden marcándolo como final.  Para hacer esto se escribe el modificador 'final' antes del método, propiedad propiedad o palabra clave introductoria (como final var, final func, final class y final subscript).  También puede marcar una clase entera 'final class).  Cualquier intento de generar una nueva subclase a partir de una clase final se reporta como error de compilación.
 */

//  Inicialización
/*  Es el proceso de preparar una instancia de clase, estructura o enumeración para su uso.  Involucra asignar valores iniciales a las propiedades de la clase.
 */

class Opciones: NSObject {
    enum Estado {
        case activado, desactivado
    }

    enum Accion {
        case configurar, abrir, guardar
    }

    var nombre: String
    var estado: Estado
    var accion: Accion? = .configurar // Default property value con .configurar como valor por defecto, con Optional agregado (?).  Cuando hay init, hay prioridad en la asignación.  La ventaja de tener Optional es que puede recibir nil y definir lo que abajo está como Genial

    init(con nombre: String, estado: Estado = .desactivado, accion: Accion? = .abrir) {
        self.nombre = nombre
        self.estado = estado
        self.accion = accion == nil ? self.accion : accion // Genial
    }
}

let config = Opciones(con: "Julia", accion: nil)
config.estado
config.accion


//  Propiedades de tipo Optional
/*  Si tu tipo de dato personalizado tiene una propiedad que lógicamente pueda tener "ningún valor" - talvez porque su valor no se pueda asignar durante la inicialización, o porque se le permite tener "ningún valor" en un punto posterior - declare la propiedad como Optional.
 */

class TransportStorage {

    weak var salida: NSObject?

    var baseDatos: Any // <----- Constante
    var token: String?

    init(baseDatos: Any) {
        self.baseDatos = baseDatos
    }
}

let almacenaje = TransportStorage(baseDatos: UserDefaults.standard)
almacenaje.baseDatos
almacenaje.token  // nil por defecto
almacenaje.token ?? ""
almacenaje.token = UUID().uuidString
almacenaje.token

//  Herencia de Clases e Inicialización
/*  No puedes dejar nada sin inicializar.  Swift define dos clases de inicializadores para los tipos de clase a que ayuden a asegurar que todas las propiedades almacenadas reciban un valor inicial.  Estos son: Inicializadores Designados e Inicializadores Convenientes.
 */

//  Inicializadores Convenientes e Inicializadores Designados
/*  
    Son los inicializadores esenciales de la clase.  Un Inicializador Designado inicializa totalmente todas las propiedades de esa clase y llama un inicializador de superclase apropiado para seguir el proceso en la cadena de  superclases.

    Las clases tienden a tener muy pocos Inicializadores Designados, y es muy común para una clase tener al menos uno.  Se comportan como un embudo de inicialización.  En algunos casos, este requerimiento se cumple heredando uno o más inicializadores designados de una superclase, como se describe más adelante en Herencia de Inicialización Automática.

    Los Inicializadores Convenientes son secundarios, dando soporte a los inicializadores de una clase.  Se puede definir un Inicializador Conveniente para llamar a un Inicializador Designado desde la misma clase con algunos de los parámetros mediante valores por defecto.  Se puede definir un Inicializador Conveniente para crear una instancia de esa clase para un caso de uso específico o tipo de valor de entrada.

    No se tiene que proveer Inicializadores de Conveniencia si no son necesarios.  Crea Inicializadores Convenientes siempre que un acceso directo a un patrón simple de inicialización ahorre tiempo o haga que la intención de inicialización sea más clara.
 */

class BtnPantCompleta: UIButton {
    // Inicializador Conveniente
    convenience init(_ screen: UIScreen) {
        self.init(frame: screen.bounds) // Reusamos el Inicializador Designado
    }
    // Inicializador overriden
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    // Inicializador Requerido
    required init?(coder aDecoder: NSCoder) {
        fatalError("no se ha implementado init(coder:)")
    }
    // Inicializador Falible
    init?(_ screen: UIScreen, with type: UIButtonType) {
        guard screen.bounds.width > 320 else { return nil }
        super.init(frame: screen.bounds)
    }
}
// Inicializador Conveniente
let panta = UIScreen.main
let btnConv = BtnPantCompleta(panta)
// Inicializador Overriden
let franja = CGRect(x: 0, y: 0, width: 100, height: 200)
let btnOver = BtnPantCompleta(frame: franja)
// Inicializador Requerido
/* No se puede utilizar directamente, ya que no se ha implementado */
// Inicializador Falible
let btnFali = BtnPantCompleta(panta, with: .roundedRect)

// variante del Falible
let tipos: [UIButtonType] = [.roundedRect, .system, .infoDark]
let btnFall = tipos.map { tipo in
    return BtnPantCompleta(panta, with: tipo)
}
type(of: btnFall)
btnFall[0]


class AlmacenajeTransporte {

    var salida: NSObject?

    let baseDatos: Any // <---- Constante
    var token: String?

    init(baseDatos: Any) {
        self.baseDatos = baseDatos
    }
}

let contenedor = AlmacenajeTransporte(baseDatos: UserDefaults.standard)

// Optional con case .none -> nil
contenedor.token?.description
contenedor.token?.description ?? "Sin Descripción"

// Esto bota error al forzar abrir la variable Optional
// contenedor.token!.description ?? ""

contenedor.token = UUID().uuidString
contenedor.token

// Optional con case .some -> String
contenedor.token?.description

// *** Crash!!! The output in currently nil ***
// this triggers a runtime error
// contenedor.salida!.description

contenedor.salida = NSObject()

// Ahora que tiene un valor, funciona
contenedor.salida!.description



class Militar {
    var armamento: Armamento? // Una vez el Militar se crea, el armamento se inicializa en nil
}

class Armamento {
    var nCuchillos = 1
}

// Podríamos definir a Rambo como alguien de clase Militar simplemente, pero para el siguiente ejemplo, lo pondremos como Opcional.
var rambo: Militar? = Militar() // Rambo es un Militar que necesita nCuchillos por tanto, necesita armamento? puede que sí, puede que no, a esta variable se le llama Optional y se define con ? al final del tipo de dato
rambo
rambo?.armamento  // Rambo internamente sabe que necesita de armamento, y bueno, mientras tanto es nil y en el momento que lo necesite, lo tomará...
// rambo?.armamento!  // Si en este momento Rambo pide su cuchillo al estilo "quiero armamento!", el compilador arrojará un error pues no hay armamento asignado aún
// rambo!.armamento!.nCuchillos // y si lo pide como "Soy Rambo! quiero el cuchillo que está en mi armamento!", el error persiste
rambo?.armamento?.nCuchillos // Esta forma es más amable, Rambo pide su cuchillo, pero como no está seguro si el armamento está asignado, aquí se usa Optional Chaining ? significa cadena opcional y en cada eslabón con ? denota precaución pues no sabe si es nil (sin asignar).   Ahora, sí y sólo sí se está 100% seguro de que el armamento esté asignado puede usar unwrapping (apertura) mediante !, pues si no está asignado, Rambo estará en grave peligro!!! (error)
let americano = Armamento() // Creamos un Armamento con 1 cuchillo (nCuchillos = 1) aunque Rambo todavía no sabe que se lo haremos llegar
rambo?.armamento = americano // Asignamos a Rambo el armamento americano
rambo?.armamento?.nCuchillos // Para que Rambo esté seguro de que esté asignado su armamento con al menos numArmas = 1 volvemos a usar Optional Chaining ?, si lo está, arroja: 1, si no: nil
rambo?.armamento!.nCuchillos // Aquí Rambo está 100% seguro que tiene armamento y por eso abre con ! y sí o sí es 1
rambo!.armamento?.nCuchillos
rambo!.armamento!.nCuchillos

// Dos formas seguras de verificar los Optionals
guard let armasParaRambo = rambo?.armamento?.nCuchillos else {
    fatalError("no encontró armas... aunque es Rambo!")
}
armasParaRambo // variable declarada usando 'guard' y sólo es visible fuera del cuerpo de 'guard'

if let armasParaRambo = rambo?.armamento?.nCuchillos { // armasParaRambo es visible sólo dentro del cuerpo, por tanto no tiene conflicto con la anterior declaración de 'guard' de armasParaRambo
    let plural = armasParaRambo == 1 ? "ón" : "ones" // Esto me encanta pues ahorro líneas
    "Rambo encontró \(armasParaRambo) habitaci\(plural)"
} else {
    "Rambo no pudo encontrar cuarto ;_("
}

rambo = nil // intentamos liberar a rambo para una nueva misión



let formatter = DateFormatter()
formatter.dateFormat = "dd 'de' MMM 'de' yyyy"


class ArmamentoMejorado: Armamento {
    var pistolas: [Pistola] = [] // propiedad almacenada
    var numPistolas: Int {      // propiedad computada o calculada
        return pistolas.count
    }
    subscript(pos: Int) -> Pistola {
        get {
            return pistolas[pos]
        }
        set {
            pistolas[pos] = newValue
        }
    }
    func getNumPistolasStr() -> String {
        return "cantidad pistolas: \(numPistolas)"
    }
    var mision: Mision?
}

class Pistola {
    var marca: String
    init(marca: String) { self.marca = marca }
}

class Mision {

    var fecha: Date?
    var pais: String?
    var dificultad: DificultadMision?

    func describeMision() -> String? {
        // hay que terminar esto...
        var str: String?
        if let pais = pais, let fecha = fecha {
            let fechaStr = formatter.string(from: fecha)
            str = "Irás a \(pais) el día \(fechaStr)"
        }
        if dificultad != nil {
            if str != nil { str = str! + ", " }
            str = str! + "tu nivel de dificultad será \(dificultad!.nivel)"
        }
        return str
    }
}

enum DificultadMision {
    case facil, intermedio, dificil, mortal
    public var nivel: String { // propiedad calculada
        var str = ""
        switch self {
        case .facil: str = "pan comido"
        case .intermedio: str = "regulimbis"
        case .dificil: str = "tenaz"
        default: str = "mortal"
        }
        return str
    }
}

var arnold: Militar = Militar()
arnold.armamento = ArmamentoMejorado() // Polimorfismo en acción

// uso del subscript implementado versión 1 al agregar Pistola mediante cast
(arnold.armamento as! ArmamentoMejorado).pistolas.append(Pistola(marca: "Smith'n'Wesson"))

// uso del subscript implementado versión 2 al agregar Pistola
let armasMejoradas = arnold.armamento as! ArmamentoMejorado
armasMejoradas.pistolas.append(Pistola(marca: "Colt"))


var maxArmas = (arnold.armamento as? ArmamentoMejorado)!.numPistolas // Si no se hace un unwrapping ! en adelante habría que aperturar cada uso de maxArmas, maxArmas!

// reasignación mediante subscript, se puede hacer pues el arreglo tiene 2 elementos
armasMejoradas[maxArmas-1] = Pistola(marca: "Beretta") // armasMejoradas[1]

let segundaPistola = armasMejoradas[1] // subscript en acción
"la segunda arma es \(segundaPistola.marca)"

armasMejoradas.mision = Mision()
armasMejoradas.mision?.dificultad = DificultadMision.intermedio
armasMejoradas.mision?.pais = "Colombia"
armasMejoradas.mision?.fecha = formatter.date(from: "28 de oct de 2030")
armasMejoradas.mision?.describeMision()

// En definitiva, las armas para Arnold han sido un aprendizaje, se complicó el código para que puedas aprender alternativas.  Para Rambo, vamos a simplificar las cosas...

// preparemos el armamento para Rambo antes que aparezca
var armasRambo = ArmamentoMejorado()
armasRambo.pistolas.append(Pistola(marca: "Glock"))
armasRambo.pistolas.append(Pistola(marca: "HK"))
armasRambo[1] = Pistola(marca: "Echelon") // subscript en acción
armasRambo.pistolas.append(Pistola(marca: "Walther"))

maxArmas = armasRambo.numPistolas  // Compáralo con la anterior asignación a maxArmas

formatter.dateFormat = "MM/dd/yyyy"

// asignemos una misión completa
var misionRambo = Mision()
misionRambo.fecha = formatter.date(from: "10/26/1981")
misionRambo.pais = "Thailand"
misionRambo.dificultad = .mortal

armasRambo.mision = misionRambo // acoplamos la misión de Rambo a las armas de Rambo

rambo = Militar() // Rambo vuelve al ruedo
rambo?.armamento = armasRambo



// El siguiente bloque de código es horrible, pero te hará pensar, analízalo

"Rambo tiene: \(rambo!.armamento!.nCuchillos) cuchillo" // full unwrap chaining
if let nPistolas = (rambo?.armamento as? ArmamentoMejorado)?.numPistolas {
    (rambo?.armamento as? ArmamentoMejorado)?.getNumPistolasStr()
    "Las \(nPistolas) son: \((rambo?.armamento as? ArmamentoMejorado)!.pistolas)"
    "La Pistola favorita : \((rambo?.armamento as! ArmamentoMejorado)[1].marca)"
} else if let nCuchillos = rambo?.armamento?.nCuchillos {
    "Le tocó con \(nCuchillos) cuchillo(s)"
} else {
    "Sólo Rambo puede salir de esta"
}

// Para entender aún mejor, retomemos Optional, al asignarlo se simplifica en lectura

let armamentoRambo = rambo?.armamento as? ArmamentoMejorado // armamento es Optional, de tipo Armamento? hacemos un casting a ArmamentoMejorado

if let nPistolas = armamentoRambo?.numPistolas {
    armamentoRambo?.getNumPistolasStr()
    "Las \(nPistolas) son: \(armamentoRambo!.pistolas)"
    "La Pistola favorita : \(armamentoRambo![1].marca)" // subscript
} else if let nCuchillos = armamentoRambo?.nCuchillos {
    "Le tocó con \(nCuchillos) cuchillo(s)"
} else {
    "Sólo Rambo puede salir de esta"
}



//  Optional Binding 'if let / if var' sólo funciona cuando el resultado del lado derecho de la expresión es Optional.  En caso de no ser Optional, no se puede usar Optional Binding.  Optional Binding es sólo para revisar el valor de nil y usar la variable solamente si no es nil.  Por tanto, la estrategia aquí es diferente.

//  Asignamos primero las armas que tiene Rambo, recordemos que armasRambo es de tipo ArmamentoMejorado()

let nPs = armasRambo.numPistolas
let nCs = armasRambo.nCuchillos  // Rambo tiene 1 cuchillo

if nPs > 0 {
    armasRambo.getNumPistolasStr()
    "Las \(nPs) son \(armasRambo.pistolas)"
    "La Pistola favorita: \(armasRambo[1].marca)"  // subscript
} else if nCs > 0 {
    "Le tocó con \(nCs) cuchillo(s)"
} else {
    "Sólo Rambo puede salir de esta"
}

// O podemos hacer un casting a Int? para volverlo Optional

if let nPistolas = armasRambo.numPistolas as Int? {
    armasRambo.getNumPistolasStr()
    "Las \(nPistolas) son: \(armasRambo.pistolas)"
    "La Pistola favorita : \(armasRambo[1].marca)" // subscript
} else if let nCuchillos = armasRambo.nCuchillos as Int? {
    "Le tocó con \(nCuchillos) cuchillo(s)"
} else {
    "Sólo Rambo puede salir de esta"
}


func creaMision() -> Mision {
    print("Se ejecutó la misión - ", terminator: "")
    let algunaMision = Mision()
    algunaMision.pais = "Panama"
    algunaMision.dificultad = .facil
    algunaMision.fecha = Date()

    return algunaMision
}

let tirofijo = Militar()
var armaTF = Mision()
var mejorTF = ArmamentoMejorado()
tirofijo.armamento = mejorTF
(tirofijo.armamento as? ArmamentoMejorado)?.mision = creaMision()
(tirofijo.armamento as! ArmamentoMejorado).mision!.fecha

mejorTF.mision = creaMision()
mejorTF.mision?.dificultad

(rambo?.armamento as! ArmamentoMejorado).mision = creaMision()
(rambo?.armamento as! ArmamentoMejorado).mision!.pais


// Accediendo a los elementos de un Diccionario directamente (subscripts mediante tipo Optional)
var puntuacion: [String : [Int]] = ["Fernando" : [10, 9, 8], "Jenny" : [7, 6, 5]]

puntuacion["Fernando"]?[0] = 3
puntuacion["Fernando"]?[1] -= 2
puntuacion["Fernando"]?[2] += 1

puntuacion["Fernando"]?[0]
puntuacion["Fernando"]?[1]
puntuacion["Fernando"]?[2]



// MÁS SOBRE PROTOCOLOS

protocol ProtIndicadorActividad: class {
    var indicadorActividad: UIView? { get set }
}

extension ProtIndicadorActividad {

    var indicadorActividad: UIView? {
        get {
            return nil
        }
        set {
            print("\(newValue)")
        }
    }
}

/// Enum tomado de un sitio y mejorado por moi https://ericasadun.com/2014/08/

protocol RawRepresentado {
    associatedtype Raw
    static func fromRaw(raw: Raw) -> Self?
}

enum Numies: Int, RawRepresentado {
    typealias Raw = Int

    case cero = 5
    case uno = 10
    case dos = 15
    case tres = 20

    internal static func fromRaw(raw: Int) -> Numies? {
        //        switch raw {
        //        case self.cero.rawValue: return .cero
        //        case self.uno.rawValue: return .uno
        //        case self.dos.rawValue: return .dos
        //        case self.tres.rawValue: return .tres
        //        default: return nil
        //}
        guard let numie = Numies(rawValue: raw) else {
            return nil
        }
        return numie
    }
}

var eee = Numies.fromRaw(raw: 2)
var ddd: Numies? = Numies.fromRaw(raw: 20)
ddd == .dos
ddd == .tres
ddd?.rawValue
ddd = .cero
ddd?.rawValue

enum Letras: Character, RawRepresentado {
    typealias Raw = Character

    case x = "x"
    case y = "y"
    case z = "z"

    internal static func fromRaw(raw: Character) -> Letras? {
        guard let letris = Letras(rawValue: raw) else {
            return nil
        }
        return letris
    }
}

var xx: Letras? = Letras.fromRaw(raw: "x")
var yy = Letras.init(rawValue: "y")
var mm = Letras.fromRaw(raw: "m")



// PROPERTY REQUIREMENTS

/*
 Un protocolo puede requerir cualquier propiedad de instancia o tipo con nombre y tipo en particular.  El protocolo no especifica cuando la propiedad deba ser almacenada o calculada - solo especifica el nombre y tipo de tal propiedad.  El protocolo también especifica cualdo cada propiedad de be ser sólo gettable o gettable y settable.
 */

protocol Informado {
    var info: [String : String] { get set }
}

protocol MarcaTarjeta {
    var nombreTenedor: String { get set }
    var numero: String { get set }
    var vence: Date? { get set }
    var mes: String? { get }
    var año: String? { get }
}

struct TarjetaCredito: MarcaTarjeta {
    internal var nombreTenedor: String // por defecto, las propiedades almacenadas son internal
    var numero: String
    var vence: Date?
    internal var mes: String?
    internal var año: String?
    var clave: String
}

extension TarjetaCredito {
    init(numero: String, vence: Date, clave: String) {
        self.nombreTenedor = ""
        self.numero = numero
        self.vence = vence
        self.clave = clave

        /* una forma elegante de sacar el año es a través de la clase Calendar. */
        let calendario = Calendar.current
        self.año = String(calendario.component(.year, from: vence))
        /* la otra es a través del objeto DateFormatter */
        formatter.locale = Locale(identifier: "es_ES")
        formatter.dateFormat = "MMMM"
        self.mes = formatter.string(from: vence)
    }
}

var mastercardPersonal = TarjetaCredito(numero: "5523-12345-234-23423", vence: formatter.date(from: "10/26/2030")!, clave: "065")

extension TarjetaCredito: Informado {
    var info: [String : String] {
        get {
            /* una forma elegante de sacar el año es a través del objeto Calendar. */
            let calendario = Calendar.autoupdatingCurrent
            let año = String(calendario.component(.year, from: vence!))
            /* la otra es a través del objeto DateFormatter */
            formatter.dateFormat = "MMMM"
            formatter.locale = Locale(identifier: "es_ES")
            let mes = formatter.string(from: vence!)

            return ["Numero" : self.numero,
                    "Tenedor" : nombreTenedor,
                    "Vence" : vence!.description,
                    "Mes vence: " : mes,
                    "Año vence: " : año,
                    "Clave" : clave]
        }
        set { // Excelente forma de actualizar propiedades en un struct/clase con una extensión
            if newValue.keys.contains("Tenedor") {
                if let tenedor = newValue["Tenedor"] {
                    self.nombreTenedor = tenedor
                }
            }
        }
    }
}

//mastercardPersonal.info
mastercardPersonal.info = ["Tenedor": "Fercho"]
//mastercardPersonal.info
mastercardPersonal.mes!

extension TarjetaCredito {
    subscript(key: String) -> String? {  // Excelente este subscript
        switch key {
            case "Tenedor": return nombreTenedor
            case "Numero": return numero
            case "Fecha": return vence?.description
            case "Mes": return mes
            case "Clave": return clave
        default: return nil
        }
    }
}

mastercardPersonal["Tenedor"]
mastercardPersonal["Fecha"]
mastercardPersonal["Mes"]
mastercardPersonal[""]
String(describing: mastercardPersonal["Numero"]!)


/// NESTED TYPES

extension TarjetaCredito {

    enum MarcaTarjeta {
        case unknown, mastercard, maestro, diners, visa
    }

    var tipoStr: MarcaTarjeta {
        guard self.numero.characters.count > 0 else { return .unknown }
        let idx = numero.startIndex
        let primNum = numero[idx ..< numero.index(idx, offsetBy: 1)]
        switch primNum {
            case "5": return .mastercard
            case "6": return .maestro
            case "3": return .diners
            case "4": return .visa
        default: return .unknown
        }
    }

    var tipoNum: MarcaTarjeta {
        guard numero.characters.count > 0 else { return .unknown }
        let primNum = Int(String(numero[numero.startIndex])) ?? 0
        switch primNum {
            case 5: return .mastercard
            case 6: return .maestro
            case 3: return .diners
            case 4: return .visa
        default: return .unknown
        }
    }
}

mastercardPersonal.tipoStr
mastercardPersonal.numero = "65324-234234-3234-223"
mastercardPersonal.tipoNum



// Method Requirements (Requerimientos de Método)
/*
   Los Protocolos pueden requerir métodos de instancia específicos y métodos de tipo sean implementados por tipos conformes.  Estos métodos se escriben como parte de la definición del protocolo en exactamente la misma forma como para los métodos de instancia normal y de tipo, pero sin llaves de apertura/cierre ni cuerpo del método.  Se permiten parámetros variádicos sujeto a las mismas reglas de los métodos normales.  Sin embargo, no se pueden especificar valores predeterminados para los parámetros del método dentro de la definición del protocolo.
 
    Al igual que con los requisitos de propiedad de tipo, siempre se antepone la palabra clave estática a los requisitos de método de tipo cuando se definen en un protocolo. Esto es cierto incluso aunque los requisitos del método de tipo tengan el prefijo class o palabra clave estática cuando los implementa una clase:

    Como con los requerimientos de propiedad de tipo, puede prefijarse requerimientos de método de tipo con la palabra clave 'static' cuando se define en un protocolo.  Esto es cierto incluso con los requerimientos de tipo de método se prefijan con las palabras 'class' o 'static' cuando los implementa una clase:
*/

protocol Mockable {
    static func mock(_ opcion: Int) -> Self // OJO: no confundir Self con la clase en sí
}

extension TarjetaCredito: Mockable {
    static func mock(_ opcion: Int) -> TarjetaCredito {
        // var tarjeta: TarjetaCredito = TarjetaCredito(nombreTenedor: "", numero: "", vence: nil, mes: nil, año: nil, clave: "")
        var tarjeta = TarjetaCredito(numero: "", vence: Date(), clave: "")

        formatter.dateFormat = "MM/dd/yyyy"

        switch opcion {
        case 1:
            tarjeta.numero = "4111-111-111-111"
            tarjeta.vence = formatter.date(from: "10/26/2040")
            tarjeta.clave = "123"
        default:
            tarjeta.numero = "0000-000-000-000"
            tarjeta.vence = formatter.date(from: "12/31/2080")
            tarjeta.clave = "987"
        }

        tarjeta.nombreTenedor = "John Wick"
        return tarjeta
    }
}

let visa = TarjetaCredito.mock(0)
print(visa.info)


extension TarjetaCredito {
    mutating func inventaUna() {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM/dd/yyyy"
        var inventa = TarjetaCredito(numero: "000-iventada", vence: formatter.date(from: "10/10/2050")!, clave: "039")
        inventa.info["Tenedor"] = "Sheldon Cooper" // A través de calculados puedo modificar
        self = inventa  // self es el secreto de esta función, por eso se declara mutating
        self.info["Tenedor"] = "Penny"
    }
}

var inventada = TarjetaCredito(numero: "", vence: Date(), clave: "")
inventada.inventaUna()
inventada.info



// MARK: SUBSCRIPTS

extension Int {
    subscript(idx: Int) -> Int {
        var baseDecimal = 1
        for _ in 0..<idx { // intenté usar 1...idx pero no funciona con 0 y no sé porqué
            baseDecimal *= 10
        }
        return (self / baseDecimal) % 10
    }
}

984123456799[10]
1234567890[7]


// MARK: Reemplazando ENUMS

//struct DiasSemana { // enum DiasSemana
//    var dia: String
//
//    init(dia: String?) {
//        self.dia = dia ?? ""
//    }
//
//    static let lunes = DiasSemana(dia: "Lunes")
//    static let martes = DiasSemana(dia: "Martes")
//    static let miercoles = DiasSemana(dia: "Miércoles")
//    static let jueves = DiasSemana(dia: "Jueves")
//    static let viernes = DiasSemana(dia: "Viernes")
//    static let sabado = DiasSemana(dia: "Sábado")
//    static let domingo = DiasSemana(dia: "Domingo")
//
//    static func dameDia(dia: String) -> DiasSemana {
//        return DiasSemana(dia: dia)
//    }
//
//    subscript(_ idx: Int) -> DiasSemana? {
//        let dSem: [DiasSemana] = [DiasSemana.lunes, .martes, .miercoles, .jueves, .viernes, .sabado, .domingo]
//        if idx >= 0, idx < dSem.count {
//            return dSem[idx]
//        }
//        return nil
//    }
//}
//
//let lunes = DiasSemana.lunes
//lunes.dia
//let martes = DiasSemana.dameDia(dia: "Martes")
//martes.dia
//let diaSemana = DiasSemana(dia: nil)[2]  // Crearlo vacío es cool
//diaSemana?.dia
//diaSemana?[4]?.dia  // Frankestein!!!

struct DiasSemana {
    var dia: String

    init(_ dia: String?) { // quitamos el outer label para que haya código más simple
        self.dia = dia ?? ""
    }
    init() {
        self.dia = ""
    }

    static let lunes = DiasSemana("Lunes")
    static let martes = DiasSemana("Martes")
    static let miercoles = DiasSemana("Miércoles")
    static let jueves = DiasSemana("Jueves")
    static let viernes = DiasSemana("Viernes")
    static let sabado = DiasSemana("Sábado")
    static let domingo = DiasSemana("Domingo")

    static func create(dia: String) -> DiasSemana {
        return DiasSemana(dia)
    }

    subscript(_ idx: Int) -> DiasSemana? {
        let dSem: [DiasSemana] = [DiasSemana.lunes, .martes, .miercoles, .jueves, .viernes, .sabado, .domingo]
        if idx >= 0, idx < dSem.count {
            return dSem[idx]
        }
        return nil
    }
}

let diasSemana = DiasSemana(nil)
let miercoles = diasSemana[2]
miercoles!.dia // Output: Miércoles
let jueves = DiasSemana(nil)[3]  // crear y usar subscript al mismo tiempo
jueves?.dia
let domingo = DiasSemana.create(dia: "Domingo")
domingo.dia
let lunes = DiasSemana.lunes
lunes.dia
let sabado = DiasSemana()[5] // la mejor implementación...
sabado?.dia


/// MARK: LAZY


struct Person {
    var nombre: String
    lazy var arbolFamiliar = ArbolFamiliar()

    init(nombre: String) {
        self.nombre = nombre
    }
}

struct ArbolFamiliar {
    init() {
        print("Creando un árbol familiar!")
    }
}

var ed = Person(nombre: "Ed")
"Persone \(ed.nombre) creade"

// En este punto, el árbol genealógico de la familia aún no se ha creado
print(ed.arbolFamiliar)
// Output:
// Creating family tree!
// <__lldb_expr_1.FamilyTree: 0xXXXXXXXXXXXX>



// MARK: DIFERENCIAS ENTRE [weak self] y [unowned self]

/*
    Se usan [weak self] y [unowned self] para evitar ciclos de retención fuerte (retain cycles) al capturar self dentro de un closure.  Ambas opciones permiten que el closure haga referencia a self sin crear una retención fuerte, lo que puede causar problemas de memoria.  ambos manejan diferente la posibilidad de que self sea nil en el momento en que se accede dentro del closure.

    [weak self]: Al capturar self como una referencia débil, el closure crea una referencia opcional a self.  Puede ser nil en el momento en que se accede dentro del closure.  Para utilizar de manera segura self dentro del cierre, se debe desempaquetar la referencia débil utilizando 'guard let' o 'if let', así evita problemas de acceso a un objeto nil.

 Ejemplo con [weak self]:
 */

class ViewControllerW {
    var closure: (() -> Void)?

    func setupClosure() {
        closure = { [weak self] in
            guard let `self` = self else { return } // Atento a `self`
            print("+ViewController: \(self), \(`self`).")
        }
    }

    deinit {
        print("-\(self) deallocated")
    }
}

var viewControllerW: ViewControllerW? = ViewControllerW()
viewControllerW?.setupClosure()
viewControllerW?.closure?() // Salida: "ViewController: ViewControllerW"

viewControllerW = nil // Salida: "ViewControllerW deallocated"

/*
    Aquí la clase ViewControllerW tiene una propiedad closure que captura [weak self].  Dentro del closure, se usa 'guard let' para desempaquetar de manera segura la referencia débil a `self` y evitar problemas si self se ha vuelto nil.  Al final, cuando se coloca viewControllerW en nil, la instancia de ViewControllerW se desasigna correctamente.

    [unowned self]: Al capturar self como una referencia sin propietario, el closure crea una referencia no opcional a self.  Esto significa que el cierre asume que self no será nil en el momento en que se accede dentro del cierre.  Si se accede a self después de que se haya desasignado, se producirá un error de tiempo de ejecución.
 
    Ejemplo con [unowned self]:
 */

class ViewControllerUO {
    var closure: (() -> Void)?

    func setupClosure() {
        closure = { [unowned self] in
            print("+ViewController: \(self)")
        }
    }

    deinit {
        print("-\(self) deallocated")
    }
}

var viewControllerUO: ViewControllerUO? = ViewControllerUO()
viewControllerUO?.setupClosure()
viewControllerUO?.closure?() // Salida: "ViewController: ViewController"

viewControllerUO = nil // Salida: "ViewController deallocated"

/*
    En este ejemplo, la clase ViewControllerUO tiene una propiedad closure que captura [unowned self].  Dentro del closure se accede directamente a self sin necesidad de desempaquetar una referencia opcional.  Sin embargo, si se accede a self después de que se haya desasignado, se producirá un error de tiempo de ejecución.

 En resumen, [weak self] se utiliza cuando se espera que self pueda ser nil en el momento en que se accede dentro del cierre, mientras que [unowned self] se utiliza cuando se asume que self no será nil en el momento en que se accede dentro del cierre. Es importante elegir la opción adecuada según el contexto y garantizar un manejo seguro de la memoria en el código.
 */


//  VIPER (View, Interactor, Presenter, Entity, Router)

protocol ViewProtocol: class {   // View
    func displayData(_ data: String)
}

class View: ViewProtocol {       // VIEW
    var presenter: PresenterProtocol?

    func displayData(_ data: String) {
        print("Mostrando datos: \(data)")
    }
}

protocol InteractorProtocol {     // Interactor
    func fetchData()
}

class Interactor: InteractorProtocol {  // INTERACTOR
    weak var presenter: PresenterProtocol?

    func fetchData() {
        // Simulate fetching data from a data source
        let data = "Hola VIPER!"
        presenter?.dataFetched(data)
    }
}

protocol PresenterProtocol: class {      // Presenter
    func fetchData()
    func dataFetched(_ data: String)
}

class Presenter: PresenterProtocol {     // PRESENTER
    weak var view: ViewProtocol?
    var interactor: InteractorProtocol?

    func fetchData() {
        interactor?.fetchData()
    }

    func dataFetched(_ data: String) {
        view?.displayData(data)
    }
}

extension Presenter { // implementación de http://ericasadun.com/2015/04/30/swift-a-little-autoclosure-hacking/
    class func fetchData(_ funcion: @escaping @autoclosure () -> Void) {
        funcion()
    }
}

class Router {                              // Router
    static func createModule() -> View {
        let view = View()
        let presenter = Presenter()
        let interactor = Interactor()

        view.presenter = presenter
        presenter.view = view
        presenter.interactor = interactor
        interactor.presenter = presenter

        return view
    }
    
}

// Uso
let module = Router.createModule()
module.displayData("VIPER Example")
module.presenter?.fetchData()




// Generics y Structs se usa Element como T


enum BufferError: Error {
    case outOfBounds
}

struct Buffer<Element> {

    private var elementos = [Element]()

    mutating func add(_ item: Element) {
        elementos.append(item)
    }

    func get(idx: Int) throws -> Element {
        guard idx < elementos.count, idx >= 0 else {
            throw BufferError.outOfBounds
        }
        return elementos[idx]
    }

    //subscript(_ idx: Int) -> Element? {
    subscript(idx: Int) -> Element? {
        guard idx < elementos.count, idx >= 0 else {
            return nil
        }
        return elementos[idx]
    }
}

var stringBuffer: Buffer<String>? = nil
stringBuffer = Buffer<String>()
stringBuffer?.add("Hola ")
stringBuffer?.add("Mundo!")
try? stringBuffer?.get(idx: 0)

(0...3).forEach {
    do {
        let itemFromBuf = try stringBuffer?.get(idx: $0)
        print("item \($0) desde buffer es: \(itemFromBuf)")
    } catch {
        print("\(error) en índice \($0)")
    }
}


var strBuffer = Buffer<String>()
strBuffer.add("La vida ")
strBuffer.add("Te da Sorpresas ")
strBuffer.add("Sorpresas te da la vida")

(0..<4).forEach {
    do {
        guard let itemFromBuf = try? strBuffer.get(idx: $0) else {
            print("acaso SE LLAMA AQUÍ?")
            throw BufferError.outOfBounds
        }
        print("Cadena: \(itemFromBuf) en índice \($0)")
    } catch {
        print("\(error) error en \($0)")
    }
}

var intBuffer = Buffer<Int>()
intBuffer.add(10)
intBuffer.add(200)
intBuffer.add(3000)

(0..<4).forEach {
    if let itemFromBuf = intBuffer[$0] {
        print("item \($0) desde buffer es: \(itemFromBuf)")
    } else {
        print("Error en índice \($0)")
    }
}

var doubleBuffer = Buffer<Double>()
doubleBuffer.add(4.5)
doubleBuffer.add(4.2)
doubleBuffer.add(2.3)

(0..<4).forEach {
    guard let itemFromBuf = try? doubleBuffer.get(idx: $0) else {
        print("error de index \($0)")
        return
    }
    print("\(itemFromBuf) en \($0)")
}

(0..<3).forEach {
    let itemFromBuf = try? stringBuffer?.get(idx: $0)
    print("Cadena: \(itemFromBuf) en índice \($0) = \(String(describing: itemFromBuf))")
}


enum Ruta {
    case relativa(String)
    case absoluta(String)
}

extension Ruta {
    var esAbsoluta: Bool {
        if case .absoluta = self { return true }
        else { return false }
    }
}

extension Ruta {
    var esRelativa: Bool {
        if case .relativa = self { return true }
        else { return false }
    }
}

var ruta: Ruta = .relativa("lo es")

ruta.esAbsoluta
ruta.esRelativa

ruta = .absoluta("absolutita")
ruta.esAbsoluta
ruta.esRelativa


// Lo que llamábamos Listas Doblemente Encadenadas, aquí es bien simple

class CareLibro {
    let nombre: String
    var amigos = [CareLibro]()

    init(nombre: String) {
        self.nombre = nombre
        print("\(nombre) ha sido ingresado exitosamente a Carelibro")
    }
    deinit {
        print("\(nombre) ha retirado su cuenta de Carelibro")
    }
}


func creaStrongReference() {
    let ana: CareLibro = CareLibro(nombre: "Ana");
    let pepe: CareLibro = CareLibro(nombre: "Pepe")
    let juan: CareLibro = CareLibro(nombre: "Juan")

    ana.amigos = [juan, pepe]
    juan.amigos = [ana]
    pepe.amigos = [ana]
    print("La función \(#function) se ejecutó bien.")
}

creaStrongReference()




// Type Constraint Syntax 
/*
    func funcionCualquiera<T: algunaClase, U: algunProtocolo>(parT: T, parU: U) {
        // Algo de código
    }
 */

protocol ViewTypeReusable: class {
    static var idReusableDefault: String { get }
    static var nib: UINib { get }
}

extension ViewTypeReusable where Self: UIView {

    static var idRreusableDefault: String {
        return NSStringFromClass(self)
    }

    static var nib: UINib {
        let manojo = Bundle(for: Self.self)
        let nombreNib = NSStringFromClass(self).components(separatedBy: ".").last!
        let nib = UINib(nibName: nombreNib, bundle: manojo)

        return nib
    }
}

extension UITableView {

    func register<T: UITableViewCell>(_: T.Type) where T: ViewTypeReusable {
        register(T.nib, forCellReuseIdentifier: T.idReusableDefault)
    }
}

// class Cell: UITableViewCell, ViewTypeReusable {}



// MARK:  CODABLE


// creamos un Diccionario para convertirlo en JSON
let miJson: [[String: Any]] = [["nombre": "Jack", "apellido": "nicholson", "edad": 90], ["nombre": "Mario", "apellido": "Moreno", "edad": 99]]


let jsonData = try? JSONSerialization.data(withJSONObject: miJson, options: [])
let jsonObject = try? JSONSerialization.jsonObject(with: jsonData!, options: [])
let jsonDict = jsonObject as? [[String: Any]]
let actorNombre = jsonDict?[0]["nombre"] as? String // como viene de arreglo de diccionarios...
let actorEdad = jsonDict?[1]["edad"] as? Int // años de Mario Moreno
let jsonString = String(data: jsonData!, encoding: .utf8)

jsonDict?.forEach {
    if let nombre = $0["nombre"] as? String, let edad = $0["edad"] as? Int {
        print("\(nombre) tiene \(edad)")
    }
}

class ActorHolliwood {
    let nombre: String = ""
    let apellido: String = ""
    let edad: Int = 0
}

