//: Playground - noun: a place where people can play

import Foundation
import UIKit

var str = "Hello, playground"

////************** FORMA TRADICIONAL DE OBTENER DE LA WEB *************////

let htmlString = "<b>Hola</b> <i>mundo</i>"
let data = htmlString.data(using: String.Encoding.utf8)
let options: [String: Any] = [
    NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
    NSCharacterEncodingDocumentAttribute: String.Encoding.utf8.rawValue
]

do {
    let attributedString = try NSAttributedString(data: data!, options: options, documentAttributes: nil)
    print(attributedString)
} catch {
    print("Error al convertir HTML a NSAttributedString: \(error)")
}




var cadenaProcesar = "uno,dos,tres\ncuatro,cinco,seis\nsiete,ocho"

/**** C O M P O S I C I Ó N   D E   F U N C I O N E S ****/

func divideLineas(de texto: String) -> [String] {
    return texto.components(separatedBy: .newlines)
}

func creaLineas(desde lineas: [String]) -> [[String]] {
    return lineas.map { linea in
        linea.components(separatedBy: ",")
    }
}

func remueveFilasInvalidas(en filas: [[String]]) -> [[String]] {
    return filas.filter { fila in
        fila.count == 3
    }
}

creaLineas(desde: divideLineas(de: cadenaProcesar))

/// Composición de funciones
/// Tomemos una página del libro del programador funcional y usemos la composición de funciones.  Componiendo dos funciones arroja una nueva función, y se abren.  Es simple. El siguiente código crea un nuevo operador que podemos poner entre dos funciones y crea una nueva función.  Ignore el bit AdditionPrecedence por ahora.

infix operator ---> :AdditionPrecedence

func ---> <M, N, O> (
    MaN: @escaping (M) -> N,
    NaO: @escaping (N) -> O) -> (M) -> O {
        return { m in
            let n = MaN(m)
            let o = NaO(n)
            return o
        }
}

/// El nombre del operador de función es ---> y tiene tres parámetros: M, N y O. También tiene 2 parámetros que resultan ser cierres (p.e. funciones). El primer cierre convierte a M en N, y el segundo cierre convierte a N en O. El operador ---> retorna una nueva función que transforma a M en O y lo retorna.

let procesaCSV = divideLineas(de:) ---> creaLineas(desde:) ---> remueveFilasInvalidas(en: )

var filasValidas = procesaCSV(cadenaProcesar)


/// Notemos que el operador ---> es asociativo de izquierda, es decir, las funciones se forman en orden de izquerda-a-derecha.  Esta es la razón de usar AdditionPrecedence cuando se declara el operador. Tiene ---> la misma precedencia y asociatividad que el operador "+".


///*********** PERMITIENDO EFECTOS SECUNDARIOS *********///

/// Cómo podemos inspeccionar el valor de retorno de una función cuando se usa composición de funciones?  Una forma es agregar sentencias de logueo a la sfunciones que se crean, pero eso sólo funciona si puedes editar esas funciones, lo cual no siempre es el caso.  Hay una forma mejor.  Revisémosla:


func ---> <P, Q> (
    PaQ: @escaping (P) -> Q,
    efectoSecundario: @escaping (Q) -> Void) -> (P) -> Q {

    return { p in
        let q = PaQ(p)
        efectoSecundario(q) // se ejecuta, no devuelve nada????
        return q
    }
}

/// Esta sobrecarga de función del operador ---> da tratamiento especial a un caso especial.  Cuando la función en el lado derecho retorna Void, se asume que exista sólo para producir un efecto secundario, como loguear en la consola o guardar datos en un archivo.  En el mudno de la programación funcional, esto se considera una función "impura", porque no opera solamente con sus entradas, y por tanto puede tener efectos secundarios impredecibles.

/// Aquí está cómo poemos usar esta nueva versión de la función ---> para ejecutar logueo.


let procesaCSVLogueando = divideLineas(de:)
    ---> { print("líneas: \($0)") }
    ---> creaLineas(desde:)
    ---> { print("filas: \($0)") }
    ---> remueveFilasInvalidas(en:)
    ---> { print("filas válidas: \($0)") }

print("estooo")
filasValidas = procesaCSVLogueando(cadenaProcesar)
print("aquí")


////***************** ENCADENAMIENTO OPCIONAL ******************////


/// El operador de composición de funciones funciona bien con valores opcionales, desde que Optional<T> es un enum de Swift y puede usarse en una función genérica así como cualqueir otro tipo.  Pero sería mejor si hubiera soporte extra para trabajar con valores opcionales cuando se usa composición de función, similar al del encadenamiento opcional en Swift.  Por ejemplo cuenta.contactoEmergencia?.enviaAlerta() enviará sólo una alerta al contacto de emergencia si existiese.

/// Aquí hay una nueva variante del operador de composición que soporta encadenamiento opcional.  La función a la izquierda retorna un valor opcional, y la función a la erecha sólo se llamará si el valor no es nil.

infix operator --->? :AdditionPrecedence

func --->? <X, Y, Z> (
    XaY: @escaping (X) -> Y?,
    YaZ: @escaping (Y) -> Z?) -> (X) -> Z? {

    return { x in
        guard let y = XaY(x) else { return nil }
        let c = YaZ(y)
        return c
    }
}

// poniendo esto en acción

func url(delSitio empresa: String) -> URL? {
    let principales = [ "APPL": "http://www.apple.com",
                        "ORAC": "http://www.oracle.com",
                        "GOGL": "http://www.google.com"]
    guard let ruta = principales[empresa] else { return nil }
    return URL(string: ruta)
}

func datos(de url: URL) -> Data? {
    return try? Data(contentsOf: url)
}

func htmlConAttrs(con datos: Data) -> NSAttributedString? {
    let opciones: [String: Any] =
        [ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
          NSCharacterEncodingDocumentAttribute: String.Encoding.utf8.rawValue ]
    return try? NSAttributedString(data: datos,
                                   options: opciones,
                                   documentAttributes: nil)
}

let htmlAttrParaEmpresa = url(delSitio:) --->? datos(de:) --->? htmlConAttrs(con:)

let html = htmlAttrParaEmpresa("GOGL")

let htmlStr = "<html><h1>Hola</h1><h2>Mundo</h2></html>"


/// Si alguna de las funciones retorna nil, no se llama ninguna de las funciones subsecuentes.  Esta es una adición más veloz.  Recuerde, los operadores ---> y --->? pueden usarse ambos al formar sentencias más grandes.



///************* PASAR MÚLTIPLES ARGUMENTOS ******************///
/// Todos los ejemplos han tenido un solo parámetro, pero es posible usar funciones con parámetros múltiples.  Una forma de hacerlo es abrir un llamado dentro de un cierre como se muestra en el siguiente ejemplo.



func dameHora(en fecha: Date) -> Int {
    return Calendar.current.component(.hour, from: fecha)
}

func esHora(_ hora: Int, entre inicial: Int, y final: Int) -> Bool {
    return (inicial...final).contains(hora)
}

let esJornada = dameHora(en:) ---> { esHora($0, entre: 9, y: 17) }

let now = Date()

let estaTrabajando = esJornada(now)




