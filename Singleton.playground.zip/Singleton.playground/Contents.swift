//: Playground - noun: a place where people can play

import UIKit


var str = "Hello, playground"


public final class Singleton {

    private static let _shared = Singleton()
    private init() { }

    public static func shared() -> Singleton {
        print("Accessed")
        return _shared
    }

    private let accessQueue = DispatchQueue(
        label: "org.sadun.singletonIsolation",
        attributes: [.concurrent])

    private var _valor: Int = 0

    // Aseguramos lectura atómica de _valor
    public var value: Int {
        return accessQueue.sync {
            return _valor
        }
    }

    // Ensure atomic change to _value
    public func next() -> Int {
        return accessQueue.sync(flags: [.barrier]) {
            _valor += 1;
            return _valor
        }
    }
}

Singleton.shared().value
Singleton.shared().value
Singleton.shared().next()
Singleton.shared().next()
