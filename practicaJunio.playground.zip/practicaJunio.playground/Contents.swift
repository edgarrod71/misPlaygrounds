//: Playground - noun: a place where people can play

import PlaygroundSupport
import UIKit
import Foundation
import CoreGraphics

var Str:String!
var DD:Double!
var II:Int?
var BB:Bool?
var optionalName: String?



// Nota sobre Optionals, para entender los opcionales veamos...
//      if Assigned(Str) then ...  // Str podría ser nil
// en Swift se entiende que una variable o cualquier tipo de dato puede o no contener un valor inicial.  (Podría entenderse que todo dato es puntero?)
//      var Str: String = "Hola mundo"  // Tiene valor
//      var Str: String = ""            // Vacío
//      var Str: String?  // nil        // No tiene valor o sea nil

//      var II: Int = 40_000    // tiene valor
//      var II: Int = 0         // vacío (0 es un valor)
//      var II: Int?            // no tiene valor o sea nil

//      var Arr: [Double] = [0.0]   // tiene 1 valor, 0.0
//      var Arr: [Double] = []      // vacío  ( var Arr = [Double]() )
//      var Arr: [Double]?          // no tiene valor o sea nil

//  ! significa Caja Abierta (Unwrapped) y, ? significa Caja Cerrada (Wrapped)

//      "Swift no introdujo Optionals, introdujo Non-Optionals". @ZevEisenberg

// SoSpEcHo que Swift maneja todo como punteros en Stack, es decir, si se pone
//      var II: Int = 100_000 // se podría entender en pascal así:

//      var II: ^Integer = nil;
//      II^ := 100000;  // ya no es nil y lo abre a fuerza pues da error, debería usarse getmem(II, sizeof(Integer)), al final liberarlo con freemem(II) pero todo esto va en contra de la optimización, a no ser que Swift lo haya hecho internamente por el usuario.


// OJO: Continue, Break, Trhow

let nums: [Int] = [1, 2, 3, 4, 5, 10, 11, 13, 20]

// Ejemplo de Continue
var totImpares = 0
for N in nums {
    if N % 2 == 0 { continue } // si encuentra un par, siga
    totImpares += N
}
totImpares

var posicion = 0
var numBuscar = 10
for (index, N) in nums.enumerated() {
    if N == numBuscar { posicion = index; break }
}
posicion

let letras: [Character] = ["m", "u", "r", "c", "i", "e", "l", "a", "g", "o"]

for elemento in zip(letras, nums) {  // WOW, viva ZIP
    print(elemento)
}


enum Errorcito: Error {
    case rangoInvalido(String)
    case sinRaiz(String)
}
var Arr = [0.0]
Arr = []


///********///**********///***********

let album = "Red"
let albumes = ["Reputation", "Red", "1989"]
if let position = albumes.index(of: album) {
    Str = "Found \(album) at position \(position)."
}
let lineasA = albumes.split(separator: " ")

let progsTV = ["Ted Lasso": "Netflix", "Bob Esponja": "Nickelodeon", "South Park": "Comedy"]
let favorito = progsTV["Lassy"] ?? "South Parque"
let lineasB = progsTV.split(whereSeparator: { (key: String, value: String) -> Bool in
    return key.contains(":")//key.hasSuffix(":")
})


struct Libro {
    let ISBN: Int
    let titulo: String
    let autor: String?
}

var B1: Libro? = nil
B1 = Libro(ISBN: 123456, titulo: "100 años", autor: nil)
let Au = B1?.autor?.capitalized ?? "nada"

/* B1[1...3] = [Libro(ISBN: 123, titulo: "Padre Rico", autor: "Kiyosaki"),
             Libro(ISBN: 234, titulo: "Toque Midas", autor: "Trump"),
             Libro(ISBN: 345, titulo: "Burrito Sabanero", autor: nil)]
// No se puede asignar directamente a un rango en Swift
// Se debe modificar el código para asignar a elementos individuales del arreglo */
var libros: [Libro] = [Libro(ISBN: 999, titulo: "Feliz Navidad", autor: "Santa")]
libros.append(Libro(ISBN: 123, titulo: "Padre Rico", autor: "Kiyosaki"))
libros.append(Libro(ISBN: 234, titulo: "Toque Midas", autor: "Trump"))
libros.append(Libro(ISBN: 345, titulo: "Burrito Sabanero", autor: nil))

for (index, L) in libros.enumerated() { // enumerated bota index
    print("\(L.titulo) escrito por \(L.autor) índice: \t \(index)")
}


// var hemeroteca = Set<Libro> = [] // esto da error, hay que hacer a Libro hashable:

extension Libro: Hashable {
    var hashValue: Int {
        return ISBN
    }
    static func ==(lhs: Libro, rhs: Libro) -> Bool {
        return lhs.ISBN == rhs.ISBN
    }
}

var hemeroteca = Set<Libro>() // Set<Libro> = []


let names = ["Vincent": "van Gogh", "Pablo": "Picasso", "Claude": "Monet"]
let surnameLetter = names["Vincent"]?.unicodeScalars

class DriversLicense {
    var puntos: Int = 0
}

class Conductor {
    var licencia: DriversLicense? // Si no tiene ? chilla porque Conductor no tiene inicializadores
}

let fer = Conductor()
if let licencia = fer.licencia {
    "tiene! \(licencia.puntos) puntos"
} else {
    "no tiene licencia"
}

let puntosLicencia = fer.licencia?.puntos
if let puntos = puntosLicencia {
    "tiene! \(puntos) puntos"
} else {
    "sigue sin tener licencia"
}

let puntillas = 4
//fer.licencia?.puntos = puntillas


var catalogo = ["Honda": (minPrecio: 1000, maxPrecio: 1_000_000)]
let precio = catalogo["Honda"]!.maxPrecio
var honda = catalogo["Honda"]




func calcularPrimos(limit: Int) -> [Int] {
    var primos = [Int]()
    for i in 2...limit {
        var esPrimo = true
        for j in 2..<i {
            if i % j == 0 {
                esPrimo = false
                break
            }
        }
        if esPrimo {
            primos.append(i)
        }
    }
    return primos
}

let primes = calcularPrimos(limit: 100)

//for prime in primes {
//    print(prime)
//}

let credentials = ["twostraws", "fr0sties"]
let lowercaseUsername = credentials.first?.lowercased()


let shoppingList = ["eggs", "tomatoes", "grapes"]
let firstItem = shoppingList.first?.appending(" are on my shopping list")

let captains: [String]? = ["Archer", "Lorca", "Sisko"]
let lengthOfBestCaptain = captains?.last?.characters.count
II = lengthOfBestCaptain!


//// Checkpoint 9  ///////  // 20 de junio de 2023
// pide función que acepte un arreglo Opcional de enteros y retorne uno de sus valores de forma aleatoria.  Si el arreglo falta (nil) o está vacío, debe devolver un aleatorio de 1...100.  Todo esto en una sola línea de código
func randomArrInt(valores: [Int]?) -> Int { if let valores = valores, !valores.isEmpty { return valores[Int(arc4random_uniform(UInt32(valores.count)))] } else { return Int(arc4random() % 100) + 1 }}

randomArrInt(valores: [2, 3, 5, 4, 9, 1, 8, 6, 7])
randomArrInt(valores: nil)

func randomArrInt2(valores: [Int]?) -> Int? { guard let valores = valores, !valores.isEmpty else { return nil ?? (Int(arc4random() % 100) + 1) }; return valores[Int(arc4random_uniform(UInt32(valores.count)))] }

randomArrInt2(valores: [2, 3, 5, 4, 9, 1, 8, 6, 7])
randomArrInt2(valores: nil)



//////// notas sobre SETS ////////////

var colores: Set = ["amarillo", "azul", "rojo"]
colores.count
colores.underestimatedCount
let colorcito = colores.sorted()[2]

colores
var idx = 0
var azul: String

for C in colores {
    if idx == 2 {
        azul = C
        break;
    }
    idx += 1
}

let elemAzul = colores.index(of: "azul")
let numAzul = elemAzul!
colores[elemAzul!]

var Cade = String()


func isDouble(ArrStr: String...) -> Bool {
    for A in ArrStr {
        guard let _:Double = Double(A) else {
            return false
        }
    }
    return true
}

isDouble(ArrStr: "1,0", "2.2")


enum Separadores1: Hashable {
    case tem, mon, lon
    
    func describe() -> String {
        switch self {
        case .tem:
            return "Temperatura"
        case .mon:
            return "Moneda"
        default:
            return "Longitud"
        }
    }
}

Separadores1.lon.hashValue

//for hash in 0...Separadores1.lon {
//    print("Valor de hash para \(hash.): \(hash)")
//}

let dic1: Dictionary<Int, String> = [0: "Temperatura", 1: "Moneda", 2: "Longitud"]

let Arr1 = ["Temperatura", "Moneda", "Longitud"]

Arr1[0]
dic1[0]


var color: UIColor?

if #available(iOS 11, *) {
    // Use iOS 11 APIs on iOS
    // color = UIColor(named: "green_color_from_asset_folder")
} else {
    // Fall back to earlier iOS APIs
    color = UIColor.green
}

// FUNCIONES CON FECHAS

func fechaConAño(_ año: Int, mes: Int = 0, dia: Int = 0) -> Date {
    let calendario = Calendar(identifier: .gregorian)
    var componentes = DateComponents()
    componentes.year = año

    let hoy = Date(); var _mes, _dia: Int
    _mes = mes == 0 ? calendario.component(.month, from: hoy) : mes
    _dia = dia == 0 ? calendario.component(.day, from: hoy) : dia

    componentes.month = _mes
    componentes.day = _dia
    // componentes.hour = 12
    return calendario.date(from: componentes)!
}

var nacimiento = fechaConAño(1971, dia: 26)

func fechaDeMañanaRelativaAHoy(_ fecha: Date) -> Date {
    let calendario = Calendar(identifier: .gregorian)
    var componentes = DateComponents()
    componentes.day = 1
    return calendario.date(byAdding: componentes, to: fecha)!
}

let formatter = DateFormatter()
formatter.dateFormat = "dd/MM/yyyy" // OJO: MM es para mes, mm es para minutos
let nacidoEn = formatter.date(from: "26/10/1971")

nacimiento = fechaDeMañanaRelativaAHoy(nacidoEn!)

func finDeSemana(_ fecha: Date) -> Date {
    let calendario = Calendar(identifier: .gregorian)
    let componentesFecha = Calendar.current.dateComponents([.weekday], from: fecha)
    let diasFaltan = 7 - (componentesFecha.weekday ?? 0)
    var componentes = DateComponents()
    componentes.day = diasFaltan
    return calendario.date(byAdding: componentes, to: fecha)!
}

nacimiento = finDeSemana(nacidoEn!) // Yo nací un martes, así que el viernes es 30

