import UIKit
import PlaygroundSupport

extension ClosedRange where Bound: FloatingPoint {
    var randy: Bound {
        let rango = self.upperBound - self.lowerBound
        let result = (Bound(arc4random()) / Bound(UINT_FAST32_MAX)) * rango + self.lowerBound
        return result
    }
}

extension Range where Bound: FloatingPoint {
    var randy: Bound {
        let rango = self.upperBound - self.lowerBound
        let result = (Bound(arc4random()) / Bound(UINT_FAST32_MAX)) * rango + self.lowerBound
        return result
    }
}

extension Collection {
    public var random: Self._Element {
        if let idxInicial = self.startIndex as? Int {
            let inicio = UInt32(idxInicial)
            let fin = UInt32(self.endIndex as! Int)
            return self[Int(arc4random_uniform(fin - inicio) + inicio) as! Self.Index]
        }
        var generator = self.makeIterator()
        var cuenta = arc4random_uniform(UInt32(self.count as! Int))
        while cuenta > 0 {
            generator.next()
            cuenta -= 1
        }
        return generator.next() as! Self._Element
    }

}

var texto = "edgarrod71@gmail.com"
let atributos: [String: Any] = [
    NSForegroundColorAttributeName: UIColor.red,
    NSFontAttributeName: UIFont.boldSystemFont(ofSize: 38)]
let almacenaje = NSTextStorage(string: texto, attributes: atributos)
let tamTexto = almacenaje.size()

/// Creamos algunas variables que afectan la vista
let cuentaV: CGFloat = 10
var desplazaH: CGFloat = 40
let mitadV = tamTexto.height * (cuentaV - 1) / 2 // = vista.center.y - almacenaje.size().height / 2

/// Construimos un área para la vista sobre la cual vamos a animar
let tamVista = CGSize(
    width: tamTexto.width + 2 * desplazaH, // padding de 40 pts
    height: tamTexto.height * cuentaV) // string height * count = view height

/// ubicamos una tupla con 2 posiciones verticales de donde saldrán las letras, arriba y abajo
var origenY: (CGFloat, CGFloat) = (-100, tamVista.height + 100)

/// construimos la vista usando tamVista
let vista = UIView(frame: CGRect(origin:.zero, size: tamVista))
vista.backgroundColor = UIColor.black
vista.clearsContextBeforeDrawing = true


/// El administrador de diseño asigna geometría al glifo
let layoutMgr = NSLayoutManager()
layoutMgr.addTextContainer(NSTextContainer(size: CGRect.infinite.size))
layoutMgr.textStorage = almacenaje

let cuentaGlifos = Int(layoutMgr.numberOfGlyphs)

/// Toma caracteres individuales con atributos
let letrasConAtributos = (0 ..< cuentaGlifos)
    .map({ almacenaje.attributedSubstring(from: NSMakeRange($0, 1)) })

/// Colores bonitos entre el 35% y 75% del brillo
var randomColor: UIColor {
    var random: CGFloat {
        return (0.35...0.75).randy
    }
    return UIColor(red: random, green: random, blue: random, alpha: 1)
}

/// Animamos cada caracter en su posición
let format = UIGraphicsImageRendererFormat()

letrasConAtributos.enumerated().forEach({ (idx, char) in
    let coloredChar: NSMutableAttributedString = char.mutableCopy() as! NSMutableAttributedString
    coloredChar.addAttribute(NSForegroundColorAttributeName, value: randomColor, range: NSMakeRange(0, 1))
    let chSize = char.size(); defer { desplazaH += chSize.width }

    /// Crea una imagen por caracter
    let renderer = UIGraphicsImageRenderer(size: chSize, format: format)
    let characterImage = renderer.image { _ in
        coloredChar.draw(at: .zero) /// dibujamos el String dentro del renderer
    }

    /// Animación desde p1 a p2
    let kit: CGFloat = (-400...400).randy
    let ceroUno = (0...1).random

    /// Esto es bárbaro, analízaloi
    /// Invocamos origenY
    let elementoDeseado: CGFloat = withUnsafePointer(to: &origenY) {
        $0.withMemoryRebound(to: CGFloat.self, capacity: MemoryLayout.size(ofValue: origenY)) {
            $0.advanced(by: ceroUno).pointee
        }
    }

    let arribaAbajo: CGFloat = ceroUno == 0 ? origenY.0 : origenY.1
    let p1 = CGPoint(x: desplazaH + kit, y: elementoDeseado)
    let p2 = CGPoint(x: desplazaH, y: mitadV)
    let areaDestino = CGRect(origin: p2, size: chSize)

    /// Construye UIImageView
    let characterView = UIImageView(frame: CGRect(origin: p1, size: chSize))
    characterView.image = characterImage; characterView.alpha = 0.0 // inicializamos en ceros para que se vea como fade con la animación
    // characterView.transform = CGAffineTransform(rotationAngle: CGFloat.pi / 2)
    let aumento: CGFloat = (1..<2.2).randy

    characterView.transform = CGAffineTransform(scaleX: aumento, y: aumento)
    vista.addSubview(characterView)

    /// Se anima, con una demora de 0.1s entre cada uno, incremente esto para disminuir la animación
    UIView.animate(
        withDuration: 3.5, // tiempo de transición completo
        delay: Double(idx) * 0.05, // retraso entre letras
        usingSpringWithDamping: 0.6, // amortiguación
        initialSpringVelocity: 0.5, // velocidad inicial
        options: [],
        animations: {
            characterView.frame = areaDestino;
            characterView.alpha = 1.0;
            ///characterView.transform = CGAffineTransform(rotationAngle: CGFloat.pi / 3);
            characterView.transform = CGAffineTransform(scaleX: 1.1, y: 1.5) // Aplica una escala de 1.5 en ambos ejes
        },
        completion: nil)
})

PlaygroundPage.current.liveView = vista
PlaygroundPage.current.needsIndefiniteExecution = true
