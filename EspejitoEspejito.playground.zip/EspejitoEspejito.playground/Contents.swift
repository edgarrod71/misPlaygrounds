//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

struct Beisbolista {
    let nombre: String
    let edad: Int
    var salario: Double
    var extranjero: Bool
    init(nombre: String, edad: Int, salario: Double, extranjero: Bool = false) {
        self.nombre = nombre; self.edad = edad; self.salario = salario; self.extranjero = extranjero;
    }
}

let babeR = Beisbolista(nombre: "babe", edad: 40, salario: 5000.0, extranjero: true)
var rentE = Beisbolista(nombre: "Edgar", edad: 44, salario: 9_000.0)
let fercH = Beisbolista(nombre: "Edgar", edad: 44, salario: 9000.00, extranjero: true)

extension Beisbolista: Equatable {
    public static func ==(lhs: Beisbolista, rhs: Beisbolista) -> Bool {
        guard lhs.nombre == rhs.nombre else { return false }
        guard lhs.edad == rhs.edad else { return false }
        guard lhs.salario == rhs.salario else { return false }
        guard lhs.extranjero == rhs.extranjero else { return false }
        return true
    }
}

var sonLoMismo = babeR == rentE

rentE.extranjero = true
sonLoMismo = rentE == fercH



public func adoptEquatable(_ sujeto: Any) {
    let espejito = Mirror(reflecting: sujeto)

    let nombreTipo: String = {
        let nombreCompletoT = String(reflecting: espejito.subjectType)
        let tipoPartes = nombreCompletoT.components(separatedBy: ".")
        let tienePrefijoMod = tipoPartes.count > 1
        return tienePrefijoMod
            ? tipoPartes.dropFirst().joined(separator: ".")
            : nombreCompletoT
    }()

    let nombresPropiedad = espejito.children.map({ $0.label ?? "(vacío)" })
    nombresPropiedad

    // Asociamos niveles de indentación con cada pieza de código
    typealias GrupoPlantilla = [(Int, String)]
    let gruposPlantillas: [GrupoPlantilla] = [
        [(0, "extension \(nombreTipo): Equatable {")],
        [(1, "public static func ==(lhs: \(nombreTipo), rhs:\(nombreTipo)) -> Bool {")],
        nombresPropiedad.map { (2, "guard lhs.\($0) == rhs.\($0) else { return false }") },
        [(2, "return true")],
        [(1, "}")],
        [(0, "}")]
    ]

    // Aplica indentación a cada línea de código mientras se aplana la lista.
    let indenta = "\t"
    let lineasDeCodigo = gruposPlantillas.flatMap { grupoPlantilla -> [String] in
        return grupoPlantilla.map { (nivelIndentado: Int, codigo: String) -> String in
            let indentacion = String(repeating: indenta, count: nivelIndentado)
            return "\(indentacion)\(codigo)"
        }
    }
    // Aplica indentación a cada línea de código mientras
    let codigoFuente = lineasDeCodigo.joined(separator: "\n")
    print(codigoFuente)
}

adoptEquatable(babeR)






