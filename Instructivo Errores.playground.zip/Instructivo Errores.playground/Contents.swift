//: Playground - noun: a place where people can play
import PlaygroundSupport
import UIKit

var str = "Hello, playground"

let view = UIView()

class MiViewController: UIViewController {
    override func LoadView() {
        let vista = UIView()
        vista.backgroundColor = .white
        self.view = vista
    }
}

let controlador = MiViewController()
PlaygroundPage.current.liveView = controlador
controlador.view
PlaygroundQuickLook.sound("ding")


