//: Playground - noun: a place where people can play
import UIKit
import PlaygroundSupport

public struct Nodo: CustomStringConvertible {
    public var hijo: [Nodo] = []
    public var clave = ""
    public var valorHoja: String?  = nil
    public var valorHojaLimpia: String? {
        if var leafValue = valorHoja {
            leafValue = (leafValue as NSString).replacingOccurrences(of: "\n", with: "")
            leafValue = (leafValue as NSString).replacingOccurrences(of: "\\s+", with: " ", options: [.regularExpression], range: NSMakeRange(0, leafValue.characters.count))
            if !leafValue.isEmpty { return leafValue }
        }
        return nil
    }
    public var atributos: [NSObject: AnyObject]? = nil
    public var description: String {return "Key: \(clave) Valor: \(valorHoja) Atributos: \(atributos) Hijos: \(hijo)"}
}

public extension Nodo {

    public func muestraNodo(_ indent: Int = 0) {
        let indentation = String(repeating: " ", count: indent)
        Swift.print(indentation)
        Swift.print("Key: \(clave) ")
        if let leafValue = valorHojaLimpia { Swift.print("Valor: [\(leafValue)] ") }
        if let attributes = atributos {
            if !(attributes.keys).isEmpty {
                print("Atributos: ", terminator: "")
                debugPrint(attributes)
            }
        }
        Swift.print("")
        for child in hijo { child.muestraNodo(indent + 4) }
    }
}

public extension Nodo {

    public var keys: [String] { return hijo.map({ $0.clave }) }

    public func childrenWithKey(_ keyString: String) -> [Nodo]{
        return hijo.filter({$0.clave == keyString})
    }

    public func childWithKey(_ keyString: String) -> Nodo? {
        return childrenWithKey(keyString).first
    }
}

public final class MyXMLParser: NSObject, XMLParserDelegate {
    var stack: [Nodo] = []

    public static func parse(xmlString: String) -> Nodo? {
        let instance = MyXMLParser()
        return instance.parseXMLString(xmlString)
    }

    public static func parse(xmlData: Data) -> Nodo? {
        let instance = MyXMLParser()
        return instance.parseXMLData(xmlData)
    }

    public func parseXMLData(_ xmlData: Data) -> Nodo? {
        stack.append(Nodo())
        let parser = Foundation.XMLParser(data: xmlData)
        parser.shouldResolveExternalEntities = true
        parser.delegate = self
        parser.parse()
        let parent = stack.last
        return parent?.hijo.last
    }

    public func parseXMLString(_ xml: String) -> Nodo? {
        if let data = xml.data(using: String.Encoding.utf8, allowLossyConversion: false) {
            return parseXMLData(data)
        }
        return nil
    }

    public func parser(_ parser: XMLParser, didStartElement nombreElemento: String,
                       namespaceURI: String?, qualifiedName qName: String?,
                       attributes dictAtributos: [String: String] = [:]) {
        var nodo = Nodo()
        nodo.clave = nombreElemento
        nodo.atributos = dictAtributos as [NSObject : AnyObject]?
        stack.append(nodo)
    }

    public func parser(_ parser: XMLParser, didEndElement elementName: String,
                       namespaceURI: String?, qualifiedName qName: String?) {
        let nodo = stack.removeLast()
        var padre = stack.removeLast()
        padre.hijo.append(nodo)
        stack.append(padre)
    }

    public func parser(_ parser: XMLParser, foundCharacters cadena: String) {
        if !stack.isEmpty {
            var nodo = stack.removeLast()
            if let leafValue = nodo.valorHoja {
                nodo.valorHoja = leafValue + cadena
            } else {
                nodo.valorHoja = cadena
            }
            stack.append(nodo)
        }
    }
}
