//: Playground - noun: a place where people can play
import UIKit

var str = "Hello, playground"

public final class Unica {

    private static let _unica = Unica()

    private init() {}

    public static func comparte() -> Unica {
        print("compartida")
        return _unica
    }

    private let colaAcceso = DispatchQueue(
        label: "com.fercho.durango",
        attributes: [.concurrent])

    private var _valor: Int = 0

    public var valor: Int {
        return colaAcceso.sync {
            return _valor
        }
    }

    public func siguiente() -> Int {
        return colaAcceso.sync(flags: [.barrier]) {
            _valor += 1
            return _valor
        }
    }
}

Unica.comparte().valor
Unica.comparte().valor
Unica.comparte().siguiente()
Unica.comparte().siguiente()