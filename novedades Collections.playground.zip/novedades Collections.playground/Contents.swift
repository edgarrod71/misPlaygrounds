import Foundation

extension Collection where Indices.Iterator.Element: Equatable,
                           Index == Self.Indices.Iterator.Element {

    /// Retorna valor opcional para el valor indexado de forma segura y nil si el índice sale de los límites
    public subscript(seguro indice: Self.Index) -> Self.Iterator.Element? {
        guard indices.contains(indice) else { return nil }
        return self[indice]
    }

    /// Retorna objetos tomados de forma segura en índices deseados existentes.
    public func objetos(tomadosEn indiceDeseado: Self.Index...) -> [Self.Iterator.Element] {
        return indiceDeseado.flatMap({ self[seguro: $0] })
    }

    /// Retorna objetos hallados de forma segura en índices deseados existentes.
    public func objetos(seguroDe indiceDeseado: Self.Index...) -> [Self.Iterator.Element?] {
        return indiceDeseado.map({ self[seguro: $0] })
    }
}

extension Collection {
    /// Retorna objetos hallados en índices deseados existentes. No se garantiza seguridad.
    public func objetos(en indiceDeseado: Self.Index...) -> [Self.Iterator.Element] {
        return indiceDeseado.map({ self[$0] })
    }
}
/*
extension Collection {
    /// Retorna objetos hallados en índices de subíndices deseados.  No se garantiza seguridad.
    subscript(uno idx1: Self.Index, _ idx2: Self.Index, _ rest: Self.Index...) -> [Self.Iterator.Element] {
        return [self[idx1], self[idx2]] + rest.map({ self[$0] })
    }
}
*/
extension Collection {
    subscript(_ idx1: Self.Index, _ indiceDeseado: Self.Index...) -> [Self.Iterator.Element] {
        return [self[idx1]] + indiceDeseado.map({ self[$0] })
    }
}

let arreglo = ["dejame", "robarte", "beso", "que", "llegue", "hasta", "el", "alma"]
/// Usando el subíndice "seguro"
let valorArr = arreglo[seguro: 2]
let porFuera = arreglo[seguro: 10]

/// Usando la función flatMap (tomadosEn:)
let valorTomE = arreglo.objetos(tomadosEn: 4, 10)

/// Usando la función map (seguroDe:)
let valorSeg = arreglo.objetos(seguroDe: 3, 5)

/// Usando la función map (En:)
let valorEn = arreglo.objetos(en: 2, 1, 4)

/// Usando la función subíndice con 3 parámetros
let tresObjetos = arreglo[3, 6, 7]

/// Usando mi función subíndice con n parámetros
let anyObjetos = arreglo[2, 4, 6, 0]
