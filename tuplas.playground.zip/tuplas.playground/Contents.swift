//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"




/// *******   T U P L A S  +++++++++++++

let tuplaVacia: ()? = ()  // No tiene utilidad, sólo es curioso
let tuplaSimple = (valorUnico: 1.0)
let TV = tuplaSimple
let recur = (uno: "hola", dos: true, tres: (cua: 4, cin: 5.0))
recur.tres.cin
type(of: recur)

let recur2: (String, Bool, (Int, Double)) = (uno: "hola", dos: true, tres: (cua: 4, cin: 5.0))
recur2.2.1  // cuando se pone la definición de tipo los nombres internos de la tupla desaparecen

let (uno, dos, (cua, cin)) = recur2
uno
cin

let ciudades = ["Santander":"Bucaramanga", "Magdalena":"Santa Marta", "Antioquia":"Medellín", "Valle":"Cali", "Atlántico":"Barranquilla"]

for (dpto, capital) in ciudades {
    // print("\(dpto), \t \(capital)")
}

let (_, _, soloNums) = recur2 // cuando sólo nos interesa el último de la tupla
soloNums.1

var (siete, ocho, nueve) = (7, 8, 9) // inicializar variables en una sola línea
nueve

(ocho, nueve) = (nueve, ocho) // intercambiar valores es más simple
ocho  // es el nuevo nueve (9)

let tupParam = (n: 1_000, s: "hola", b: true)

func trabajaTupla(tupla: (num: Int, str: String, bool: Bool)) -> (cad: String, bull: Bool, cant: Int) {
    return (tupla.str, tupla.bool, tupla.num)
}

var tupResult: (String, Bool, Int) = ("", false, 0)
tupResult.2

// desde Swift 3 quitaron el poder agregar como parámetro a una tupla
tupResult = trabajaTupla(tupla: (tupParam.n, tupParam.s, tupParam.b))
tupResult.2


func transformar(coords:(X: Double, Y: Double, Z: Double)...) -> [(x: Double, y: Double, z: Double)] {
    return coords.map{($0.X, $0.Y * 2, $0.Z)}
}

let TT = transformar(coords: (1.0, 2.0, 1.5), (2.0, 3.0, 4.0)) // retorna [(1.0, 4.0, 1.5), (2.0, 6.0, 4.0)]
TT[1].y  // por xtraña razón el etiquetado regresa


var diasLaborales1:[Int] = [1, 2, 3, 4, 5]
var diasLaborales2:(lun: Int, mar: Int, mié: Int, jue: Int, vie: Int, sáb:Int, dom:Int) = (1, 2, 3, 4, 5, 6, 7)
diasLaborales2.sáb


