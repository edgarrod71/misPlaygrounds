import UIKit
import PlaygroundSupport

func dibujeSeguro(en contexto: UIGraphicsImageRendererContext,
              applying actions: () -> Void) {
    contexto.cgContext.saveGState()
    actions()
    contexto.cgContext.restoreGState()
}

let π = CGFloat(Double.pi)
let tamaño = CGSize(width: 400, height: 400)
let renderizador = UIGraphicsImageRenderer(size: tamaño)


// Activamos Interlineado (kerning)

let font = UIFont(name: "Helvetica-BoldOblique", size: 24.0) ?? UIFont.boldSystemFont(ofSize: 24.0)
let attributos: [String: Any] = [
    NSFontAttributeName: font,
    NSForegroundColorAttributeName: UIColor.yellow,
    NSBackgroundColorAttributeName: UIColor.darkGray,
    NSKernAttributeName: 6
]
let cadenaAtributos = NSTextStorage(string: "0123456789ABCDE", attributes: attributos)

let CC = cadenaAtributos.length

// Textkit layout (diseño de kit de texto)
// Un NSLayoutManager maneja y contiene un espacio (NSTextContainer) para el texto (NSTextStorage) con atributos definidos en un diccionario [String: Any].
let contenedor = NSTextContainer(size: CGSize(width: .max, height: .max))
let manager = NSLayoutManager()

manager.addTextContainer(contenedor) // agrega el NSTextContainer
manager.textStorage = cadenaAtributos // asigna el texto con atributos NSTextStorage

let anchoPleno = manager.boundingRect(forGlyphRange: NSMakeRange(0, CC), in: contenedor).width


let letras = Array(0...10).lazy /// Use lazy y evite cálculos innecesarios al usar map y filter
    .map({ NSMakeRange($0, 1) })

/// understanding my code...
let letrasNumies = Array(0...5)
    .map { (nume: $0, alfabetus: cadenaAtributos) }
letrasNumies[0].alfabetus // Alfabetooooo
let rangoLetrasNumies = Array(0...3)
    .map { (id: $0, abecede: cadenaAtributos.attributedSubstring(from: NSMakeRange($0, 1))) }

letras[10].toRange()!.lowerBound // 10
cadenaAtributos.attributedSubstring(from: NSMakeRange(10, 1)) // K
manager.boundingRect(forGlyphRange: NSMakeRange(10, 1), in: contenedor).width // 34.30078125
/// hope I understood ;)

let letrasConAnchuras = Array(0 ..< CC) //.lazy
    .map({ NSMakeRange($0, 1) }) // $0 para armar el rango en from: de letra:
    .map({ (letra: cadenaAtributos.attributedSubstring(from: $0), // <-- aquí
            ancho: manager.boundingRect(forGlyphRange: $0, in: contenedor).width) })

letrasConAnchuras[10].letra


var tamañoConsumido: CGFloat = 0

let imagen = renderizador.image { contexto in
    type(of:contexto)
    /// comenzamos ajustando el origen del contexto, esto afecta todas las operaciones subsecuentes
    let bounds = contexto.format.bounds
    let (mitadX, mitadY) = (bounds.midX, bounds.midY)
    contexto.cgContext.translateBy(x: mitadX, y: mitadY)

    /// Desplazamiento a la mitad del primer caracter
    let primeraMitad = letrasConAnchuras.first!.ancho / 2.0
    let theta = 2 * π * primeraMitad / anchoPleno
    contexto.cgContext.rotate(by: -theta)

    /// Fijamos el radio a dibujar
    let r: CGFloat = 180

    // Draw each letter proportionally
    for (letra, tamañoLetra) in letrasConAnchuras {
        let mitadAncho = tamañoLetra / 2.0
        tamañoConsumido += mitadAncho;
        /// defer se asegura que se pueda ejecutar sí o sí.
        defer { tamañoConsumido += mitadAncho }
        dibujeSeguro(en: contexto) {
            // Rotamos el contexto
            let theta = 2 * π * tamañoConsumido / anchoPleno
            contexto.cgContext.rotate(by: theta)
            /// Trasladamos hasta el borde del radio y movemos a la izquierda hasta la mitad del ancho de la letra.
            contexto.cgContext.translateBy(x: -mitadAncho, y: -r)
            letra.draw(at: .zero)
        }
    }
}
