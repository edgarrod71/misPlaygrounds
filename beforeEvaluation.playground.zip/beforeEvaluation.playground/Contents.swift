import PlaygroundSupport
import UIKit
import Foundation
import CoreGraphics

var Str:String!
var DD:Double!
var II:Int?
var BB:Bool?
var optionalName: String?

// Nota sobre Optionals, para entender los opcionales veamos...
//      if Assigned(Str) then ...  // Str podría ser nil
// en Swift se entiende que una variable o cualquier tipo de dato puede o no contener un valor inicial.  (Podría entenderse que todo dato es puntero?)
//      var Str: String = "Hola mundo"  // Tiene valor
//      var Str: String = ""            // Vacío
//      var Str: String?  // nil        // No tiene valor o sea nil

//      var II: Int = 40_000    // tiene valor
//      var II: Int = 0         // vacío (0 es un valor)
//      var II: Int?            // no tiene valor o sea nil

//      var Arr: [Double] = [0.0]   // tiene 1 valor, 0.0
//      var Arr: [Double] = []      // vacío  ( var Arr = [Double]() )
//      var Arr: [Double]?          // no tiene valor o sea nil

//  ! significa Caja Abierta (Unwrapped) y, ? significa Caja Cerrada (Wrapped)

//      "Swift no introdujo Optionals, introdujo Non-Optionals". @ZevEisenberg

// SoSpEcHo que Swift maneja todo como punteros en Stack, es decir, si se pone
//      var II: Int = 100_000 // se podría entender en pascal así:

//      var II: ^Integer = nil;
//      II^ := 100000;  // ya no es nil y lo abre a fuerza pues da error, debería usarse getmem(II, sizeof(Integer)), al final liberarlo con freemem(II) pero todo esto va en contra de la optimización, a no ser que Swift lo haya hecho internamente por el usuario.


enum Errorcito: Error {
    case rangoInvalido(String)
    case sinRaiz(String)
}
var Arr = [0.0]
Arr = []


///********///**********///***********


struct Persona {
    let nombre: String?
    let apellido: String?
    
    enum Errores: Error {
        case nomVacio
        case apeVacio
        case todoVacio
    }
    
    func dameCompletoOld() throws -> String {
        if let nombre = nombre, let apellido = apellido {
            return "\(nombre) \(apellido)"
        } else if nombre == nil, apellido != nil {
            throw Errores.nomVacio
        } else if nombre != nil, apellido == nil {
            throw Errores.apeVacio
        } else {
            throw Errores.todoVacio
        }
    }
    
    func dameCompletoS() throws -> String {
        switch (nombre, apellido) {
        case (.none, .none):
            throw Errores.todoVacio
        case (.none, .some):
            throw Errores.nomVacio
        case (.some, .none):
            throw Errores.apeVacio
        case let (.some(nombre), .some(apellido)):
            return "\(nombre) \(apellido)"
        }
    }
}

let foo = Persona(nombre: "Fer", apellido: nil)

do {
    let completo = try foo.dameCompletoS()
} catch { //let error as Persona.Errores {
    "Errorcito: \(error)"
} /* catch { // is Persona.Errores {
    "Errorcito desconocido  \(error)"
} */

do {
    let completo = try foo.dameCompletoS()
    completo
} catch Persona.Errores.nomVacio {
    "Sin Nombre"
} catch Persona.Errores.apeVacio {
    "Sin Apellido"
} catch Persona.Errores.todoVacio {
    "Sin Nombre ni Apellido"
} catch {
    "Algún otro error será"
}



struct Carro {
    let fabricante: String
    
    enum Errores: Error {
        case noValidoFabricante
    }
    
    init(fabricante: String) throws {
        if fabricante.isEmpty {
            throw Errores.noValidoFabricante
        }
        self.fabricante = fabricante
    }
}

do {
    let miCarro = try Carro(fabricante: "Lada")
} catch Carro.Errores.noValidoFabricante {
    "fabricante indebido"
} catch {
    "alguna otra pendejada"
}


if let miCarro = try? Carro(fabricante: "Mercedes") {
    "Felicidades, tu \(miCarro) está parqueado al frente"
} else {
    "Pidelo para Navidad"
}



struct Perro {
    let lastimado: Bool
    let durmiendo: Bool
    
    enum ErroresLadrando: Error {
        case noPuedeTaDurmiendo
        case noPuedeTaLastimado
    }
    
    func ladra() throws {
        if durmiendo {
            throw ErroresLadrando.noPuedeTaDurmiendo
        }
        "ladra"
    }
    
    func corre() throws {
        if lastimado {
            throw ErroresLadrando.noPuedeTaLastimado
        }
        "corre"
    }

    func correLadra() throws {
        do {
            try ladra()
        } catch {
            "\(error)"
            throw ErroresLadrando.noPuedeTaDurmiendo // para que lo bote abajo (A>>>)
        }
        do {
            try corre()
        } catch {
            "\(error)"
            throw ErroresLadrando.noPuedeTaLastimado // para que bote abajo (A>>>)
        }
    }
}


let chanda = Perro(lastimado: true, durmiendo: true)

do {
    try chanda.correLadra()
} catch is Perro.ErroresLadrando {
    "No pudo " // (>>>A) Aquí!!!
} catch {
    "Algo pasó, carnal"
}


// para efectos educativos lo siguiente (rethrows):

func nomCompleto(nombre: String?, apellido: String?, operacion: (String?, String?) throws -> String?) rethrows -> String? {
    return try operacion(nombre, apellido)
}

enum ErroresNombre: Error {
    case nomVacio
    case apeVacio
}


func + (nombre: String?, apellido: String?) throws -> String? {
    guard let nombre = nombre, !nombre.isEmpty else {
        throw ErroresNombre.nomVacio
    }
    guard let apellido = apellido, !apellido.isEmpty else {
        throw ErroresNombre.apeVacio
    }
    return "\(nombre) \(apellido)"
}


do {
    let fooBar = try nomCompleto(nombre: nil, apellido: "Dager", operacion: +)
} catch let e as ErroresNombre {
    switch e {
    case .nomVacio: "Error de nombre"
    case .apeVacio: "Error de apellido"
    }
}


enum ErroresEntero: Error {
    case sinEnteroPositivoAntes(de: Int)
}
/*
func dameEnteroPositivo(entero: Int) -> Result<Int, ErroresEntero> {
    guard entero > 0 else {
        return Result.failure()
    }
}
*/

let pendejadas = [1, "hola", 2, "shoot"] as [Any]
let pingadas: [Any] = [3, "corre", 4, "escóndete"]
let brujas: [Int?] = [1, 2, nil, 4, 5]
let purasB = brujas.filter({
    $0 != nil}) //({valor: Int?) -> Bool in valor != nil})
purasB.map({
    $0})

let unicos: Set<AnyHashable> = Set([1, 2, 3, 4, 5, 6, 1, 2, 3, "hola"])
// unicos.map(-)
unicos

func insert(_ item: Int, into array: inout [Int], at index: Int) {
    array.insert(item, at: index)
}
var array = [Int]()
insert(1, into: &array, at: 0)


func greeting(for timeOfDay: Int) -> String {
    let greeting: String
    switch timeOfDay {
    case 5..<12:
        greeting = "Good morning"
    case 12..<18:
        greeting = "Good afternoon"
    case 18..<21:
        greeting = "Good evening"
    case 21...24, 0..<5:
        greeting = "Good night"
    default:
        greeting = "Hello"
    }
    return greeting
}

greeting(for: 5)


let names = ["Bear", "Joe", "Clark"]

names.map { (s) -> String in
    return s.uppercased() }

//func retrieveData(forKey key: String) -> (data: Data?, error: Error?, success: Bool) {
//    return (nil, error, true)
//}

protocol Shape {}
class Triangle: Shape {}
class Circle: Shape {}
class Rectangle: Shape {}
let x = Circle()
let y = Rectangle()
let z = Triangle()
var arrResult = [String]()

[x, y, y, z, x].forEach { (item) in
    switch item {
    case is Circle: arrResult.append("Circle")
    case is Rectangle: arrResult.append("Rectangle")
    case is Triangle: arrResult.append("Triangle")
    case is Shape: arrResult.append("Shape")
    default: arrResult.append("Unknown shape")
    }
}
arrResult


enum Direction {
    case north, south, east, west
}
let D = Direction.self

type(of: D)



let xx = ["1","2"].dropFirst()
xx

//let yy = xx[1]


