//: Playground - noun: a place where people can play

import UIKit

var str = "1001"
var resultaQue = ""

let izquierda = ["petro", "maduro", "daSilva", "cuarenta", "irene"]
let derecha = ["uribe", "trump", "bolsonaro", "rato", "risaloca", "flash"]

for (i, d) in zip(izquierda, derecha) {
    print("\(i) va con \(d)")
}

let ambos = Array(zip(izquierda, derecha))

resultaQue = ambos.reduce("") { (primer, segundo) in
    return primer + "/" + segundo.0 + "-" + segundo.1
}
print(resultaQue)

let numeros = [1, 2, 3, 4]

numeros.reduce(0) {
    return $0 + $1
}

numeros.reduce(0) { ($0, $1)
    return $0 + $1
}

numeros.reduce(0) { (suma, num) in
    return suma + num
}

let agregaDos: (Int, Int) -> Int = { m, n in n + m }

numeros.reduce(0, agregaDos)


class Persona: NSObject {
    let nombre: String;
    let edad: Int8;
    init(nombre: String, edad: Int8) {
        self.nombre = nombre
        self.edad = edad
    }
    convenience init(nombre: String) {
        self.init(nombre: nombre, edad: 0) 

    }
}

let tarzan = Persona(nombre: "Edgar", edad: 52)
let jane = Persona(nombre: "Jenny")


jane.edad


let url = URL(string: "demoapp://show/photo%20real?name=rabbit")!
url.pathComponents
url.host
url.path
url.scheme
let allComponents = url.host.map { [$0] + url.pathComponents }
allComponents

var componente = allComponents?
    .filter { $0 != "/" }
    .map { $0.capitalized }

str = "0000111"
let cuentaChars = str.characters.filter{ $0 == "1" }.count
cuentaChars
let primaParte = String(repeating: "1", count: cuentaChars - 1)
let seconParte = String(repeating: "0", count: str.characters.count - cuentaChars) + "1"

let tercaParte = primaParte + seconParte

class Solution {
    static func maxOddBinaryNumber(_ s: String) -> String {
        let cuentaUnos = s.characters.filter { $0 == "1" }.count
        if cuentaUnos < 101, cuentaUnos > 0 {
            return String(repeating: "1", count: cuentaUnos - 1) + String(repeating: "0", count: s.characters.count - cuentaUnos) + "1"
        } else {
            return "countOnes no se puede procesar"
        }
    }
}

let Sol = Solution.maxOddBinaryNumber("00101100011")

let numerillos = [1, 2, 3]
func reverseArray(_ arr: [Int]) -> [Int] {
    var invertido = [Int]()
    for i in 0..<arr.endIndex {
        invertido.insert(arr[i], at: 0)
    }
    return invertido
}

reverseArray(numerillos)

let resulty = numerillos.reversed().map { $0 }

resulty



// Lo siguiente está basado en un artículo: https://ijoshsmith.com/2017/04/08/reflectable-enums-in-swift-3/

struct Contacto0 {

    let contacto: TipoContacto

    enum TipoContacto {
        case facebook
        case instagram
    }

    let id: Int
    let nombre: String

    let edad: Int?
    let direccion: String?
}

//enum Contacto {
//    case facebook(ContactoFacebook)
//    case instagram(ContactoInsta)
//}


// Adoptado por un enum donde cada case tiene un struct asociado con propiedades similares
protocol EnumReflejable {
    func valor<Value>(de nombrePropiedad: String) -> Value
}

extension EnumReflejable {
    func valor<Value>(de nombrePropiedad: String) -> Value {
        let espejito = Mirror(reflecting: self)
        let structHijo = espejito.children.first!
        let structEspejo = Mirror(reflecting: structHijo.value)
        let propiedad = structEspejo.children.first {
            $0.label == nombrePropiedad
        }
        let valor: Any = propiedad?.value as Any // propiedad!.value
        return valor as! Value
    }
}


enum Contacto: EnumReflejable {
    case facebook(ContactoFacebook)
    case instagram(ContactoInsta)

    var id: Int { return valor(de: #function) }
    var nombre: String { return valor(de: #function) }
}


struct ContactoFacebook {
    let id: Int
    let nombre: String
    let edad: Int
}

struct ContactoInsta {
    let id: Int
    let nombre: String
    let direccion: String
}

let fer = ContactoFacebook (id: 444, nombre: "Fernando", edad: 52)

let nando = ContactoInsta(id: 333, nombre: "Nandito", direccion: "Cra tal con tal")

let usuarios = [Contacto.facebook(fer), .instagram(nando)]

//extension Contacto {
//    var id: String {
//        switch self {
//        case .facebook(let c): return String(c.id)
//        case .instagram(let i): return String(i.id)
//        }
//    }
//    var nombre: String {
//        switch self {
//        case .facebook(let f): return f.nombre
//        case .instagram(let i): return i.nombre
//        }
//    }
//}

// sin definir las variables computadas en la anterior extensión no se puede lograr lo siguiente:
usuarios.forEach{ print(String($0.id) + ", " + $0.nombre) }

/**********************   ***********************/


struct Beisbolista {
    let nombre: String
    let edad: Int
    let salario: Double
    let extranjero: Bool
    init(nombre: String, edad: Int, salario: Double, extranjero: Bool = false) {
        self.nombre = nombre; self.edad = edad; self.salario = salario; self.extranjero = extranjero;
    }
}

let babeR = Beisbolista(nombre: "babe", edad: 40, salario: 5000.0, extranjero: true)
let rentE = Beisbolista(nombre: "Edgar", edad: 44, salario: 9_000.0)

extension Beisbolista: Equatable {
    public static func ==(lhs: Beisbolista, rhs: Beisbolista) -> Bool {
        guard lhs.nombre == rhs.nombre else { return false }
        guard lhs.edad == rhs.edad else { return false }
        guard lhs.salario == rhs.salario else { return false }
        guard lhs.extranjero == rhs.extranjero else { return false }
        return true
    }
}

let sonLoMismo = babeR == rentE

public func adoptEquatable(_ sujeto: Any) {
    let espejito = Mirror(reflecting: sujeto)

    let nombreTipo: String = {
        let nombreCompletoT = String(reflecting: espejito.subjectType)
        let tipoPartes = nombreCompletoT.components(separatedBy: ".")
        let tienePrefijoMod = tipoPartes.count > 1
        return tienePrefijoMod
            ? tipoPartes.dropFirst().joined(separator: ".")
            : nombreCompletoT
    }()

    let nombresPropiedad = espejito.children.map({ $0.label ?? "(vacío)" })

    // Asociamos niveles de indentación con cada pieza de código
    typealias GrupoPlantilla = [(Int, String)]
    let gruposPlantillas: [GrupoPlantilla] = [
        [(0, "extension \(nombreTipo): Equatable {")],
        [(1, "public static func ==(lhs: \(nombreTipo), rhs:\(nombreTipo)) -> Bool {")],
        nombresPropiedad.map { (2, "guard lhs.\($0) == rhs.\($0) else { return false }") },
        [(2, "return true")],
        [(1, "}")],
        [(0, "}")]
    ]

    // Aplica indentación a cada línea de código mientras se aplana la lista.
    let indenta = "\t"
    let lineasDeCodigo = gruposPlantillas.flatMap { grupoPlantilla -> [String] in
        return grupoPlantilla.map { (nivelIndentado: Int, codigo: String) -> String in
            let indentacion = String(repeating: indenta, count: nivelIndentado)
            return "\(indentacion)\(codigo)"
        }
    }
    // Aplica indentación a cada línea de código mientras
    let codigoFuente = lineasDeCodigo.joined(separator: "\n")
    print(codigoFuente)
}

adoptEquatable(babeR)

/**********************   ***********************/

extension Array {
    mutating func mezcla() {
        for _ in 0..<10 {
            sort { (_,_) in arc4random() < arc4random() }
        }
    }
}

var organisms = [
    "ant",  "bacteria", "cougar",
    "dog",  "elephant", "firefly",
    "goat", "hedgehog", "iguana",
    "jiraf", "koala",   "mouse",
    "Nightingale", "Orca"]

print("Original: \(organisms)")

organisms.mezcla()

print("Revuelto: \(organisms)")

