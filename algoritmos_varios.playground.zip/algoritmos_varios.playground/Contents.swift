import Foundation

import PlaygroundSupport

//PlaygroundPage.current.needsIndefiniteExecution = true // para manejo de funciones y closures en Queues Asincrónicos


let messageID = Array<Int>(1...3_000)
let mensajeID = [Int](1...3_000)
let mensajeContiguoID = ContiguousArray<Int>(1...3_000) // WOW Súper-Rápido

var inicio = CFAbsoluteTimeGetCurrent()
mensajeID.reduce(0, +)
var final = (CFAbsoluteTimeGetCurrent() - inicio) * 10_000

inicio = CFAbsoluteTimeGetCurrent()
mensajeContiguoID.reduce(0, +)
final = (CFAbsoluteTimeGetCurrent() - inicio) * 10_000

struct Libro {
    let ISBN: Int
    let titulo: String
    let autor: String?
}

var B1: Libro? = nil
B1 = Libro(ISBN: 123_456, titulo: "100 años", autor: nil)
let Au = B1?.autor?.capitalized ?? "nada"

var libros: [Libro] = [Libro(ISBN: 999, titulo: "Feliz Navidad", autor: "Santa")]
libros.append(Libro(ISBN: 234, titulo: "Toque Midas", autor: "Trump"))
libros.append(Libro(ISBN: 345, titulo: "Burrito Sabanero", autor: nil))
libros.insert(Libro(ISBN: 123, titulo: "Padre Rico", autor: "Kiyosaki"), at: 0)

for (index, L) in libros.enumerated() { // enumerated bota index
    print("\(L.titulo) escrito por \(L.autor) índice: \t \(index)")
}


// Dados unos números en un arreglo, determine si un par de sus elementos da la suma de `B`
func equalSumA(_ A: [Int], B: Int) -> Bool {
    var hashA = Set<Int>()

    for a in A {
        let c = B - a
        if hashA.contains(c) {
            return true
        }
        hashA.insert(a)
    }
    return false
}
equalSumA([1, 2, 6, 4], B: 8)


// Función para intercambiar enteros en una sola línea

func swap(_ a: inout Int, _ b: inout Int) { // inout es como var en Pascal
    return (a, b) = (b, a)
}

var a = 10
var b = 20
swap(&a, &b)
a
b

// la misma función pero con Generics

func swapGenerics<T>(_ a: inout T, _ b: inout T) {
    (a, b) = (b, a)
}

var aa = 10.01
var bb = 20.02
swapGenerics(&aa, &bb)



// Ejemplo de función con una clausura @escaping
func doSomething(completion: @escaping () -> Void) {
    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
        completion()
    }
}

// Ejemplo de función con una clausura non-escaping
func doSomethingElse(completion: () -> Void) {
    completion()
}

var XX = 10

// Uso de la función con clausura @escaping
doSomething {
    print("primera tarea: \(XX)")
    XX += 20
    print("Primera tarea completada debería ser 30 pero da \(XX)")
}

// Uso de la función con clausura non-escaping
doSomethingElse {
    print("Otra tarea: \(XX)")
    XX += 5
    print("Otra tarea completada \(XX)")
}


// Fibonacci a la antigua

var fib = [Int]()
fib.append(1)
fib.append(2)
var sumaFib = 2
while fib[fib.count - 1] < 4_000 {
    let c = fib.count
    fib.append(fib[c - 2] + fib[c - 1])
    let ultimo = fib[c - 1]
    if ultimo < 4_000, ultimo % 2 == 0 {
        sumaFib += ultimo
    }
}
sumaFib

// Implementación de una programadora https://ericasadun.com/2014/07/31/swift-project-euler-challenge-fibonacci/#more-707

struct GeneradorFib {
    private var i = 0, j = 0
    mutating func siguiente() -> Int? {
        if i == 0 { i = 1; return 1 }
        if j == 0 { j = 2; return 2 }
        let suma = i + j; i = j; j = suma
        return suma
    }
}

var fibie = GeneradorFib()
var sumaFibie = 0
var actual = 0
while actual < 4_000 {
    if actual % 2 == 0 { sumaFibie += actual }
    actual = fibie.siguiente()!
}
sumaFibie


// Formateando es genial...

func stringWithFormat(format: String, args: CVarArg...) -> String {
    return NSString(format: format, arguments: getVaList(args)) as String
}

extension String {
    func formatee(_ args: CVarArg...) -> String {
        return NSString(format: self, arguments: getVaList(args)) as String
    }
}

"La canción %@ de %@".formatee("Michael Jackson", "Thriller")
"Hola a mis %d amigos ".formatee(30)
// "funciona hasta con clases y structs %@".formatee(fibie as! CVarArg)
// let mensaje = String(format: "funciona hasta con clases y structs %@", fibie as! UInt)

var rangosVarios: [CountableClosedRange<Int>] = [1...5, 7...10]
rangosVarios.append(30...60)

for rango in rangosVarios {
    var C = "🏇"
    for elemento in rango {
        C += "\(elemento)🏇"
    }
    print(C)
}


let cade = "hola mundo"
let arreCade = Array(cade.characters) // Array(cade[0]...)


