import PlaygroundSupport
import UIKit
import Foundation
import CoreGraphics

var Str:String!
var DD:Double!
var II:Int?
var BB:Bool?
var optionalName: String?
var vegetalStr:String! = "hey"

var cad = "Sólo me faltabas tú para ser feliz"

enum Errorcito: Error {
    case rangoInvalido(String)
    case sinRaiz(String)
}

var numerosInteresantes: [String:[Int]] = [
    "primos": [2, 3, 5, 7, 11, 13, 17, 19, 23, 31],
    "fibona": [1, 1, 2, 3, 5, 8, 13, 21, 34, 55],
    "cuadra": [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
]

var uno = [String]()

for I in 0..<numerosInteresantes.count {
    uno.append(Array(numerosInteresantes.keys)[I])
}
uno

uno.removeAll()

// Tres formas excelentes de recorrer los valores tipo Arreglo de Diccionarios; la primera es mediante una variable de tipo Elemento "K" de Diccionario ( K.key == Array(numerosInteresantes.keys)[1] ), la segunda es recorriendo los elementos de título de forma numérica "C": Int, ( C == 1 ), la tercera mediante una tupla que en su primer elemento "llave" sirve para poder comparar entre Strings ( llave == Array(numerosInteresantes.keys)[1] )...  Excelente Fernando

for K in numerosInteresantes {
    uno.append(K.key)
    if K.key == Array(numerosInteresantes.keys)[1] {
        for V in K.value {
            print(V, terminator: " ")
        }
        // OPTIMIZACIÓN: incluso aquí se puede poner un "break" ya que se logró el objetivo K.key == Array(numerosInteresantes.keys[1]
    }
}
uno
print("")


for C in 0..<numerosInteresantes.count {
    if C == 1 {
        for V in Array(numerosInteresantes.values)[1] {
            print(V, terminator: " ")
        }
        // OPTIMIZACIÓN: incluso aquí se puede poner un "break" ya que se logró el objetivo C == 1
    }
}

print("")

for (llave, valores) in numerosInteresantes {
    if llave == Array(numerosInteresantes.keys)[1] {
        for V in valores {
            print(V, terminator: " ")
        }
        // OPTIMIZACIÓN: incluso aquí se puede poner un "break" ya que se logró el objetivo llave == Array(numerosInteresantes.keys)[1]
    }
}

print("")

Array(numerosInteresantes.values)[0][0]

for I in Array(numerosInteresantes.values)[1] {
    type(of:I)
//    print(type(of:I), terminator: " ")
}

var mas_grande = 0
var tipo = String()

for (clase, numeros) in numerosInteresantes {
    for num in numeros {
        if num > mas_grande {
            mas_grande = num
            tipo = clase
        }
    }
}

Str = "Mayor: \(mas_grande), está entre los \(tipo)."

print("")



let miDiccionario: [String: Int] = ["Bruce": 1950, "Jean": 1968, "Chuck": 1948, "Jet": 1966, "Jackie": 1958, "Lee": 1950, "Li": 1966, "Norris": 1948]

/// Excelente forma para buscar los keys de un diccionario

extension Dictionary where Value: Equatable{
    func keysForValue(valor: Value) -> [Key] {
        return flatMap { (key: Key, val: Value) -> Key? in
            valor == val ? key : nil
        }
    }
}

miDiccionario.keysForValue(valor: 1948) // extensión de Dictionary

let myDict = NSDictionary(dictionary: miDiccionario)

myDict.allKeys(for: 1966) // NSDictionary


