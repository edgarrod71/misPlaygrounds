//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"



let cedulaNo = 91439275
let cedulaStr = String(cedulaNo)
let cedulaChrs = String(cedulaNo).characters

let cedulaArr1 = cedulaStr.characters.map { $0 } // 1. convierte de string a Array
let cedulaArr2 = Array(cedulaStr.unicodeScalars).map { String($0) } // 2. Str a Array
let cedulaArr3 = Array(cedulaChrs) // 3. CharacterView to Array
let cedulaArr4 = Array(String(cedulaNo).characters) // 4. CharacterView to Array

cedulaArr1
cedulaArr2.contains("9")

let cedulaCad = [String]((65...90).map { String(UnicodeScalar($0)) })

cedulaCad

[9, 1, 4, 3, 9, 2, 7, 5].map(String.init)
let cedula = [9, 1, 4, 3, 9, 2, 7, 5].map { String($0) }.joined()
cedula
Array(0...9).map(String.init)
let from0To9 = Array(98...107).map { String($0) }
from0To9
let cuentaDe9A19 = [Int](9..<20) // Array con rango demasiado práctico
let deBaJ = [Character]((98..<107).map { Character(UnicodeScalar($0)) }) // Array de letras ASCII
deBaJ



let DBAJ = [Character]((98..<107).flatMap { Character(UnicodeScalar($0)) })
DBAJ
let de0a9 = Array(48...57).map { String(UnicodeScalar($0)) } // Array de dígitos
de0a9
str = ""
for a in de0a9 {
    str.append(a)
}
str

/// Decenas
let decenas: [Int] = [4, 5, 6, 9, 7].map { $0 * 10 }
print("las decenas son \(decenas)")



let heladosFavoritos = [
    "fer": "guanabana",
    "sveta": "mango"
]

// heladosFavoritos["jenny", default: "niansesabe"]
let jennys = heladosFavoritos["jenny"] ?? "niansesabe"

let precios = ["leche": 4000, "Pepsi": 4000]

var numies = Array(10...20)

let ubicadoEn = precios["Pepsi"]

var equipos = Array<String>()

equipos.append("Millos")
equipos.append("")
equipos.insert("", at: 0)

equipos
equipos.startIndex

equipos[equipos.startIndex] = "SantaFe"

equipos
equipos.endIndex

equipos[equipos.endIndex - 1] = "Nacional"

equipos

var estrellas = [String: Int]()

estrellas[equipos.first!] = 14
estrellas[equipos[1]] = 15
estrellas[equipos.last!] = 16

estrellas[equipos[0]] = nil

estrellas



var esta_guardado = [1, 2, 3] // arreglo
esta_guardado.append(3)

let conjuntico = NSCountedSet(array: esta_guardado) // Array a Set
conjuntico.count(for: 3) // for es los, cuenta los: 3

let setArreglo = Array(conjuntico) // Set a Array
//let setArregloOrdenado = setArreglo.sorted(by: { return setArreglo.count })

esta_guardado.append(4)
esta_guardado.remove(at: 2)
var H = esta_guardado[2].hashValue; //print(H, esta_guardado.contains(1));
esta_guardado // good!

let messageID = Array<Int>(1...100_000)
let mensajeID = [Int](1...100_000)
let msjContiguoID = ContiguousArray<Int>(1...100_000) // WOW

var inicio = CFAbsoluteTimeGetCurrent()
mensajeID.reduce(0, +)
var final = CFAbsoluteTimeGetCurrent() - inicio

inicio = CFAbsoluteTimeGetCurrent()
msjContiguoID.reduce(0, +)
final = CFAbsoluteTimeGetCurrent() - inicio


let empleadoS: [String: String] = [
    "BCA": "FERNANDO",
    "BGA": "JENNY"
]
empleadoS["BGA"]!

var primos = Set([2, 2, 3, 5, 7, 11, 13, 17, 23]); primos.insert(29)
str = "\(String(describing: primos.sorted())), \(Bool(primos.contains(37)))"

var politicos: Array<String> = ["Col", "Uribe", "Arg", "Milei"]
var polLat = [String: String]() // Diccionario vacío
polLat = ["Col": "Uribe", "Arg": "Milei"]  // Esto es Dictionary, no Array simple
for dirigente in polLat {
    print("\(dirigente.value) derecha en \(dirigente.key)")
}

var usuriaga: [String: Double] = ["Edgar": 234.45, "Fer": 123.3] // Dictionary
var libros: Set<String> = Set(arrayLiteral: "Agustín", "Generación", "Kishner", "idiota") // puede omitirse el segundo Set, es decir los elementos dentro de los corchetees quedan y compila
var libros_S: Set<String> = Set(["Padre Rico", "Toque Midas"]) // Set

var libros_A: [String] = ["Laje", "Generación", "Kishner", "idiota"] // Array!

var equipitos: [String] = [String]() // Arrays vacíos
var pistas = [String]()
var otroDicVacio: [String: Int] = [:]


/// ZIP para un cierre de arreglos en una tupla
let nums = 1...Int.max // rangazo
let batman = ["m", "u", "r", "c", "i", "é", "l", "a", "g", "o"]

for pares in zip(nums, batman) {
    print(pares)
}

let nones = Array(zip(nums, batman))




struct Letters {

    static let
    A: UInt32 =  65,
    Z: UInt32 = 101

    static func isUppercaseLetterValue(_ charValue: UInt32) -> Bool {

        return Letters.A <= charValue && charValue <= Letters.Z
    }
}

extension String {

    func toLetters() -> [String] {

        return Array(self.unicodeScalars)
            .filter { Letters.isUppercaseLetterValue($0.value) }
            .map { String($0) }
    }
}


var letras = Letters.isUppercaseLetterValue(70)
let hola = Array("hola".unicodeScalars)

let hello = hola.map({ String($0) })
hello
var saludando = "HOLA".toLetters()
saludando

let saludandote = Array("malo, VER CÓDIGO TAN MALIÑO".unicodeScalars).map({ String($0) })

let letters = saludandote
    .reduce("") { $0 + $1.uppercased() }
    .toLetters()
type(of:letters)

let occurrences = NSCountedSet()
occurrences.addObjects(from: letters)

let letrotas = ["a", "b", "c"]

let ocurrencias = Set(letters)
ocurrencias.count

let letterCount = max(letters.count, 1)

let alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toLetters()
let resultito = alphabet.map {
    Double(occurrences.count(for: $0)) / Double(letterCount)
}


/// comprimir y descomprimir arreglos está cool!

func comprimeArray<T: Comparable>(input: [T]) -> [(T, Int)] {
    var salida = [(T, Int)]()
    for elem in input {
        if let (valor, ocurrencias) = salida.last, valor == elem {
            salida[salida.endIndex - 1] = (elem, ocurrencias + 1)
        } else {
            salida.append((elem, 1))
        }
    }
    return salida
}

func descomprimeArray<T>(input: [(T, Int)]) -> [T] {
    return input.flatMap { (valor, ocurrencias) in
        repeatElement(valor, count: ocurrencias)
    }
}

let uncompressedInts = [
    8, 8, 8,
    2, 2, 2, 2, 2, 2, 2, 2, 2,
    8,
    3,
    5, 5, 5, 5,
    0, 0, 0, 0, 0, 0, 0,
    9]

let expectedCompressedArray = [
    (8, 3),
    (2, 9),
    (8, 1),
    (3, 1),
    (5, 4),
    (0, 7),
    (9, 1)]

let arrayComprimido = comprimeArray(input: uncompressedInts)
let estaCorrectoAC = arrayComprimido.elementsEqual(expectedCompressedArray, by: { $0.0 == $1.0 && $1.1 == $0.1 })
estaCorrectoAC

let arrayDescomprimido = descomprimeArray(input: arrayComprimido)
let estaCorrectoAD = arrayDescomprimido == uncompressedInts




