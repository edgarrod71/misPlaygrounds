//: Playground - noun: a place where people can play
import UIKit
import Foundation

var str = "Hello, playground"

/////// ericasadun.com ////////

// Reemplace esto con una ruta a la biblioteca estándar en su sistema
// public let stdlpath = Bundle.main.path(forResource: "stdl", ofType: "txt")
public let stdlpath = "/Users/fernandodager/Desktop/stdl.txt"
public let contenido = try? String(contentsOfFile: stdlpath)

// Guardando elementos de interés
var conformanceDictionary = [String: [String]]()
var associatedConformanceDictionary = [String: [String]]()
var typedDictionary = [String: [String]]()
var fullAsociatedTypes = [String: [String]]()
var objC = Set<String>()


///////// STRING UTILS

extension String {
    public var first: String? { return isEmpty ? nil : String(self[startIndex]) }
    public var last: String? { return isEmpty ? nil : String(self[index(before: endIndex)..<endIndex]) }
    public var butFirst: String? {
        return isEmpty ? nil : String(self.substring(from: index(after: startIndex)))
    }
    public var butLast: String? {
        return isEmpty ? nil : String(self.characters.dropLast())
    }
    public var trimmed: String {
        return self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    public static func pattern(count: Int, _ s: String) -> String {
        if let c = s.first, s.characters.count > 0 {
            return String(repeating: String(c), count: count)
        } else {
            return ""
        }
    }
}


// Retorna un Rango Optional cuya expresión regular concuerda dentro de una cadena
func rexRange(_ cad: String, _ rex: String) -> Range<String.Index>? {
    cad
    rex
    cad.startIndex
    cad.endIndex
    return cad.range(of: rex, options: [.regularExpression], range: cad.startIndex..<cad.endIndex, locale: nil)
}

/// Extract an entire scope from a match point by pairing braces
func fetchScope(contenido: String, prefijoRex: String) -> Range<String.Index>? {

    if let matchRange = rexRange(contenido, prefijoRex) {
        var idx = matchRange.upperBound; var cuenta = 1; let ii = 0
        let chars = Array(contenido.characters)
        repeat {
            if ii < chars.count {
                let testChar = chars[ii]
                if testChar == "{" { cuenta += 1 }
                if testChar == "}" { cuenta -= 1 }
                idx = contenido.index(after: idx)
            } else {
                print("Se acabaron los caracteres")
                return nil
            }
        } while cuenta > 0
        return matchRange.lowerBound..<idx
    }
    return nil
}

/// Substring from start of Rex
func substringFromStartOfRex(cad: String, rex: String) -> String {
    if let matchRange = rexRange(cad, rex) {
        return cad.substring(from: matchRange.lowerBound)
    } else {
        return ""
    }
}

/// Substring to start of Rex
func substringToStartOfRex(cad: String, rex: String) -> String {
    if let matchRange = rexRange(cad, rex) {
        return cad.substring(to: matchRange.lowerBound)
    } else {
        return ""
    }
}

/// Substring from end of Rex
func substringFromEndOfRex(cad: String, rex: String) -> String {
    if let matchRange = rexRange(cad, rex) {
        return cad.substring(from: matchRange.upperBound)
    } else {
        return ""
    }
}

/// Substring to end of Rex
func substringToEndOfRex(cad: String, rex: String) -> String {
    if let matchRange = rexRange(cad, rex) {
        return cad.substring(to: matchRange.upperBound)
    } else {
        return ""
    }
}

/// Extract string between starting.end and ending.start rexes
public func extractStringContent(cad: String, startRex: String, endRex: String) -> String {
    var S = cad
    S = substringFromEndOfRex(cad: S, rex: startRex)
    S = substringToEndOfRex(cad: S, rex: startRex)
    return S
}

/// Transform comma-delineated string to trimmed string array
public func arrayFromComaDelineatedString(cad: String) -> [String] {
    let miembros = cad.components(separatedBy: ",")
    return miembros.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
}


/////////////// UTILIDADES

/// Remueve elementos duplicados de un arreglo
public func uniq<S: Sequence, H: Hashable>(fuente: S) -> [H] where S.Iterator.Element == H {
    let elementosUnicos = Set<H>(fuente)
    return Array(elementosUnicos)
}

/// Print a heading for a section
public func printHeading(cad: String, first: Bool = false) {
    if !first { print("") }
    let linea = String(repeating: "-", count: cad.characters.count + 2)
    print("\(linea)\n \(cad) \n\(linea)\n")
}

//let unicos = uniq(fuente: [3, 3, 4, 5, 4])
//
//printHeading(cad: "hola fer, cómo vas")



/////// ProtocolFetch

func protocolReport() {
    // obtiene la declaración completa del protocolo tomado de la biblioteca
    func traerPortocolo(contenido: String) -> Range<String.Index> {
        return fetchScope(contenido: contenido, prefijoRex: "\n(@objc\\s)?protocol[^\\{]*\\{")!
    }

    // Retorna el nombre de un protocolo
    func fetchProtocolName(cadProtocolo: String) -> String {
        return extractStringContent(cad: cadProtocolo, startRex: "\n(@objc\\s+)?protocol\\s*", endRex: "[\\s:]")
    }

    // Retorna una lista de protocolos ancestros que cumplen con lo conforme
    func fetchProtocolConformance(cadProtocolo: String) -> [String] {
        var p = cadProtocolo
        p = substringToEndOfRex(cad: p, rex: "protocol[^\\{]*\\{")
        if rexRange(p, ":") == nil { return [] }
        p = substringToEndOfRex(cad: p, rex: ":.*\\{")
        p = substringFromStartOfRex(cad: p, rex: ":.*\\{")
        p = (p.butFirst?.butLast)!
        return arrayFromComaDelineatedString(cad: p)
    }

}
    /// Locate associated types for the protocol
    func fetchAssociatedTypes(cadProtocolo: String) -> [String] {
        var p = cadProtocolo
        var tipos = [String]()
        repeat {
            if let tipoAliasRango = rexRange(p, "typealias .*\n") {
                let startIndex = tipoAliasRango.lowerBound
                let endIndex = tipoAliasRango.upperBound
                let subString = p[startIndex..<endIndex]
                let trimmedSubstring = String(subString).trimmed
                tipos.append(trimmedSubstring)
                p = p.substring(from: endIndex) // daba error '...' is not a postfix unary operator
            } else {
                p = ""
            }
        } while !p.isEmpty
        return tipos
    }

//func FetchAssociatedTypes(protocolString: String) -> [String] {
//    var p = protocolString
//    var types = [String]()
//    repeat {
//        if var typealiasRange = rexRange(p, "typealias .*\n") {
//            typealiasRange.startIndex = advance(typealiasRange.startIndex, "typealias ".characters.count)
//            types.append(p.substringWithRange(typealiasRange).trimmed)
//            p = p.substringFromIndex(typealiasRange.endIndex)
//        } else {
//            p = ""
//        }
//    } while !p.isEmpty
//    return types
//}



let cadProtocolo = "protocol MyProtocol { typealias MyType }"
let tipos = fetchAssociatedTypes(cadProtocolo: cadProtocolo)
print(tipos) // Salida: ["MyType"]










