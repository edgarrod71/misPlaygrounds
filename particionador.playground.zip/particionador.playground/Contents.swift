//: Playground - noun: a place where people can play
import UIKit
import PlaygroundSupport

extension Collection where Iterator.Element: Comparable {
    /// Retorna un arreglo compuesto de elementos ordenados divididos
    /// en cada punto donde un predicado suplido por el usuario que evalúa true
    /// ```
    /// [1, 2, 2, 3, 3, 3, 1]
    ///   .partitioned(at: { $0 != $1.last! })
    /// // [[1], [2, 2], [3, 3, 3], [1]]
    ///
    /// [1, 2, 2, 3, 3, 3, 1]
    ///   .partitioned(at: { $0.count == 2 })
    /// // [[1 2], [2, 3], [3, 3], [1]]
    /// ```
    ///
    /// - Parámetro predicado: un closure que prueba si un nuevo elemento
    ///   debiera agregarse a la parte actual
    /// - Parámetro elemento: el elemento a ser probado
    /// - Parámetro currentPartition: un arreglo no-vacío que contiene un grupo
    ///   ordenado contiguo de miembros reunidos

    /// - Retorna: Un arreglo de elementos reunidos particionados
    public func particionar(en predicado: (_ elemento: Iterator.Element, _ particionActual: [Iterator.Element]) -> Bool ) -> [[Iterator.Element]] {
        var actual: [Iterator.Element] = []
        var resultado: [[Iterator.Element]] = []
        for E in self {
            guard !actual.isEmpty else {
                actual = [E];
                continue
            }
            switch predicado(E, actual) {
            case true: resultado.append(actual); actual = [E]
            default: actual.append(E)
            }
        }
        guard !actual.isEmpty else { return resultado }
        resultado.append(actual)
        return resultado
    }

    /// ```
    /// [1, 2, 2, 3, 3, 3, 1]
    ///   .partitioned(where: !=)
    /// // [[1], [2, 2], [3, 3, 3], [1]]
    /// ```
    ///
    /// - Parameter predicate: a closure that tests whether a new element
    ///   should be added to the current partion
    /// - Parameter element: the element to be tested
    /// - Parameter mostRecent: the most recently included element
    ///
    /// - Returns: An array of partitioned collection elements
    public func particionar(cuyo predicado: @escaping (_ element: Iterator.Element, _ mostRecent: Iterator.Element) -> Bool ) -> [[Iterator.Element]] {
        // `partitioned(at:)` guarantees a non-empty array
        // as its second closure argument
        return self.particionar(en: {
            return predicado($0, $1.last!)
        })
    }
}

let testArray = [1, 2, 2, 3, 3, 3, 1, 1, 1, 2, 2, 3]

print(testArray.particionar(en: { $0 != $1.last! }))
// [[1], [2, 2], [3, 3, 3], [1, 1, 1], [2, 2], [3]]

print(testArray.particionar(cuyo: !=))
// [[1], [2, 2], [3, 3, 3], [1, 1, 1], [2, 2], [3]]

print(testArray.particionar(en: { $0 == $1.last! }))
// [[1, 2], [2, 3], [3], [3, 1], [1], [1, 2], [2, 3]]

print(testArray.particionar(en: { $1.count == 5 }))
// [[1, 2, 2, 3, 3], [3, 1, 1, 1, 2], [2, 3]]

print([1, 2, 2, 3, 3, 3, 1].particionar(en: { $1.count == 4 }))
// [[1, 2], [2, 3], [3, 3], [1]]

print("1223333111223"
    .characters
    .particionar(en: { $0 != $1.last! })
    .map({ String($0) }))
// ["1", "22", "3333", "111", "22", "3"]

print("1223333111223"
    .characters
    .particionar(cuyo: !=)
    .map({ String($0) }))
// ["1", "22", "3333", "111", "22", "3"]


//// ________________________________________________


extension ArraySlice where Element: Comparable {
    /// Produces an array of slices representing the original
    /// slice split at each point where a user-supplied
    /// predicate evalutes to true.
    ///
    /// - Parameter predicate: a closure that tests whether a new element
    ///   should be added to the current partion
    /// - Parameter element: the element to be tested
    /// - Parameter nextElement: the successive element to be tested
    /// - Parameter maxPartitions: The maximum number of
    ///   subslices that can be produced
    ///
    /// - Returns: An array of array slices
    fileprivate func sliced(where predicate: (_ element: Element, _ nextElement: Element) -> Bool, maxPartitions: Int = .max ) -> [ArraySlice<Element>] {

        guard !isEmpty else { return [] }
        guard maxPartitions > 1, count > 1 else { return [self] }
        var (partitionIndex, nextPartitionIndex) = (startIndex, indices.index(after: startIndex))

        while nextPartitionIndex < endIndex, !predicate(self[partitionIndex], self[nextPartitionIndex]) {
            (partitionIndex, nextPartitionIndex) = (nextPartitionIndex, indices.index(after: nextPartitionIndex))
        }

        guard partitionIndex < endIndex else { return [self] }

        let (firstSlice, remainingSlice) = (self[startIndex ..<  nextPartitionIndex], self[nextPartitionIndex ..< endIndex])
        let rest = remainingSlice.sliced(where: predicate, maxPartitions: maxPartitions - 1)

        return [firstSlice] + rest
    }
}

extension Array where Element: Comparable {
    /// Produces an array of slices representing an
    /// array split at each point where a user-supplied
    /// predicate evalutes to true.
    ///
    /// ```
    /// [1, 2, 2, 3, 3, 3, 1]
    ///   .sliced(where: !=)
    /// // [ArraySlice([1]), ArraySlice([2, 2]), ArraySlice([3, 3, 3]), ArraySlice([1])]
    /// ```
    ///
    /// - Parameter predicate: a closure that tests whether a new element
    ///   should be added to the current partion
    /// - Parameter element: the element to be tested
    /// - Parameter nextElement: the successive element to be tested
    /// - Parameter maxPartitions: The maximum number of slices
    ///
    /// - Returns: An array of array slices
    public func sliced(where predicate: (_ element: Element, _ nextElement: Element) -> Bool, maxPartitions: Int = .max ) -> [ArraySlice<Element>] {
        return self[startIndex ..< endIndex].sliced(where: predicate, maxPartitions: maxPartitions)
    }
}

// Same value
let x = [1, 2, 2, 3, 3, 3, 1]
    .sliced(where: { $0 != $1 })
print(x)
// [ArraySlice([1]), ArraySlice([2, 2]), ArraySlice([3, 3, 3]), ArraySlice([1])]

// Run-length encoding
let xx = [1, 2, 2, 3, 3, 3, 3, 3, 1, 1, 2, 1, 1]
    .sliced(where: !=)
    .map { ($0.count, $0.first!) }
print(xx)
// [(1, 1), (2, 2), (5, 3), (2, 1), (1, 2), (2, 1)]

// Strings
let y = Array("aaaabbbbcccdef".characters)
    .sliced(where: !=)
    .map({ String($0) })
print(y)
// ["aaaa", "bbbb", "ccc", "d", "e", "f"]

// increasing subsequences
let z = [1, 2, 2, 1, 3, 3, 1].sliced(where: >)
print(z)
// [ArraySlice([1, 2, 2]), ArraySlice([1, 3, 3]), ArraySlice([1])]

// decreasing subsequences
let w = [1, 2, 2, 1, 3, 3, 1].sliced(where: <)
print(w)
// [ArraySlice([1]), ArraySlice([2, 2, 1]), ArraySlice([3, 3, 1])]