import UIKit
import Foundation

var str = "Hello, playground"

func findNemo (_ arr: [String]) {

    let antes = Date()

    for i in 0 ..< arr.count {
        if arr[i] == "nemo" {
            print("Encontrado!")
        }
    }

    let despues = Date()
    let componente = Calendar.current.dateComponents([.nanosecond], from: antes, to: despues)
    let milisegundos: Double = Double(componente.nanosecond! / 1_000_000)
    print("buscar a memo tomó \(milisegundos) ms")
}

let nemo = Array<String>(repeating: "", count: 10)
let memo = [String](repeating: "", count: 3000)
findNemo(nemo)
findNemo(memo)

// Constante de tiempo O(1)
func constanteTiempo(_ n: Int) -> Int {
    let result = n * n
    return result
}

// tiempo Linear O(n)
func tiempoLinear(_ n: [Int]) -> Int {
    for i in 0..<n.count {
        if n[i] == 0 {
            return 0
        }
    }
    return 1
}
tiempoLinear([1, 2, 3])

// tiempo Logarítmico O(log n)
func tiempoLogaritmico(_ n: Int) -> Int {
    var N = n
    var resultado = 0

    while N > 1 {
        N /= 2
        print(N)
        resultado += 1
    }
    return resultado
}
tiempoLogaritmico(128)

// tiempoCuadrático O(n^2)
func tiempoCuadratico(_ n: Int) -> Int {
    var resultado = 0
    for _ in 0 ..< n {
        for _ in 0 ..< n {
            resultado += 1
            //print("\(i) \(j)")
        }
    }
    return resultado
}
tiempoCuadratico(16)

var arreglo = [1, 2, 3]
arreglo.append(4)

var set = Set<Int>()
set.count


// Fuerza Bruta Ingenua O(n^2)
func fuerzaBruta(_ a: [Int], _ b: [Int]) -> Bool {
    for i in 0 ..< a.count {
        for j in 0 ..< b.count {
            if a[i] == b[j] {
                return true
            }
        }
    }
    return false
}

fuerzaBruta([1, 2, 3], [4, 5, 6])
fuerzaBruta([1, 2, 3], [3, 5, 6])

// Convertir a hash y revisar mediante otro índice

func elementosComunesHash(_ A: [Int], _ B: [Int]) -> Bool {

    // sigue rotando pero no anidado - O(2n) vs O(n^2)
    var hashA = [Int: Bool]() // diccionario de enteros: booleanos
    for a in A { // O(n)
        hashA[a] = true
    }

    // ahora buscamos en el hash para verificar si el elemento B existe
    for b in B {
        if hashA[b] == true {
            return true
        }
    }

    return false
}
elementosComunesHash([1, 2, 3], [4, 5, 6])
elementosComunesHash([1, 2, 3], [3, 5, 6])
