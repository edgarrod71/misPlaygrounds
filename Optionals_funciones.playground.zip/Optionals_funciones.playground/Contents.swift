//: Playground - noun: a place where people can play
import PlaygroundSupport
import UIKit
import Foundation
import CoreGraphics

var Str:String!
var DD:Double!
var II:Int?
var BB:Bool?
var optionalName: String?

// Nota sobre Optionals, para entender los opcionales veamos...
//      if Assigned(Str) then ...  // Str podría ser nil
// en Swift se entiende que una variable o cualquier tipo de dato puede o no contener un valor inicial.  (Podría entenderse que todo dato es puntero?)
//      var Str: String = "Hola mundo"  // Tiene valor
//      var Str: String = ""            // Vacío
//      var Str: String?  // nil        // No tiene valor o sea nil

//      var II: Int = 40_000    // tiene valor
//      var II: Int = 0         // vacío (0 es un valor)
//      var II: Int?            // no tiene valor o sea nil

//      var Arr: [Double] = [0.0]   // tiene 1 valor, 0.0
//      var Arr: [Double] = []      // vacío  ( var Arr = [Double]() )
//      var Arr: [Double]?          // no tiene valor o sea nil

//  ! significa Caja Abierta (Unwrapped) y, ? significa Caja Cerrada (Wrapped)

//      "Swift no introdujo Optionals, introdujo Non-Optionals". @ZevEisenberg

// SoSpEcHo que Swift maneja todo como punteros en Stack, es decir, si se pone
//      var II: Int = 100_000 // se podría entender en pascal así:

//      var II: ^Integer = nil;
//      II^ := 100000;  // ya no es nil y lo abre a fuerza pues da error, debería usarse getmem(II, sizeof(Integer)), al final liberarlo con freemem(II) pero todo esto va en contra de la optimización, a no ser que Swift lo haya hecho internamente por el usuario.


enum Errorcito: Error {
    case rangoInvalido(String)
    case sinRaiz(String)
}
var Arr = [0.0]
Arr = []


///********///**********///***********


func getUsuario() -> String? {
    return "Fer"
}

if let usu1 = getUsuario() {
    Str = "hey \(usu1)"
}

var bestScore: Int? = nil
bestScore = 101
if bestScore! > 100 {
    Str = "You got a high score!"
} else {
    Str = "Better luck next time."
}

func hablaPues(precio: Int?) {
    guard precio != nil else {
        // ejecute aquí si precio no tiene valor alguno (nil) y SALGA! mediante return
        return
    }
    guard let precio = precio else {
        // ejecuta aquí pues el Shadowing no funcionó, porque precio no tiene valor alguno (nil) debe SALIR! puede usar return
        Str = "Falta precio"
        return
    }
    Str = "\(precio) * \(precio) = \(precio * precio)"
}

var miVar: Int? = 4

if let miVar = miVar {
    // ejecute porque miVar tiene un valor de 4
    Str = "Sí pudo"
} else {
    Str = "no pudo"
    // ejecute porque miVar no tiene valor alguno
}


func getMeaning() -> Int? {
    return 42
}

func printMeaning() {
    if let nombre = getMeaning() {
        II = nombre
    }
}

printMeaning()



func double(number: Int?) -> Int? {
    guard let number = number else {
        return nil
    }
    return number * 2
}

let input = 5
if let doubled = double(number: input) {
    Str = "\(input) doubled is \(doubled)."
}

func validate(password: String?) -> Bool {
    guard let password = password else {
        return false
    }
    if password == "fr0sties" {
        Str = "Authenticated successfully!"
        return true
    }
    return false
}
validate(password: "fr0sties")


let narcos = [
    "pablo": "escobar",
    "nicolás": "maduro",
    "chapo": "guzmán"
]

//extension Sequence where Self: Collection {
//    func randomElement() -> String? {
//        let count = self.underestimatedCount
//        guard count > 0 else { return nil }
//        let randomIndex = arc4random_uniform(UInt32(count))
//        let index = self.index(self.startIndex, offsetBy: randomIndex)
//        return self[index]
//    }
//}

//extension Collection {
//    func randomElement() -> String? {
//        let count = self.count //self.underestimatedCount
//        guard count > 0 else { return nil }
//        let randomIndex = Int(arc4random_uniform(UInt32(count)))
//        let randomElement = self[self.index(self.startIndex, offsetBy: randomIndex)]
//        return randomElement
//    }
//}


struct RandomDictionary<Key, Value> where Key: Hashable {
    private let dictionary: [Key: Value]
    
    init(_ dictionary: [Key: Value]) {
        self.dictionary = dictionary
    }
    
    func randomElement() -> Value? {
        let count = dictionary.count
        guard count > 0 else { return nil }
        let RI = Int(arc4random_uniform(UInt32(count)))
        let randomKey = Array(dictionary.keys)[RI]
        return dictionary[randomKey]
    }
}

let narcas = RandomDictionary([
    "pablo": "escobar",
    "nicolás": "maduro",
    "chapo": "guzmán"
    ])

let corruptoFavorito = narcas.randomElement() ?? "ninguno"

let principalNarco: String = narcos["nicolas"] ?? "Chávez"
let segundoNarco = narcos["DeMalas"] ?? "Francia Márquez"
let tercerNarco = narcos["fernando"] ?? narcos["chapo"]



let corruptos = NSMutableArray (array: [
    "Petro", "Benedetti", "Roy", "Tornillo", "Mordisco"
    ])

func cambiaCorruptos(_ nuevos: NSArray) {
    let copia = nuevos as! NSMutableArray
    copia.add("Cabal")
}

cambiaCorruptos(corruptos)
// print(corruptos)


let miEdad = 51
let tuEdad = 22

if miEdad > tuEdad {
    "Epa que toy viejito"
} else if miEdad < tuEdad {
    "Tas pelaíto"
} else {
    "já, que somos contemporáneos"
}


/// 1. prefijo unario
let verdad = !true
type(of: verdad)
/// 2. sufijo unario
let opcional = Optional("verdad")
let fijo = opcional!
type(of: fijo)
/// 3. infijo binario
let sume = 1 + 1
type(of: sume)
/// 4. condicional ternario
let como_taz = miEdad == tuEdad ? "já, que somos contemporáneos" : miEdad > tuEdad ? "Epa que toy viejito" : "TasPelaíto"

@discardableResult
func nadaNada(
    nuevo: Int
    ) -> Int {
    "nada nada"
    return nuevo + 2
}

let nada = nadaNada(nuevo: 30)




let sumerio: (Int, Int) -> Int
sumerio = {
    (A: Int,B: Int) -> Int in A + B }
type(of: sumerio)

sumerio(10, 20)

func customSumerio(_ lhs: Int, _ rhs: Int, usando F: (Int, Int) -> Int) -> Int {
    return F(lhs, rhs)
}

customSumerio(20, 30,
    usando: {(L: Int, R: Int) -> Int in L * R })

customSumerio(5, 5) {  // quitando los tipos de dato
    (J, K) in J / K
}

customSumerio(10, 10) {  // mi favorito
    $0 * $1
}


let boletos = [10, 3, 20, 14, 17, 2]
boletos.sorted(by: {(lhs, rhs) -> Bool in
    lhs > rhs })
boletos.sorted(by: < )


func añade10(_ valor: Int) -> Int {
    return valor + 10
}

func añade20(_ valor: Int) -> Int {
    return valor + 20
}

func agrega(_ valor: Int,
            usando funcion: (Int) -> Int) -> Int {
    return funcion(valor)
}

var A1 = agrega(30) {
    (valor) in valor + 10 }

A1 = agrega(30, usando: añade10(_:))
A1 = agrega(30, usando: añade20(_:))




struct PersonaA {
    let nombre: String
    let apelli: String
    var completos: String { return "\(nombre) \(apelli)" }

    let añoNac: Int
    let añoMte: Int
    var vivio: Int { return añoMte - añoNac + 1 }
    
    static var ingresos: Double = { return 100.0 }()
    static var gastos: Double = { return 40.0 }()
    let patrimonio: Double = { return ingresos - gastos }()  // si se pone en var debe mencionarse en el init, si cambia a let hay que dejar de mencionarlo en el init, esto es realmente una propiedad calculada
    
    var sexo: Character = "M"
    mutating func cambioSexo(operacion: Character) {
        "mundo está loco"
        sexo = operacion
    }
    func copia(nombre: String, apellido: String, sexo: Character) -> PersonaA {
        return PersonaA(nombre: nombre, apelli: apellido, añoNac: self.añoNac, añoMte: self.añoMte, sexo: sexo)
    }
}


var P1 = PersonaA(nombre: "Fer", apelli: "Dager", añoNac: 1971, añoMte: 0, sexo: "M")
P1.cambioSexo(operacion: "F")

var p2 = P1.copia(nombre: "Jen", apellido: "Rod", sexo: "F")
p2.añoNac


enum Animales {
    case gato, perro, loro
}

let ani1 = Animales.gato

switch ani1 {
case .gato:
    "gatùbela"
case .perro:
    "lassie"
case .loro:
    "lorenzo"
}

enum Enlaces {
    case archivo(ruta: URL, nombre: String)
    case wwwURL(ruta: URL)
    case video(artista: String, canción: String)
}

var wwwApple = Enlaces.wwwURL(
    ruta: URL(string: "https://www.apple.com")!
)

wwwApple = .video(artista: "Sabrina", canción: "Boys")

switch wwwApple {
case .archivo(ruta: let ERRE, nombre: let FFF):
    ERRE
    FFF
    "archivito"
case .wwwURL(ruta: let R):
    R
    "ruta del sol"
case .video(artista: let TETAS, canción: let COME):
    TETAS
    COME
    "Sabrina: Boys"
}


switch wwwApple {
case .archivo(let ERRE, let FFF):
    ERRE
    FFF
    "archivito"
case .wwwURL(let R):
    R
    "ruta del sol"
case .video(let TETAS, let COME):
    TETAS
    COME
    "Sabrina: Boys"
}



switch wwwApple {
case let .archivo(ERRE, FFF):
    ERRE
    FFF
    "archivito"
case let .wwwURL(R):
    R
    "ruta del sol"
case let .video(TETAS, COME):
    TETAS
    COME
    "Sabrina: Boys"
}


wwwApple = Enlaces.wwwURL(
    ruta: URL(string: "https://www.apple.com")!
)

//if case let .wwwURL(ruta) == wwwApple {
//    ruta
//}

enum VehiculoT {
    case Carro(fabricante: String, modelo: String)
    case Moto(fabricante: String, año: Int)
    
    var fabricante: String {
        switch self {
        case let .Carro(fabricante, _):
            return fabricante
        case let .Moto(fabricante, _):
            return fabricante
        }
    }

}

let carro = VehiculoT.Carro(fabricante: "Tesla", modelo: "X")

switch carro {
case let .Carro(fabricante, _):
    fabricante
case let .Moto(fabricante, _):
    fabricante
}

let moto = VehiculoT.Moto(fabricante: "Honda", año: 1999)

switch moto {
case let .Carro(fabricante, _):
    fabricante
case let .Moto(fabricante, _):
    fabricante
}


func getFabricante(vehiculo: VehiculoT) -> String {
    switch vehiculo {
    case let .Carro(fabricante, _):
        return fabricante
    case let .Moto(fabricante, _):
        return fabricante
    }
}

Str = getFabricante(vehiculo: carro)
Str = getFabricante(vehiculo: moto)

carro.fabricante
moto.fabricante



enum Familia: String {
    case padre = "papá"
    case madre = "mamá"
    case hija = "bebé chiquita"
    case hermana = "sis"
    mutating func hacerMamá() {
        self = Familia.madre
    }
}

var hermana = Familia.hermana
hermana.hacerMamá()
hermana

// Recursión en enumerations

indirect enum Operacion {
    case suma(Int, Int)
    case resta(Int, Int)
    case libre(Operacion)
    func calculaRta(de operac: Operacion? = nil) -> Int {
        switch operac ?? self {
        case let .suma(A, B):
            return A + B
        case let .resta(A, B):
            return A - B
        case let .libre(operac ):
            return calculaRta(de: operac)
        }
    }
}

let libre = Operacion.libre(.suma(10, 20))
libre.calculaRta()



protocol PuedeSaltar {
    func salta()
}

protocol PuedeCorrer {
    func corre()
}

struct PersonaB: PuedeSaltar, PuedeCorrer {
    internal func salta() {
        print("Saltando!")
    }

    internal func corre() {
        print("Corriendo!")
    }

    let nombre: String
    let apellido: String
    
}

extension PersonaB {
    init(completo: String) {
        let componentes = completo
          .components(separatedBy: " ")  // herejía lo de .components?
        self.init(
            nombre: componentes.first ?? completo,
            apellido: componentes.last ?? completo
        )
    }
}

// Generic para múltiples protocolos
func saltaCorre<T: PuedeSaltar & PuedeCorrer>(_ valor: T) {
    valor.salta()
    valor.corre()
}

let Per3 = PersonaB(completo: "Fer Dager")
saltaCorre(Per3)




let Per1 = PersonaB.init(completo: "Edgar Fernando")
Per1.nombre
Per1.apellido

let Per2 = PersonaB.init(nombre: "Fernando", apellido: "Dager")




// en Swift 3, Numeric es SignedNumber
func realice<N: SignedNumber>(_ op: (N, N) -> N, entre AA: N, Y BB: N) -> N {
    return op(AA, BB)
}

realice(+, entre: 10, Y: 20)
realice(-, entre: 40.0, Y: 20.0)
realice(*, entre: 8, Y: 5)
realice(/, entre: 100.0, Y: 50.0)


func realicelo<N>(_ op: (N, N) -> N, entre AA: N, Y BB: N) -> N where N: SignedNumber {
    return op(AA, BB)
}

realicelo(+, entre: 10, Y: 20)
realicelo(-, entre: 40.0, Y: 20.0)
realicelo(*, entre: 8, Y: 5)
realicelo(/, entre: 100.0, Y: 50.0)


let x: CGFloat = 1.0


//extension [String] {
//    
//}


protocol View {
    func addSubView(_ view: View)
}

extension View {
    func addSubView(_ view: View) {
        "nada"
    }
}

struct Button: View {
    // "nada"
}

protocol PresentableComoView {
    associatedtype ViewType: View
    func produceView() -> ViewType
    func configure(superView: View, thisView: ViewType)
    func present(view: ViewType, on superView: View)
}

extension PresentableComoView {
    
}


let edad: Int? = 0

switch edad {
case .none:
    "No tengo edad"
case let .some(valor):
    "probablemente \(valor)"
}


struct Ruta {
    let conductor: String
    let direccion: Direccion?
    struct Direccion {
        let firstLine: String?
    }
}

let uber1: Ruta = Ruta(conductor: "Fer", direccion: Ruta.Direccion(firstLine: "Cra 4"))

if let uber1FL = uber1.direccion?.firstLine {
    "Recogida en camino \(uber1FL)"
} else {
    "nanain"
}

if let uber1FL = uber1.direccion,
    let primUber1 = uber1FL.firstLine {
    uber1FL
    primUber1
}

let uber2: Ruta? = Ruta(conductor: "Fer", direccion: Ruta.Direccion(firstLine: "Cra 5"))
if uber2?.conductor == "Fer",
    uber2?.direccion?.firstLine == nil {
    "no podía abrir porque Fer además direccion nil"
} else {
    "\(uber2!.direccion!.firstLine!)"
}

switch uber2?.direccion?.firstLine {
case let .some(firstLine) where firstLine.hasPrefix("Kra"):
    "primera Dir: \(firstLine)"
    break
case let .some(firstLine):
    "no concuerda con lo pedido anteriormente"
    break
case .none:
    "nanain"
    break
}


func dameNombreCompleto(nombre: String, apellido: String?) -> String? {
    if let apellido = apellido {  // Shadowing!
        return "\(nombre) \(apellido)"
    } else {
        return nil
    }
}

var completo = dameNombreCompleto(nombre: "Fer", apellido: "nando")

func dameNombreCompletito(nombre: String, apellido: String?) -> String? {
    guard let apellido = apellido else {  // Shadowing!
        return nil
    }
    return "\(nombre) \(apellido)"
}

completo = dameNombreCompletito(nombre: "Jen", apellido: "nifer")



