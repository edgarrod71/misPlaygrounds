import Foundation

import UIKit

class main: UIViewController {
    var str:String = "Hello, playground" // se puede obviar el tipo de dato :String
    
    //print("hola mundo")
    
    var entero:Int64 = 100;
    
    //print(entero)
    
    func suma(_ A:Int64, _ B:Int64) -> Int64 {
        var k:Int64 = 0
        for i in A...B {
            k = i + k;
        }
        return k
    }
    
    //print(suma(-100, 1000))
    
    var arreglo = ["uno", "dos", "tres"]
    
    //print("alfa", "beta", "omega", separator: ", ")
    
//    for i in arreglo {
    //print (i, terminator: ",\t")
//    }
    
    func esDoble(ArrChar a:String ...) -> Bool { // ArrChar es el label de la función, ... se define como muchos más parámetros del tipo anterior, String
        var isDub = true // Banderita
        for i in a {
            let DoubleCheck: Double? = Double(i) // Double(i) es de tipo asignable Double? si es así, entonces DoubleCheck se existirá en memoria
            if DoubleCheck == nil {
                isDub = false
            }
        }
        return isDub
    }
    
}

//This function takes a closure or function that returns an int and then just evaluates the function.
func a(closure a: () -> Int) -> Int {
    return a()
}
/*
//Without trailing closure syntax
a(closure: {return 1})
//With trailing closure syntax
a {return 1}
*/
//print (a)

/* // En este caso se simplifican 3 líneas en una
 let aTenant = aBuilding.tenantList[5]
 let theirLease = aTenant.leaseDetails
 let leaseStart = theirLease?.startDate
 
 let leaseStart = aBuilding.tenantList[5].leaseDetails?.startDate
 */

var miVariable:Int = 50
//miVariable = 44
let miConstante = 33
let explicito: Double = 10
let dejame: Float = 22

let etiqueta = "el ancho es "
let anchoEtiqueta = etiqueta + String(explicito)
//print(anchoEtiqueta)

let resumen = "Tengo estos datos: \(Float(miConstante)), \(dejame)"

//print(resumen)

var ocupaciones = [
    "Edgar": "Programador Software",
    "Fernando": "Desarrollador iOS"
]
//ocupaciones["Isabel"] = "Amor cansona"

//print(ocupaciones)

//let arrayVacio = String[]()
let emptyDict = Dictionary<String, Double>()

var optionalNom: String? = "Edgar Fernando" // if Assign(optionalNom) then optionalNom := 'Edgar Fernando'
var saludos:String = "Hola!" // Al definir explícito, le digo al compilador que no de tanta vuelta
//optionalNom = nil
//if let nombre = optionalNom { // Si la asignación no es nil, entonces salude
//    saludos = "\(saludos), \(nombre)"
//}


var vegetalStr:String = "hey"


let vegetal = "molacha"

/*
switch vegetal {
case "pepino":
    vegetalStr = "Agrega ketchup a tu ensalada"
case "zanahoria", "cebolla":
    vegetalStr = "Recuerda que es dulce"
case let x where x.hasSuffix("acha"): // arracacha, remolacha
    vegetalStr = "No te parece que la \(x) es dulce?"
default:
    vegetalStr = "No olvides agregar SAL"
}
*/

//print(vegetalStr)

let numerosInteresantes = [
    "Primo": [2, 3, 5, 7, 11, 13, 17, 19, 23],
    "Fibonacci": [1, 1, 2, 3, 5, 8],
    "Cuadrados": [2, 4, 9, 16, 25, 36, 49, 64, 8934567890098765432],
]

//print (numerosInteresantes)

var masAlto:Int! = 0 // Explícito y definitivo, me encanta Swift
var kClase:String! // con ! abrimos la asignación de memoria, es decir no preguntamos "?"
/*
for (clase, nums) in numerosInteresantes { // 2 variables en un Diccionario
    for N in nums { // N recorre nums
        if N > masAlto {
            masAlto = N
            kClase = clase
        }
    }
}
*/

//print("El más alto es: \(masAlto) que pertenece a la clase \(kClase)")
/*
for i in 0 ..< 3 {  // ... incluye al 3, de esta forma sólo llega hasta 2.
    i = i //print(i)
}
*/

func dameFinde() -> (Int, String, Double) {
    return (10000, "Fernando", 3.14)
}

// //print(dameFinde().1)


func promedioD(valores: Int...) -> Int {
    var suma:Int = 0
    for valor in valores {
        suma += valor
    }
    return (suma / valores.count)
}

// //print(promedioD(valores: 3, 4, 15, 10))


func retorna50() -> Int {
    
    var y = 10
    var z:Int = 0 // :Int es explícito
    func agregaCinco() {
        y += 5
    }
    func retorna20() -> Int {
        return (y + 20)
    }
    agregaCinco() // A esta altura 'y' vale 15
    z = retorna20() // Aquí se agrega 20 a 'y', z = 35
    return (y + z)
}

//print(retorna50())


// [Int] es Tipo Array
func hayCoincidentes(lista: [Int], condicion: (Int) -> Bool) -> Bool { // (Int) -> Bool toma la función menosQue10, cuyo parámetro para (Int) es _num
    for item in lista {
        if condicion(item) {
            return true
        }
    }
    return false
}

func menosQue10(_num: Int) -> Bool {
    return _num < 10
}


var numeros = [20, 19, 7, 12]

//print("tiene Coincidentes \(hayCoincidentes(lista: numeros, condicion: menosQue10))")

/*
numeros.map({  // Revisa esto, no se comprende bien
    (numero: Int) -> Int in // Parámetro (numero: Int) devuelve un Int, este closure no tiene nombre
    let resultado = 3 * numero
    return resultado
})

numeros.map({numero in 3 * numero})
*/
//print(numeros)




class Figura {
    var numLados: Int = 0
    var nombre: String
    var longLado: Double = 0.0
    var area: Double = 0.0
    func asignaMayor(valor: Double) {  // _ esto es &?, var en pascal? valor por referencia?
        longLado = valor
    }
    func descripcionSimple() -> String {
        return "una forma con \(numLados) lados"
    }
    init(nombre: String) {
        self.nombre = nombre
    }
}

class Cuadrado: Figura {
    init(name: String, longLado: Double) {
        super.init(nombre: name)
        super.longLado = longLado
        numLados = 4
        area = area()
    }
    
    func area() -> Double {
        super.area = longLado * longLado
        return super.area
    }
    
    override func descripcionSimple() -> String {
        return "Un cuadrado con lados que miden \(longLado)"
    }
}

class Circulo: Figura {
    init(nombeee: String, radio longLado: Double) {
        super.init(nombre: nombeee)
        super.longLado = longLado
        area = area()
    }
    func area() -> Double {
        super.area = 3.1416 * longLado * longLado
        return super.area
    }
}

let cuadro = Cuadrado(name: "jugador", longLado: 4.4)

//print("Area del cuadrado \(cuadro.nombre.uppercased()), mide \(cuadro.area), y se describe como: \(cuadro.descripcionSimple())")

let circulo = Circulo(nombeee: "bola8", radio: 5.5)

//print("Area del círculo \(circulo.nombre.uppercased()), mide \(circulo.area), y se describe como: \(circulo.descripcionSimple())")


class TrianguloEquilatero: Figura {
    init(nombre: String, longLado: Double) {
        super.init(nombre: nombre)
        super.longLado = longLado
        super.numLados = 3
    }
    var perimetro: Double { // Así se define perímetro como "property", una variable explícita con una funcion getter y un método setter
        get { return 3.0 * longLado }
        set {
            longLado = newValue / 3.0
            area = area()
        }
    }
    func area() -> Double {
        super.area = (sqrt(3)/4) * (longLado * longLado)
        return super.area
    }
    override func descripcionSimple() -> String {
        return "Un triángulo equilátero con lados de longitud \(longLado)."
    }
}

let triangulo = TrianguloEquilatero(nombre: "Pascal", longLado: 3.1)

//print("Triangulo que se llama \(triangulo.nombre), con perímetro \(triangulo.perimetro), y se describe como: \(triangulo.descripcionSimple())")
//triangulo.perimetro = 21
//print("Luego de verificar, al triángulo \(triangulo.nombre.uppercased()) se le ajustó el perímetro en \(triangulo.perimetro), y el nuevo lado mide \(triangulo.longLado)")
//print("El área de ese triángulo es \(triangulo.area)")



class Triangulo_Cuadrado {
    var triangulo: TrianguloEquilatero {
        willSet {
            cuadro.longLado = newValue.longLado
        }
    }
    var cuadro: Cuadrado {
        willSet {
            triangulo.longLado = newValue.longLado
        }
    }
    init(tam: Double, nombre: String) {
        cuadro = Cuadrado(name: nombre, longLado: tam)
        triangulo = TrianguloEquilatero(nombre: nombre, longLado: tam)
    }
}

var tri_cua = Triangulo_Cuadrado(tam: 10, nombre: "otro test de figuras")
//print("cuadro: \(tri_cua.cuadro.longLado)")
//print("triángulo: \(tri_cua.cuadro.longLado)")
//tri_cua.cuadro = Cuadrado(name: "cuadro más grande", longLado: 50)
//print("triangulo después de ajustar el cuadrado: \(tri_cua.triangulo.longLado)")


class Contador {
    var cuenta: Int = 0
    func incrementeEn(cantidad: Int, veces: Int) {
        cuenta += cantidad + veces
    }
}

var contador = Contador()
//contador.incrementeEn(cantidad: 2, veces: 7)

//print("cuenta: \(contador.cuenta)")

let cuadroOpcional: Cuadrado? = Cuadrado(name: "cuadro Opcional", longLado: 2.5)
let longLado = cuadroOpcional?.longLado

//print(longLado ?? 0) // Valor por defecto 0
//print(longLado!) // Unwrapping (apertura)
//print(longLado as Any) // cualquier cosa





enum Rango: Int {
    case As = 1
    case Dos, Tres, Cuatro, Cinco, Seis, Siete, Ocho, Nueve, Diez
    case Once, Reina, Rey
    func describeSimple() -> String {
        switch self {
        case .As:
            return "As"
        case .Once:
            return "J"
        case .Reina:
            return "Q"
        case .Rey:
            return "K"
        default:
            return String(self.rawValue)
        }
    }
    func intComparadoCon(A: Int) -> Int {
        if (A < self.rawValue) {
            return -1
        }
        if (A > self.rawValue) {
            return 1
        } else {
            return 0
        }
    }
    func comparadoCon(_ A: Rango) -> Bool {
        return A.rawValue == self.rawValue
    }
}

let ace = Rango.As
let aceRV = ace.rawValue
//print("Cartas: \(ace), \(aceRV), hash: \(ace.hashValue), desc: \(ace.describeSimple())")

let cinco = Rango.Cinco
let cincoRV = cinco.rawValue
//print("Cartas: \(cinco), \(cincoRV), desc: \(cinco.describeSimple())")

let jota = Rango.Once
let jotaRV = jota.rawValue
//print("Cartas: \(jota), \(jotaRV), desc: \(jota.describeSimple())")

let reina = Rango.Reina  // \(reina) está como enum y en \(descripción) está como String
//print("Cartas: \(reina), hash:\(reina.hashValue), desc: \(reina.describeSimple())")

/*
 if (reina.intComparadoCon(A: jota.rawValue)) != 0 {
 //print("valores distintos")
 } else {
 //print("valores IGUALES")
 }
 
 
 if jota != .Once {
 //print("diferentes")
 } else {
 //print("\(jota.describeSimple()) IGUAL con \(Rango(rawValue: 11)!)")
 }
 
 if reina.comparadoCon(.Rey) {
 //print("IGUALIIIITOS")
 } else {
 //print("DIFEREEENTES, pues \(Rango(rawValue: 13)!.describeSimple()) jamás será \(reina.describeSimple())")
 }
 
 if let rangoConverso = Rango(rawValue: 13) {
 let describeRey = rangoConverso.describeSimple()
 //print(String(describeRey)!)
 }
 */

enum TipoCarta: Int {
    case Espadas, Corazones, Diamantes, Picas
    func describeSimple () -> String {
        switch self {
        case .Espadas:
            return "Espadas"
        case .Corazones:
            return "Corazones"
        case .Diamantes:
            return "Diamantes"
        default:
            return "Picas"
        }
    }
    func color() -> String {
        switch self {
        case .Espadas, .Picas:
            return "negro"
        default:
            return "rojo"
        }
    }
}

struct Carta {
    var rango: Rango
    var tipo: TipoCarta
    func describeSimple() -> String {
        return "La carta es \(rango.describeSimple()) de \(tipo.describeSimple())"
    }
/*    func imprimeCartas() {
        for j in 0..<4 {
            for i in 1...13 {
                let colorStr = TipoCarta(rawValue: j)!.color()
                debug//print("\(Rango(rawValue: i)!.describeSimple()) de \(TipoCarta(rawValue: j)!) \(colorStr)")
            }
        }
    }*/
}

let tresEspadas = Carta(rango: .Tres, tipo: .Espadas)
//print(tresEspadas.describeSimple())
//tresEspadas.imprimeCartas()


enum respuestaServidor {
    case Result(String, String)
    case Error(String)
}

let exito = respuestaServidor.Result("6:00 am", "8:09 pm")
let falla = respuestaServidor.Error("Nos quedamos sin trago!")

//print(falla)
/*
switch exito {
case let .Result(amanecer, anochecer):
    let respuestaServidor = "El amanecer es a las \(amanecer) y el anochecer es a las \(anochecer)"
case let .Error(error):
    let respuestaServidor = "Fallo... \(error)"
}
*/
//print(respuestaServidor.Result("8:00 am", "11:00 pm"))



/***** PROTOCOLOS Y EXTENSIONES *******/

protocol EjemploProtocolo {
    var describe: String { get }
    mutating func ajustar()
}

/*class claseSimple: EjemploProtocolo {
    var describe: String = "Una clase muy simple"
    var salario: Int = 2456789
    func ajustar() {
        describe += " Ahora se ajustó 100%"
    }
}
*/
//var a = claseSimple()
//a.ajustar()
//let aDescripcion = a.describe

//print(aDescripcion)





/***** PROTOCOLOS Y EXTENSIONES *******/
/*
protocol EjemploProtocolo {
    var describe: String { get }
    mutating func ajustar()
}

class claseSimple: EjemploProtocolo {
    var describe: String = "Una clase muy simple"
    var salario: Int = 2456789
    func ajustar() {
        describe += " Ahora se ajustó 100%"
    }
}
*/
/*
 var a = claseSimple()
 a.ajustar()
 let aDescripcion = a.describe
 
 //print(aDescripcion)
 */


protocol ConvertibleString {
    func aCadena() -> String
}

extension String: ConvertibleString {
    func aCadena() -> String {
        return self
    }
}

let cad = "hola mundo"
let cade = cad.aCadena()

//print(cade)

//var algoParaImprimir: ConvertibleString
//algoParaImprimir = "hola Fercho"
//print(algoParaImprimir.aCadena())

let edadVotante = [20, 28, 19, 30]
var sonAdultos = true
/*for edad in edadVotante {
    if edad < 19 {
        sonAdultos = false
        break
    }
}
*/
//print(sonAdultos)
//print(Bool(edadVotante.first{ $0 <= 18 } == nil))

struct Item {
    var nombre: String
    var precioTotalVenta: Double
    var precioVenta: Double
    var cant: Int16
}

let inventario: [Item] = [
    Item(nombre: "Bola", precioTotalVenta: 6.95, precioVenta: 8.95, cant: 8),
    Item(nombre: "Bate", precioTotalVenta: 18.95, precioVenta: 22.5, cant: 8),
    Item(nombre: "Guante", precioTotalVenta: 35.15, precioVenta: 44, cant: 8),
    Item(nombre: "Camiseta", precioTotalVenta: 15.86, precioVenta: 22.5, cant: 8),
    Item(nombre: "Guayos", precioTotalVenta: 28.5, precioVenta: 39.75, cant: 8) //,
    //Item(nombre: "Gorra", precioTotalVenta: 6.95, precioVenta: 8.95, cant: 8)
    
]
/*
func valorVentaTotal(para inventario: [Item]) -> Double {
    inventario.reduce(0) { partialResult, item in partialResult + item.precioTotalVenta * Double(item.cant)
    }
    return 0.0
}


class Basecita {
    func hola(_ nombre: String = "Odin") {
        //print("Padre: \(nombre)")
    }
}

class Derivada: Basecita {
    override func hola(_ nombre: String = "Thor") {
        //print("hijo: \(nombre)")
    }
}*/
/*
let b = Basecita()
b.hola()

let d = Derivada()
d.hola()

let b2: Basecita = Derivada()
b2.hola()
*/











