import Foundation
//import UIKit


var str = "Hello, playground"

func depuraPrint(_ elementor: Any..., separador: String = " ", terminator: String = "\n") {
    //if debug
        print(elementor.map({ "\($0)" }).joined(separator: separador), terminator: terminator)
    //endif
}


depuraPrint("uno", 2, false, separador: "\n", terminator: "\t")
depuraPrint("dos", 4, false, separador: "\n", terminator: "\n")
depuraPrint("tres", 8, false, separador: "\t")


//-----------------------------------------------------------
// MARK:  Impresión Postfija de Paso
//-----------------------------------------------------------

postfix operator *?

/// Postfix printing for quick playground tests
public postfix func *?<T>(object: T) -> T {
    print("El objeto es: \(object)"); return object
}

postfix operator **?

/// Debug-only postfix printing
public postfix func **? <T>(object: T) -> T {
    depuraPrint(object)
    return object
}

postfix operator *?!

/// Postfix printing for quick playground tests
public postfix func *?!<T>(object: T) -> T {
    return dump(object)
}

postfix operator **?!

/// Debug-only postfix printing
public postfix func **?! <T>(object: T) -> T {
    #if debug
        dump(object)
    #endif
    return object
}


let patojita = 42

patojita*?
patojita**?
patojita*?!



//-----------------------------------------------------------
// MARK: Salida tipo Diagnóstico
//-----------------------------------------------------------

/// Muestra a fuente de archivo actual y línea.
/// Seguido de ?* o ?*! para imprimir/dump el elemento a ver en
/// ```
/// guard
///    here() ?* !histogram.isEmpty,
///    let image = here() ?* BarChart(numbers: histogram)
/// ```
/// de forma alterna, pendiente al final de las líneas donde se detiene la evaluación
/// ```
/// if
///    let json = try JSONSerialization
///        .jsonObject(with: data, options: []) as? NSDictionary, here("JSON"),
///    let resultsList = json["results"] as? NSArray, here("resultsList")
/// ```

func here(_ note: String = "", file: String = #file,
          line: Int = #line, cr: Bool = false) -> Bool {
    let filename = (file as NSString).lastPathComponent
    print(
        "[\(filename):\(line)\(note.isEmpty ? "" : " " + note)] ",
        terminator: cr ? "\n" : "")
    return true
}

/// Diagnostica el estado en condiciones compuestas.
/// Siempre retorna true, así no interfiere con la progresión de la condición.
/// ```
/// if
///    let json = try JSONSerialization
///        .jsonObject(with: data, options: []) as? NSDictionary,
///    diagnose(json),
///    let resultsList = json["results"] as? NSArray,
///    diagnose(resultsList),
/// ```
func diagnose(_ item: Any?) -> Bool {
    if let item = item { print(item) }
    else { print("nil") }
    return true
}


//-----------------------------------------------------------
// MARK: Impresión Diagnóstica Infija
//-----------------------------------------------------------

precedencegroup VeryLowPrecedence {
    associativity: right
    lowerThan: AssignmentPrecedence
}

/// Una alternativa de operador a diagnosticar, la que puede ser complicada de escribir.
/// Esto usa un operador de precedencia infija para permitir a la condición entera evaluarse e imprimirse antes de asignarse.
/// Ponga el argumento y operador en línea antes de la condición.
/// ```
/// guard let x = here() ?* complex condition statement, ...
/// ```
/// Usando here() como el primer argumento imprime la ubicación en código antes de hacer el volcado o imprimir


infix operator ?* : VeryLowPrecedence
infix operator ?*! : VeryLowPrecedence

/// Imprime rápido el siguiente elemento.  Operador infijo que requiere algunos valores (típicamente `here()`).  Si no quiere imprimir una ubicación, puede colocar un valor cualquiera antes del ?*.
func ?*<T>(_: Any, item: T) -> T {
    print(item); return item
}

///
/// Deseche completamente el siguiente elemento. Operador infijo, por lo que esto requiere algún valor (normalmente, `here()`) para seguir.  Si no desea imprimir una ubicación, puede colocar un valor cualquiera antes de ?*.
func ?*! <T>(_: Any, item: T) -> T {
    dump(item); return item
}


