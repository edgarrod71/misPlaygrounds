//import PlaygroundSupport
import Foundation
import CoreGraphics

//// RECOMIENDO QUE LEAS EL INSTRUCTIVO SOBRE ERRORES AL FINAL A PARTIR DE LA LÍNEA 660


//PlaygroundPage.current.needsIndefiniteExecution = true // para manejo de funciones y closures en Queues Asincrónicos

// Nota sobre Optionals, para entender los opcionales veamos...
//      if Assigned(Str) then ...  // str podría ser nil
// en Swift se entiende que una variable o cualquier tipo de dato puede o no contener un valor inicial.  (Podría entenderse que todo dato es puntero?)
//      var Str: String = "Hola mundo"  // Tiene valor
//      var Str: String = ""            // Vacío
//      var Str: String?  // nil        // No tiene valor o sea nil

//      var II: Int = 40_000    // tiene valor
//      var II: Int = 0         // vacío (0 es un valor)
//      var II: Int?            // no tiene valor o sea nil

//      var Arr: [Double] = [0.0]   // tiene 1 valor, 0.0
//      var Arr: [Double] = []      // vacío  ( var Arr = [Double]() )
//      var Arr: [Double]?          // no tiene valor o sea nil

//  ! significa Caja Abierta (Unwrapped) y, ? significa Caja Cerrada (Wrapped)

//      "Swift no introdujo Optionals, introdujo Non-Optionals". @ZevEisenberg

// SoSpEcHo que Swift maneja todo como punteros en Stack, es decir, si se pone
//      var II: Int = 100_000 // se podría entender en pascal así:

//      var II: ^Integer = nil;
//      II^ := 100000;  // ya no es nil y lo abre a fuerza pues da error, debería usarse getmem(II, sizeof(Integer)), al final liberarlo con freemem(II) pero todo esto va en contra de la optimización, a no ser que Swift lo haya hecho internamente por el usuario.


enum Errorcito: Error {
    case rangoInvalido(String)
    case sinRaiz(String)
}

var Arr = [0.0]
Arr = []

///********///**********///***********

var str = "Hola mundo"

let album = "Red"
let albums = ["Reputation", "Red", "1989"]
if let position = albums.index(of: album) {
    str = "Found \(album) at position \(position)."
}
let lineasA = albums.split(separator: " ")

let progsTV = ["Ted Lasso": "Netflix", "Bob Esponja": "Nickelodeon", "South Park": "Comedy"]
let favorito = progsTV["Lassy"] ?? "South Parque"
let lineasB = progsTV.split(whereSeparator: { (key: String, value: String) -> Bool in
    return key.contains(":")//key.hasSuffix(":")
})

struct Libro {
    let titulo: String
    let autor: String?
}

var B1: Libro? = nil
B1 = Libro(titulo: "100 años", autor: nil)
let Au = B1?.autor?.capitalized ?? "nada"


let names = ["Vincent": "van Gogh", "Pablo": "Picasso", "Claude": "Monet"]
let surnameLetter = names["Vincent"]?.unicodeScalars


enum eTotales: Error {
    case corto, obvio
}

func promedio(_ numeros: Double...) -> Double {
    var ST: Double = 0.0
    let cuenta: Double = Double(numeros.count)
    if cuenta != 0 {
        for A in numeros {
            ST += A
        }
        ST = ST / cuenta
    }
    return ST
}

var P = promedio(10, 20, 30, 40.4)
str = "Promedio \(P)"

func prueba() throws {
    throw eTotales.corto
}

do {
    try prueba()
} catch {}



enum ErrorStr: String, Error {
    case rangoInvalido = "El número debe ser el cuadrado exacto en absoluto, sin decimales"
    case nombreIncompleto = "El nombre debe estar con su apellido"
}

enum ErrorCad: Error {
    case rangoNoValido(String)
    case nomIncompleto(String)
}

enum ErroresNombre: Error {
    case nomVacio
    case apeVacio
}

func raizS(num: Int) throws -> Int? {
    let R: Range<Int> = 1..<1_000_001
    guard R.contains(num) else {
        throw ErrorCad.rangoNoValido("El número debe estar entre 1 y 10.000") }
    var r = 1
    let CR = CountableRange(R)
    /*
     let tol = 1  // Helon
     while abs(r * r - num) > tol {
     r = (r + num / r) / 2
     if r <= 1 {
     return nil
     }
     } */
    for N in CR {
        if N * N == num {
            r = N; break
        }
    }
    if r == 1 && num > r { return nil }
    return r
}


// ojo que esta función no botaba THROWS, si lo colocas, verás cambios en los demás bloques...
func dameNombreCompleto(nombre: String, apellido: String?) /* throws */ -> String? {
    if let apellido = apellido, !apellido.isEmpty {  // Shadowing!
        return "\(nombre) \(apellido)"
    } else {
        return nil
    }
}


// en vez de esto:

do {
    guard let result = dameNombreCompleto(nombre: "Edgar", apellido: nil) else {
        throw ErrorStr.nombreIncompleto }
    result
} catch ErrorStr.nombreIncompleto {
    ErrorStr.nombreIncompleto.rawValue
}

do {
    guard let result = dameNombreCompleto(nombre: "Edgar", apellido: nil) else {
        throw ErrorStr.nombreIncompleto }
    result
} catch {           // todo catch tiene la variable error que contiene
    switch error {  // el tipo de dato y su correspondiente valor
    case ErrorStr.nombreIncompleto:
        ErrorStr.nombreIncompleto.rawValue
    default:
        "niansesabe"
    }
}

do {
    guard let result = dameNombreCompleto(nombre: "Edgar", apellido: nil) else {
        throw ErrorCad.nomIncompleto("Esperando un nombre con apellido") }
    result
} catch let E as ErrorCad  {
    switch E {
    case let .nomIncompleto(respuesta): // se está asignando respuesta (String)
        respuesta
    default:
        "niansesabe"
    }
}


// hacer esto es más sencillo, se llama Optional Try

if let erre = try? raizS(num: 144) {
    if erre == nil {
        "Pos no se pudo"
    } else {
        erre
    }
} else {
    "Algún otro error"
}


// esto no necesita Optional Try pues la función no tiene THROWS
if let completito = dameNombreCompleto(nombre: "Jenny", apellido: "Daniela") {
    completito
} else {
    "error"
}



/// CASO ESPECIAL pues sí tiene THROWS (Y RETHROWS)

func nomCompleto(nombre: String?, apellido: String?, operacion: (String?, String?) throws -> String?) rethrows -> String? {
    return try operacion(nombre, apellido)  // WOW
}

func + (nombre: String?, apellido: String?) throws -> String? {
    guard let nombre = nombre, !nombre.isEmpty else {
        throw ErroresNombre.nomVacio
    }
    guard let apellido = apellido, !apellido.isEmpty else {
        throw ErroresNombre.apeVacio
    }
    return "\(nombre) \(apellido)"
}

do {
    let fooBar = try nomCompleto(nombre: nil, apellido: "Dager", operacion: +)
    fooBar
} catch let e as ErroresNombre {
    switch e {
    case .nomVacio: "Error de nombre"
    case .apeVacio: "Error de apellido"
    }
}

if let fooBar = try? nomCompleto(nombre: nil, apellido: "Dager", operacion: +) {
    fooBar
} else {
    "ni idea"
}


class DriversLicense {
    var puntos: Int = 0
}

class Conductor {
    var licencia: DriversLicense? // Si no tiene ? chilla porque Conductor no tiene inicializadores
}

let fer = Conductor()
if let licencia = fer.licencia {
    "tiene! \(licencia.puntos) puntos"
} else {
    "no tiene licencia"
}

let puntosLicencia = fer.licencia?.puntos
if let puntos = puntosLicencia {
    "tiene! \(puntos) puntos"
} else {
    "sigue sin tener licencia"
}

let puntillas = 4
//fer.licencia?.puntos = puntillas


var catalogo = ["Honda": (minPrecio: 1000, maxPrecio: 1_000_000)]
let precio = catalogo["Honda"]!.maxPrecio
var honda = catalogo["Honda"]


/// *******   T U P L A S  +++++++++++++

let tuplaVacia: ()? = ()  // No tiene utilidad, sólo es curioso
let tuplaSimple = (valorUnico: 1.0)
let TV = tuplaSimple
let recur = (uno: "hola", dos: true, tres: (cua: 4, cin: 5.0))
recur.tres.cin
type(of: recur)

let recur2: (String, Bool, (Int, Double)) = (uno: "hola", dos: true, tres: (cua: 4, cin: 5.0))
recur2.2.1  // cuando se pone la definición de tipo los nombres internos de la tupla desaparecen

let (uno, dos, (cua, cin)) = recur2  // tuplas dentro de tuplas
uno
cin

let ciudades = ["Santander":"Bucaramanga", "Magdalena":"Santa Marta", "Antioquia":"Medellín", "Valle":"Cali", "Atlántico":"Barranquilla"]

for (dpto, capital) in ciudades {
    // print("\(dpto), \t \(capital)")
}

let (_, _, soloNums) = recur2 // cuando sólo nos interesa el último de la tupla
soloNums.1

var (siete, ocho, nueve) = (7, 8, 9) // inicializar variables en una sola línea
nueve

(ocho, nueve) = (nueve, ocho) // intercambiar valores es más simple
ocho  // es el nuevo nueve (9)

let tupParam = (n: 1_000, s: "hola", b: true)

func trabajaTupla(tupla: (num: Int, str: String, bool: Bool)) -> (cad: String, bull: Bool, cant: Int) {
    return (tupla.str, tupla.bool, tupla.num)
}

var tupResult: (String, Bool, Int) = ("", false, 0)
tupResult.2

// desde Swift 3 quitaron el poder agregar como parámetro a una tupla
tupResult = trabajaTupla(tupla: (tupParam.n, tupParam.s, tupParam.b))
tupResult.2


func transformar(coords:(X: Double, Y: Double, Z: Double)...) -> [(x: Double, y: Double, z: Double)] {
    return coords.map{($0.X, $0.Y * 2, $0.Z)}
}

let TT = transformar(coords: (1.0, 2.0, 1.5), (2.0, 3.0, 4.0)) // retorna [(1.0, 4.0, 1.5), (2.0, 6.0, 4.0)]
TT[1].y  // por xtraña razón el etiquetado regresa


var diasLaborales1:[Int] = [1, 2, 3, 4, 5]
var diasLaborales2:(lun: Int, mar: Int, mié: Int, jue: Int, vie: Int, sáb:Int, dom:Int) = (1, 2, 3, 4, 5, 6, 7)
diasLaborales2.sáb

enum FileError: Error {
    case notFound(String)
    case unknown(String)
    case theFile(String)
}

func escribeArchivo() throws {
    let nomArchivo = "pruebita.txt"
    let rutaDoc = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
    let ruta = "\(rutaDoc)/\(nomArchivo)"
    // print(ruta)
    // throw Opcional.other("ni idea")

    "Abriendo el archivo..."
    guard let archivo = FileHandle(forUpdatingAtPath: ruta) else {
        "No se encontró el archivo"
        throw FileError.theFile("Archivo no se encontró")
    }

    defer { // la sentencia "defer" provee una limpia forma de manejar situaciones cuando se debe ejecutar código justo antes de que la ejecución salga del bloque de código activo
        "cierre y vámonos"
        archivo.closeFile()
    }

    "Tomando datos"
    let datos = ("Hola mundo, cómo estás niño?" as NSString).data(using: String.Encoding.utf8.rawValue)

    archivo.seek(toFileOffset: 0)

    "Escribiendo datos"
    archivo.write(datos!)

    // aquí debería estar el "cierre y vámonos junto con el cierre del archivo pero es manejado por el "defer" de arriba.
}



do {
    try escribeArchivo()
} catch {
    switch error as! FileError {
    case let .notFound(fraseE):
        fraseE
        //        "Creando el archivo..."
        //        guard let archivo = FileHandle( else {
        //            "No se encontró el archivo"
        //            throw FileError.notFound("Archivo no se encontró")
    //        }
    default:
        "niansesabe pelaíto"
    }

}


////////////// ENUM GENERICO //////////////

enum Opcional<T>: Error {
    case notFound(String)
    case negativeValue(T)
    case exitoso(T)
    case other(T)
    case err(Error)
    case ningúnError
}

func log(descripcion: () throws -> String) rethrows -> () {
    str = try descripcion()
}

func nonThrowing() -> String {
    return "nananana"
}

func throwing() throws -> String { // prueba cualquiera de las siguientes líneas
    // return "Sing a sad song and make it better"
    throw Opcional<String>.other(nonThrowing())
    // throw FileError.unknown("Homero Falla")
    // throw Opcional<String>.notFound("ni idea mi hermano")
}

let result = try? throwing()

log(descripcion: { "Free Guy" }) // imprime Free Guy

log(descripcion: nonThrowing)  // imprime nananana

do {
    try log(descripcion: throwing)
} catch let e as FileError{
    switch e {
    case let .unknown(msg):
        msg
    default: "desconocido"
    }
} catch let f as Opcional<String> {
    f
    switch f {
    case let .notFound(msg):
        msg
    case let .other(throwing):
        throwing
    default: "caramba ay"
    }
} catch {
    error
}


func auch(completion: () throws -> String) rethrows -> String {
    do {
        return try completion()
    } catch {
        error
        throw Opcional<String>.notFound("ni idea mi hermano") // si no se relanza esta u otra excepción, da error de falta de retorno
    }
}

do {
    print(try auch { () throws -> String in
        throw Opcional<String>.ningúnError })
} catch {
    error
}



enum InputError: Error {
    case faltaMarca
    case kmMuyBajo(Int)
    case kmMuyAlto(Int)
}

func debieraComprarCarro(marca: String, kms: Int) throws {
    guard marca.characters.count > 0 else {
        throw InputError.faltaMarca
    }
    switch kms {
    case kms where kms <= 10:
        throw InputError.kmMuyBajo(kms)
    case kms where kms >= 100:
        throw InputError.kmMuyAlto(kms)
    default: "Cómpralo"
    }
}

do {
    try debieraComprarCarro(marca: "", kms: 190)
} catch let Err as InputError {
    switch Err {
    case .faltaMarca: "falta marca"
    case let .kmMuyAlto(K) where K > 150: "\(K) son demasiados kilómetros"
    case let .kmMuyAlto(K): "\(K) sigue siendo alto"
    default: Err
    }
} catch {
    error
}

func cuadradoPositivo(valor: Int) throws -> Int {
    guard valor >= 0 else {
        throw Opcional<Int>.negativeValue(valor)
    }
    return valor * valor
}


do {  // hermoso todo este bloque
    let val1 = try cuadradoPositivo(valor: -10)
} catch let error as Opcional<Int> {
    error
    if case let .negativeValue(val) = error {
        print("El valor \(val) es negativo")
    }
}




/// OPERACIONES ASÍNCRONAS

// importante para manejo de sincronía agregue en el Playground
// import PlaygroundSupport
// PlaygroundPage.current.needsIndefiniteExecution = true



/// 1. Manejo simple de un método asíncrono

func operAsincrona1(termino: @escaping (String) -> ()) -> Void {
    DispatchQueue.global().async {
        let saludo = "1. Hola, mundo asincrónico!"
        DispatchQueue.main.async {
            termino(saludo)
        }
    }
}

func manejaTermino1(saludo: String) {
    print(saludo)
}

operAsincrona1(termino: manejaTermino1)


/// 2. Al tomar un método que lanza una excepción (al ejemplo, un error dentro de la operación asincrónica), el método manejador hace su trabajo con la excepción

func operaThrowingString() throws -> String { // en vez de retornar un String, lanza una excepción, se usa en los siguientes ejemplos
    throw Opcional<String>.ningúnError
}

func operAsincrona2(operacion: @escaping () throws -> String, termino: @escaping (String?) -> ()) -> Void {
    DispatchQueue.global().async {
        // hace cualquier cosa, por ejemplo que resultado sea nil (error!)
        var resultado: String? = nil //"Plutón es un planetaaaa"
        do {
            resultado = try operacion()
        } catch {
            error
        }
        DispatchQueue.main.async {
            termino(resultado)
        }
    }
}

func manejaTermino2(result: String?) {
    print(result ?? "2. hola planeta asincrónico \(result)")
}

operAsincrona2(operacion: operaThrowingString, termino: manejaTermino2)



/// 3. Retornamos un error que ocurrió antes de ingresar o ser llamado por la operación asíncrona

func operaNotThrowingString() throws -> String {
    //throw Opcional<String>.ningúnError // lanza una excepción
    return "3. Cierto compadre?"
}

func operAsincrona3(operacion: @escaping () throws -> String, termino: @escaping (Opcional<String>) -> ()) -> Void {
    DispatchQueue.global().async {
        var resultado: Opcional<String>
        do {
            let salida = try operacion()
            resultado = .exitoso(salida) // cambie por un método que no lance una excepción y verá el resultado
        } catch {
            resultado = .err(error)  // aquí se recibe el error
        }
        DispatchQueue.main.async {
            termino(resultado)  // entra un Optional<String> como parámetro
        }
    }
}

func manejaTermino3(result: Opcional<String>) {
    switch result {
    case let .exitoso(val):
        print(val)
    case let .err(error):
        print(error)
    default: "niansesabeeee"
    }
}

operAsincrona3(operacion: operaNotThrowingString, termino: manejaTermino3) // quítale el Not a operacionNotThrowingString y analiza


/// 4. Closure Interno. El más complejo.  Revisa bien este código.

func operAsincrona4(operacion: @escaping () throws -> String, termino: @escaping (_ closureInterno: () throws -> String) -> Void) -> Void {
    DispatchQueue.global().async {
        var resultado: () throws -> String
        do {
            let salida = try operacion()
            type(of: salida)
            resultado = { salida }  // este es el closure interno
            type(of:resultado)
        } catch {
            resultado = { throw error }  // relanza el error!
        }
        DispatchQueue.main.async {
            termino(resultado)
        }
    }
}

func manejaTermino4(result: () throws -> String) {
    do {
        let valor = try result()
        print(valor)
    } catch {
        print(error)
    }
}

operAsincrona4(operacion: { () throws -> String in throw Opcional<String>.exitoso("4. Exitoso Lanzamiento") }, termino: manejaTermino4)
operAsincrona4(operacion: { throw Opcional<String>.notFound("4. Not Found: Lanzado sin parámetros en el closure ") }, termino: manejaTermino4)
operAsincrona4(operacion: { "4. después de return!" }, termino: manejaTermino4)



/// Defer!  Postergar pero ejecutar antes que se salga del bloque de código activo. El mejor uso para esta palabra reservada es de limpiar recursos dentro de un programa.  Evitar su uso masivo.

func suma3(num: inout Int) {
    defer {
        print("A \(num)")
        num = num * 10
        print("B \(num)")
    }
    print("C \(num)")
    num = num + 5
    print("D \(num)")
}

var numero = 1

suma3(num: &numero)
numero



/////////// INSTRUCTIVO SOBRE MANEJO DE ERRORES ////////////////

/// Formas de manejar las excepciones y/o errores:

//do
//try
//catch
//throw
//throws

extension BinaryFloatingPoint {

    /// Returns a random floating point number between 0.0 and 1.0, inclusive.
    public static var randomFP: Self {
        return Self(arc4random()) / 0xFFFFFFFF
    }

    /// Random double between 0 and n-1.
    /// - Parameter n:  Interval max
    /// - Returns:      Returns a random double point number between 0 and n max
    public static func randomFP(min: Self, max: Self) -> Self {
        return Self.randomFP * (max - min) + min
    }
}

let pruebaFP = Double.randomFP

extension ClosedRange where Bound: UnsignedInteger {
    public func random(in rango: ClosedRange<UInt32>) -> Bound {
        let rango = self.upperBound - self.lowerBound
        let result = (Bound(UIntMax(arc4random_uniform(UINT32_MAX))) / Bound(UIntMax(UINT32_MAX))) * rango + self.lowerBound
        return result
    }
}

extension ClosedRange where Bound: FloatingPoint {
    public func random() -> Bound {
        let rango = self.upperBound - self.lowerBound
        let result = (Bound(arc4random()) / Bound(UIntMax(UINT_FAST32_MAX))) * rango + self.lowerBound
        return result
    }
}

extension Int {
    static func random(in rango: CountableClosedRange<Int>) -> Int {
        let lower = UInt32(rango.lowerBound)
        let upper = UInt32(rango.upperBound)
        let result = Int(arc4random_uniform(upper - lower) + lower)
        return result
    }
}

extension Collection {
    public func random() -> Self._Element {
        if let idxInicial = self.startIndex as? Int {
            let inicio = UInt32(idxInicial)
            let fin = UInt32(self.endIndex as! Int)
            return self[Int(arc4random_uniform(fin - inicio) + inicio) as! Self.Index]
        }
        var generator = self.makeIterator()
        var count = arc4random_uniform(UInt32(self.count as! Int))
        while count > 0 {
            generator.next()
            count -= 1
        }
        return generator.next() as! Self._Element
    }

}

let comaM: CGFloat = (0.0...1.0).random()
(0...1).random()
["a", "b", "m"].random()
["a": 1, "b": 3, "c": 5].random()

let ronDamon = (-0.4...0.4).random()
type(of: ronDamon)

/// Antes de majenar las excepciones, lo podemos hacer mediante un enum o cualquier objeto que tenga el protocolo Error

enum SimpleCustomError: Error {
    case someError
}

/// do-try-catch — do-catch nos permitirá "atrapar" y manejar los errores lanzados desde un bloque de código mediante el bloque 'do'.

enum ErrorPersonalizado: Error {
    case algunError(mensaje: String)
}

func algunaFuncion() throws  {
    let randomNum = Int.random(in: 0...1)
    if randomNum == 0 {
        throw ErrorPersonalizado.algunError(mensaje: "Ocurrió un errorcito")
    } else {
        print("algunaFuncion trabajó bien")
    }
}

do {
    try algunaFuncion()
} catch SimpleCustomError.someError {
    print("Atrapé un Error dado: ErrorPersonalizado.algunError")
} catch {
    print("Error desconocido \(error)")
}

/// Lanzando la función - Podemos lanzar errores usando la palabra reservada "throws" al final de la definición de la función o "throw" dentro del bloque de código.

/// recordemos que arriba está definido el enum ErrorPersonalizado

func otraFuncion() throws  {
    let randomNum = Int.random(in: 0...1)
    if randomNum == 0 {
        throw ErrorPersonalizado.algunError(mensaje: "Error al generar un aleatorio")
    } else {
        throw ErrorPersonalizado.algunError(mensaje: "Ocurrió algún otro error")
    }
}

try otraFuncion()

/// try - Podemos usar la función con try antes de que lance un error que indique que esté pendiente de un error potencial y cómo podemos manejarlo.

func terceraFuncion() throws -> Int {
    let randomNum = Int.random(in: 0...1)
    if randomNum == 0 {
        throw ErrorPersonalizado.algunError(mensaje: "Algo sucedió")
    } else {
        return 100
    }
}

do {
    try terceraFuncion()
} catch SimpleCustomError.someError {
    print("Atrapé un error dado: ErrorPersonalizado.algunError")
} catch {
    print("Error desconocido \(error)")
}

/// try! - No debemos usar esta función sólo si estamos seguros que la función no lanzará error alguno.

func cuartaFunction() throws -> Int {
    let randomNum = Int.random(in: 0...1)
    if randomNum == 0 {
        throw SimpleCustomError.someError
    } else {
        return 100
    }
}

let resultado = try! cuartaFunction()
print("Resultado \(resultado)")


/// try? - Opcional pero puede contener una respuesta o error. Esto desactiva el bloque catch y si algún error ocurre, sólo retornará nil.


func quintaFuncion() throws -> Int {
    let randomNum = Int.random(in: 0...1)
    if randomNum == 0 {
        throw SimpleCustomError.someError
    } else {
        return 100
    }
}
let resultadoQuinto = try? quintaFuncion()
print("Resultado \(resultadoQuinto ?? 0)")


