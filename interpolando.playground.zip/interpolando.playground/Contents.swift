//: Playground - noun: a place where people can play
import UIKit
import PlaygroundSupport

extension BinaryFloatingPoint {
    public var doubleValue: Double {
        guard !(self is Double) else { return self as! Double }
        guard !(self is Float) else { return Double(self as! Float) }
        guard !(self is Float80) else { return Double(self as! Float80) }
        guard !(self is CGFloat) else { return Double(self as! CGFloat) }
        fatalError("Tipo de punto flotante no-soportado")
    }
}

public enum CurvaInterpolada { case lineal, easeIn, easeOut, easeInOut }

public protocol Interpolando {
    func interpolar(a valor: Self, en porcentaje: Double, curva: CurvaInterpolada) -> Self
}

extension BinaryFloatingPoint {
    public func interpole(al valor: Self, by percent: Double, estilo: CurvaInterpolada = .lineal) -> Self {
        let distancia = (valor - self).doubleValue
        switch estilo {
        case .lineal:
            return self + Self(distancia * percent)
        case .easeIn:
            return self + Self(distancia * pow(percent, 3))
        case .easeOut:
            return self + Self(distancia * (1 - pow(1 - percent, 3)))
        case .easeInOut where percent < 0.5:
            return self + Self(0.5 * distancia * pow(percent * 2, 3))
        case .easeInOut:
            return self + Self(0.5 * distancia * (2 - pow(2 - 2 * percent, 3)))
        }
    }
}

extension CGPoint: Interpolando {
    public func interpolar(a valor: CGPoint, en porcentaje: Double, curva: CurvaInterpolada) -> CGPoint {
        return CGPoint(
            x: self.x.interpole(al: valor.x, by: porcentaje, estilo: curva),
            y: self.y.interpole(al: valor.y, by: porcentaje, estilo: curva)
        )
    }
}

let p1 = CGPoint.zero
let p2 = CGPoint(x: 1, y: 1)

for porcentaje in stride(from: 0.0, through: 1.0, by: 0.25) {
    let px = p1.interpolar(a: p2, en: porcentaje, curva: .easeInOut)
    print(px)
}

for percent in stride(from: 0.0, through: 1.0, by: 0.05) {
    0.0.interpole(al: 1.0, by: percent, estilo: .lineal)
    0.0.interpole(al: 1.0, by: percent, estilo: .easeIn)
    0.0.interpole(al: 1.0, by: percent, estilo: .easeOut)
    0.0.interpole(al: 1.0, by: percent, estilo: .easeInOut)
}
