
#if os(iOS)
    import UIKit
    public typealias Color = UIColor
#elseif os(macOS)
    import AppKit
    import Cocoa
    public typealias Color = NSColor
#endif

import UIKit
import Darwin
import Foundation
import CoreGraphics
//import PlaygroundSupport
//
//PlaygroundPage.current.needsIndefiniteExecution = true


// swiftlint:disable identifier_name
var str: String!
var dd: Double!
var ii: Int?
var bb: Bool?
var optionalName: String?
var vegetalStr: String! = "hey"

var cad: String = "Sólo me faltabas tú para ser feliz"

let abece = ["a", "b", "c"] as Set // de Array a Set mediante casting

let efege = Array(abece)

efege.count
efege.endIndex
type(of: efege.endIndex)

let diccio = [1: 20, 2: 30, 3: 40, 4: 50]
diccio.endIndex
type(of: diccio)


let cedulaNo = 91439275
let cedulaStr = String(cedulaNo)
let cedulaChrs = String(cedulaNo).characters

let cedulaArr1 = cedulaStr.characters.map { $0 } // 1. convierte de string a Array
let cedulaArr2 = Array(cedulaStr.unicodeScalars).map { String($0) } // 2. Str a Array
let cedulaArr3 = Array(cedulaChrs) // 3. CharacterView to Array
let cedulaArr4 = Array(String(cedulaNo).characters) // 4. CharacterView to Array

cedulaArr1
cedulaArr2.contains("9")

let cedulaCad = [String]((65...90).map { String(UnicodeScalar($0)) })

cedulaCad

[9, 1, 4, 3, 9, 2, 7, 5].map(String.init) // convierte cada dígito de un array en String


let cedula = [9, 1, 4, 3, 9, 2, 7, 5].map { String($0) }.joined()
cedula
Array(0...9).map(String.init)
let from0To9 = Array(98...107).map { String($0) }
from0To9
let cuentaDe9A19 = [Int](9..<20) // Array con rango demasiado práctico
let deBaJ = [Character]((98..<107).map { Character(UnicodeScalar($0)) }) // Array de letras ASCII
deBaJ
let DBAJ = [Character]((98..<107).flatMap { Character(UnicodeScalar($0)) })
DBAJ
let de0a9 = Array(48...57).map { String(UnicodeScalar($0)) } // Array de dígitos
de0a9
str = ""
for a in de0a9 {
    str.append(a)
}
str

/// Decenas
let decenas: [Int] = [4, 5, 6, 9, 7].map { $0 * 10 }
print("las decenas son \(decenas)")







enum Errorcito: Error {
    case rangoInvalido(String)
    case sinRaiz(String)
}

Errorcito.rangoInvalido("cualquiera")._code
Errorcito.sinRaiz("arbolito de navidad")._domain



struct Equipo {
    var nombre: String
    var estrellas: Int
}

let campeonato = [
    Equipo(nombre: "Millos", estrellas: 16),
    Equipo(nombre: "America", estrellas: 14),
    Equipo(nombre: "Nacional", estrellas: 18),
    Equipo(nombre: "Alianza P", estrellas: 1),
    Equipo(nombre: "Santa Fe", estrellas: 13),
    Equipo(nombre: "Bucaramanga", estrellas: 1),
    Equipo(nombre: "Junior", estrellas: 11),
    Equipo(nombre: "Pasto", estrellas: 1)
]

var mayoresA10: (Equipo) -> Bool = { EQ in // equi es el parámetro que representa una variable de tipo Equipo
    EQ.estrellas >= 10
}

func menoresA10(eki: Equipo) -> Bool {
    return eki.estrellas < 10
}

let mejoresEq = campeonato.filter(mayoresA10)

let menoresEq = campeonato.filter { $0.estrellas < 10 }

for EQ in mejoresEq {
    print(EQ.nombre)
}


let fraseCompleta = "Esta es una frase bien completa qué sucede que no sigue"
// print("\(fraseCompleta)") // no es necesario imprimir todas las veces en PlayGround

var consonantes = String()

for A in fraseCompleta.characters {
    var existe = false
    for B in " aeiouAEIOUÑñáéíóúÁÉÍÓÚÜü".characters where B == A {
        existe = true
        break
    }
    if !existe {
        consonantes.append(A)
    }
}
"funciona, pero no en una línea: \(consonantes)"
//print("funciona, pero no es en una línea: \(consonantes)")

let conson = fraseCompleta.characters.filter { !" aeiouAEIOUÑñáéíóúÁÉÍÓÚÜü".characters.contains($0) }
"esta es la mejor forma: \(String(conson))"
// print("esta es la mejor forma: \(String(conson))")

consonantes.removeAll()
for caracter in fraseCompleta.characters {
    if !" aeiouAEIOUÑñáéíóúÁÉÍÓÚÜü".characters.contains(caracter) {
        consonantes.append(caracter)
    }
}
"consonantes: \(consonantes)"


cicloExterno: for ii in 1...10 {
    for j in 1...10 {
        print("\(ii) times \(j) = \(ii * j)")
        if j == 5 {
            print("mijo, hasta 30 te llegó el tren")
            break cicloExterno
        }
    }
}


var puntuacion: [String : [Int]] = ["Fernando" : [10, 9, 8], "Jenny" : [7, 6, 5]]

puntuacion["Fernando"]?[0] = 3
puntuacion["Fernando"]?[1] -= 2
puntuacion["Fernando"]?[2] += 1

puntuacion["Fernando"]?[0]
puntuacion["Fernando"]?[1]
puntuacion["Fernando"]?[2]


let op01: Int? = 4
let num1: Int = 14
let op02: Int?

op02 = Optional(num1)
print((op01?.advanced(by: 100))!)
print("\(op02!)")

op01?.distance(to: op02!)

guard let op01 = op01 else {  // qué interesante! op01 ya no es Optional, se cambió!
    fatalError("op01 es nil")
}

op02?.distance(to: op01)


func miNombre() -> String {
    return "Fernando"
}

class ClasePereza {  // Excelente forma de entender lazy
    lazy private var propPerezosa: String = miNombre()
    var description: String {
        var N: String = "nombre: "
        N += propPerezosa
        return N
    }
}

var cp = ClasePereza()
cp
cp.description
cp

let argv = ProcessInfo.processInfo.arguments
let nomApp = (argv[0] as NSString).lastPathComponent
let appName = ProcessInfo.processInfo.processName


extension String {
    // Retorna una nueva cadena hecha al remover espacios en blanco en inicio y fin de la cadena original.  Los espacios en blanco se definen como Categoría General Unicode Z*, U+000A ~ U+000D, and U+0085.  Esto como función retorna un String al no tener mutating, no modifica la cadena que la invoca.
    public func trimmed() -> String {
        return self.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    /// - Retorna:  Una cadena recortada de espacios en blanco inicial y terminal.  Como tiene mutating, recorta la misma cadena que la invoca.
    @discardableResult
    public mutating func trim() -> String {
        self = self.trimmed()
        return self
    }

    var count: Int { return characters.count }
}

var que_haras: String = "   voy a cagar, y estaré limpio   "
    que_haras.trim()  // Permanece recortado
var que_hiciste = "     ya cagué, mira no te limpiaste     "
    que_hiciste.trimmed() // No permanece recortado
// Resultados, al final de todo
que_hiciste
que_haras


["a", "b", "c"].map { $0.uppercased() }

let letrasPopeye = ["Popeye", "the", "Sailorman"].map { $0.characters.count }



// OptionSet, no lo conozco, TODO: CONOCERLO!

public extension OptionSet where RawValue == Int {
    // Thanks Ian Keen
    static func option(_ level: RawValue) -> Self {
        assert(level > 0, "Las Opciones deben ser mínimo 1")
        return .init(rawValue: 1 << (level - 1))
    }
}

public struct OptionSetEx: OptionSet {
    public typealias RawValue = Int
    public var rawValue: RawValue = 0
    public init(rawValue: OptionSetEx.RawValue) { self.rawValue = rawValue }

    public static let option1 = option(1)
    public static let option2 = option(2)
    public static let option3 = option(3)
    public static let option4 = option(4)
}

var mySet: OptionSetEx = []  // OptionSetEx vacío
print(mySet.rawValue)
mySet.formUnion([.option1, .option3])
print(mySet.rawValue)
mySet.formUnion([.option2, .option3])
print(mySet.rawValue)


