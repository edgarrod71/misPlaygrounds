import UIKit

extension BinaryFloatingPoint {
    public var doubleValue: Double {
        guard !(self is Double) else { return self as! Double }
        guard !(self is Float) else { return Double(self as! Float) }
        guard !(self is Float80) else { return Double(self as! Float80) }
        guard !(self is CGFloat) else { return Double(self as! CGFloat) }
        fatalError("Tipo de punto flotante no soportado.")
    }
}

public enum InterpolationCurve { case linear, easeIn, easeOut, easeInOut }

public protocol Interpolating {
    func interpolate(to value: Self, by percent: Double, curve: InterpolationCurve) -> Self
}

extension BinaryFloatingPoint {
    public func interpolate(a valor: Self, by percent: Double, style: InterpolationCurve = .linear) -> Self {
        let distance = (valor - self).doubleValue
        switch style {
        case .linear:
            return self + Self(distance * percent)
        case .easeIn:
            return self + Self(distance * pow(percent, 3))
        case .easeOut:
            return self + Self(distance * (1 - pow(1 - percent, 3)))
        case .easeInOut where percent < 0.5:
            return self + Self(0.5 * distance * pow(percent * 2, 3))
        case .easeInOut:
            return self + Self(0.5 * distance * (2 - pow(2 - 2 * percent, 3)))
        }
    }
}

for percent in stride(from: 0.0, through: 1.0, by: 0.05) {
    0.0.interpolate(a: 1.0, by: percent, style: .linear)
    0.0.interpolate(a: 1.0, by: percent, style: .easeIn)
    0.0.interpolate(a: 1.0, by: percent, style: .easeOut)
    0.0.interpolate(a: 1.0, by: percent, style: .easeInOut)
}

extension CGPoint: Interpolating {
    public func interpolate(to value: CGPoint, by percent: Double, curve: InterpolationCurve) -> CGPoint {
        return CGPoint(
            x: self.x.interpolate(a: value.x, by: percent, style: curve),
            y: self.y.interpolate(a: value.y, by: percent, style: curve)
        )
    }
}

let p1 = CGPoint.zero
let p2 = CGPoint(x: 1, y: 1)

for percent in stride(from: 0.0, through: 1.0, by: 0.05) {
    let px = p1.interpolate(to: p2, by: percent, curve: .easeInOut)
}
