//: Playground - noun: a place where people can play
import PlaygroundSupport
import UIKit
import Foundation
import CoreGraphics

var str: String!
var dd: Double!
var ii: Int?
var bb: Bool?
var optionalName: String?
var vegetalStr: String! = "hey"

var cad = "Sólo me faltabas tú para ser feliz"

enum Errorcito: Error {
    case rangoInvalido(String)
    case sinRaiz(String)
}

/*
 print(cad.hasPrefix("Sólo")); let num = 999
 
 print(num.distance(to: 1500))
 print(num.advanced(by: 22))
 */
let adivina = Int.allZeros;// print(adivina)


/*
 for libs in polLat {
 print("\(libs)")
 }
 */

var S1: String = ""

let rango = 2..<9  // CountableRange, casi como en Pascal!!!

for j in 2..<5 {
    for i in rango {
        S1 += "\(i) por \(j) = \(j * i) \t"
    }
}
S1

/*
 func lanza_dado8(R: CountableRange<Int>) -> Int {
 var num: Int = 0
 while (num < R.lowerBound || num >= R.upperBound) {
 num = Int(drand48() * 1000)  // random!
 }
 return num // En futuras versiones se puede hacer una sola línea sin return, Int.random(R)
 }
 
 for _ in libros_A {
 S1 += "eres un maestro \(lanza_dado8(R: rango))\t"
 }
 print(S1)
 
 func toma_Datos() -> (Nombre: String, Middle: String) {
 return (Nombre: "Edgar", Middle: "Fernando")
 }
 
 let user = toma_Datos()
 print("Se llama: \(user.Nombre) y se le dice \(user.Middle)")
 
 let (usua, fer) = toma_Datos() // let (usua, _) si sólo quiero definir la primera variable
 print("Dije que se llama \(usua)? o \(fer)?")
 */


/*+++**+++** BLOQUE DO..TRY..CATCH +++**+++**/
/*
 do {
 let result = try checaContrasenia("ee8ewe5lb")
 print("Rating: \(result)")
 } catch errorContrasenia.obvio {
 print("La misma combinación que mi casillero")
 } catch { //errorContrasenia.corto, es decir, cualquier cosa!
 print("Errorazo!")
 }
 */
//*** **** ***** BLOQUES DE CÓDIGO ASIGNABLE (namespace???)
/*
 var bloque1 = {  // se comporta como un procedimiento o método
 print("Hola Colombia")
 }
 bloque1()
 
 var bloque2 = { (nombre: String) -> String in  // se comporta como una función
 "Hola mi amigo(a) \(nombre) todo esto es un String"
 }
 print(bloque2("Fer"))
 
 var bloque3 = { (nombre: String) -> (String, Double) in  // se comporta como una función
 ("Hola mi amigo(a) \(nombre), esto es un String y un Double: ", 20.20001)
 }
 print(bloque3("Nando"))
 
 var equipo = ["Millos", "SantaFe", "Bucaramanga", "Malianza"]
 
 var quedice = equipo.filter({ (nombre: String) -> Bool in
 /* return */ nombre.hasPrefix("M")  // como es sólo una línea, se puede quitar el return inicial
 })
 print(quedice)
 
 quedice = equipo.filter { nombre in nombre.hasPrefix("S") } // esto equivale a lo anterior
 print(quedice)  // se elimina el paréntesis y lo demás, analízalooooo
 
 quedice = equipo.filter { $0.hasPrefix("B") } // mucho más compacto pues $0 es parám 0
 print(quedice)
 */


struct EmpleadoZ {
    let nombre: String
    var vacacionesPermitidas: Int = 14
    var vacacionesTomadas: Int = 0 {
        didSet { // afterSet
            str = "Nuevo valor de vacacionesTomadas es: \(vacacionesTomadas)"
        }
    }
    var vacacionesRemanentes: Int {
        get { return vacacionesPermitidas - vacacionesTomadas }
        set { vacacionesPermitidas = vacacionesTomadas - newValue }
    }
}
// EmpleadoZ en este caso maneja internamente un constructor implícito, no se ve, pero funciona como los initializers en C++
var emp111: EmpleadoZ = EmpleadoZ(nombre: "Edgar", vacacionesPermitidas: 20, vacacionesTomadas: 1)
emp111.vacacionesRemanentes = 1
emp111.vacacionesTomadas = 4
"Vacaciones Permitidas: \(emp111.vacacionesPermitidas)"
"Vacaciones Remanentes: \(emp111.vacacionesRemanentes)"

struct Jefe {
    let nombre: String
    var vacacionesPermitidas: Int = 10 {
        didSet {
            str = "Nuevas vacaciones para jefe \(vacacionesPermitidas)"
        }
    }
    init(nombre: String, vacacionesPermitidas: Int = 10) {
        self.nombre = nombre
        if vacacionesPermitidas != 10 {
            self.vacacionesPermitidas = vacacionesPermitidas
        }
    }
}

var jefe1: Jefe = Jefe(nombre: "Fernando")
jefe1.vacacionesPermitidas = 11


/******** CLASES *********/

class VehiculoZ {
    var k_galon: Double
    init(gal: Double) {
        k_galon = gal
        str = "El Vehículo tiene nuevo galoncito $\(k_galon)"
    }
    deinit {
        str = "Lo secuestró las FARC con $\(k_galon) galones\n----\n"
    }
}

class CarroZ: VehiculoZ {
    let ocupantes: Int
    init(gal: Double, ocupa: Int) {
        ocupantes = ocupa
        super.init(gal: gal) // en Pascal a esta línea se le conoce como "Inherited;" dentro del constructor
        "Carro: Subió la gasolinaaa $\(k_galon)"
    }
    deinit {
        "Carro: nos paró un retén $\(k_galon)"
    }
}

var precio: Double = 8000
for i in 1...3 {
    precio *= 1.139
    let carro = CarroZ(gal: precio, ocupa: i) // al invocar el constructor Carro en carro, se llama el destructor
    "estamos andandoooo \(carro.ocupantes) ocupantes!"
}

/******* PROTOCOLOS ********/

protocol VehiculoW {
    var conductor: String { get }
    var pasajeros: UInt16 { get set }
    func viaje(_ distancia: Double)
    func tiempoEstimado(por distancia: Double) -> Int
}

struct CarroW: VehiculoW {
    var conductor: String = "Fernando"
    var pasajeros: UInt16 = 1

    func viaje(_ distancia: Double) {
        str = "Yo \(conductor), llevo \(pasajeros) pasajeros, \(distancia) kms"
    }
    
    func tiempoEstimado(por distancia: Double) -> Int {
        return (Int(distancia / 50))
    }
    
    func abreCorredizo() {
        str = "es un lindo día"
    }
}

func conmuta(distancia: Double, usando vehiculo: VehiculoW) {
    if vehiculo.tiempoEstimado(por: distancia) > 100 {
        str = "Lenttooooo"
    } else {
        vehiculo.viaje(distancia)
    }
}

/*
 let carro = Carro()
 conmuta(distancia: 100, usando: carro)
 carro.abreCorredizo()
 */

extension String {
    func cortaEspacios() -> String {
        return self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

var frase = "    Voy a la ciudad, voy a trabajar    "
var cortadita = frase.cortaEspacios()
/*
 print(frase)
 print(frase.cortaEspacios())
 */
extension String {
    mutating func cortao() {  // mutating se usa para modificar
        self = self.cortaEspacios()
    }
    /*
     var lineas: [String] {
     self.components(separatedBy: .newlines)
     }    */
}

frase.cortao()
//print(frase)

var frutas:[String: String] = [
    "Pera": "verde",
    "Manzana": "roja"
]

var inversa: String? = frutas["Anón"]  // Aquí String es opcional, pues puede que no exista lo que se busca en frutas, lo que daría "nil"

str = inversa ?? "No existe" // ?? indica que inversa como variable tendría el valor por defecto "no existe" en caso que fuese nil

var aBuscar: String = "Perra"

if let contrarioFruta = frutas[aBuscar] {  // if let asigna a contrarioFruta el valor de frutas[aBuscar], para que no devuelva un valor nil y menos la palabra opcional
    str = "El opuesto a \(aBuscar) es \(contrarioFruta)"
} else {
    str = "El valor \(aBuscar) no está"
}

func cuadrado(de numero: Int?) -> Int {
    guard let num = numero else {
        str = "faltó número"
        return -1 // pues jamás un cuadrado dará negativo
    }
    return (num * num)
}

let num = 10101010
str = "Cuadrado de \(num) es: \(cuadrado(de: num))"

let progsTV:[String: String] = ["Ted Lasso": "Netflix", "Bob Esponja": "Nickelodeon", "South Park": "Comedy", "Batman": "Action"]
let favorito = progsTV["Superman"] ?? "South Parque"

str = favorito

let entrada = "algo"
let aNumero = Int(entrada) ?? 0  // if entrada == (cualquier cosa) aNumero = 0


var arrPersonas: Array<String> = ["Pepe", "Juan", "María"]
var arrPeople: [String] = ["Pepe", "Juan", "María"]
arrPeople.append("Carlos")


// vie 26 mayo

if let nome = optionalName { // a esta altura optionalName es nil por definición
    str = "Hola \(nome)"
} else {
    str = "Algún error hubo con \(optionalName)"
}

let vegetal = "pimentón verde"
var tipo_vegetal: String = ""

switch vegetal {
case "apio":
    tipo_vegetal = "añade algunas pasas"
case "pepino", "berro":
    tipo_vegetal = "quedaría rico un sandwich con el té"
case let x where x.hasPrefix("pimentón"):
    tipo_vegetal = "es un \(x) picante?"
case let x where x.hasSuffix("amarillo"):
    tipo_vegetal = "es un plátano \(x)"
default:
    tipo_vegetal = "todo queda rico con vegetales"
}
str = "el vegetal es \(vegetal), para el caso, \(tipo_vegetal)"

// TUPLAS

func preciosGasolina() -> (ayer: Double, hoy: Double, tomorrow: Double) { // una tupla
    return (ayer: 8000, hoy: 12000, tomorrow: 16000)
}
str = "la gasolina a \(preciosGasolina().tomorrow) por culpa del marica de Petro"

func preciosACPM() -> (Int, Double, String) {
    return (ayer: 8000, hoy: 9000, tomorrow: "18000")
}
str = "y el acpm \(preciosACPM().2) no se queda atrás"

var pers0na = (prime: "Edgar", edad: 20)  // Tuples
str = pers0na.prime
str = "\(pers0na.edad)"

let N1 = "Edgar"
let N2 = "Fernando"
var N3 = "Dager"

var completo = [N1, N2, N3] // esto es un array
str = "\(completo)" // y esto es la cadena de ese array
N3 = "Rod?"  // N3 se modifica pero en completo no se actualiza
completo.append("Pacheco")

var telefonico = [Int: String]()  // Dictionary<Int, String>()
telefonico[6] = "Mundo"
telefonico[6] = "Mundo"  // simplemente lo ignora, funciona como Set
telefonico[1] = "hola"
telefonico

var Ages: [String: Int] = ["Fer": 50, "Ale": 30]

var Gasolina: [String: Double] = ["ayer":8000, "hoy":12_000, "mañana":16_000]

func retorna25() -> Int {
    var j: Int = 5
    func agrega5() -> Int { // función dentro de la función
        j += 5
        return j
    }
    
    agrega5()
    return j + agrega5()
}
retorna25()


// FUNCIONES, CLOSURES Y CALLBACKS

func incrementador() -> ((Int) -> Int) { // devuelve una función con parámetro Int
    func agregaDiez(num: Int) -> Int { // agregaDiez es una función que se conecta
        return num + 10                // a sí misma con el tipo de dato de la
    }                                  // función que la contiene: (Int) -> Int
    return agregaDiez
}
// definir      vvvvvvvvvvvvvv el tipo de dato se puede omitir
var incremente: ((Int) -> Int) = incrementador()  // incremente es de tipo función
incremente(5)


// condición usa una llamada "callback" con parámetro Int y devuelve Bool
func cumpleAlMenosUno(array: [Int], condicion: (Int) -> Bool) -> Bool {
    for item in array {
        if condicion(item) {
            return true
        }
    }
    return false
}

func menorA20(numero: Int) -> Bool {
    return numero < 20
}

let numeros = [20, 30, 2, 4, 10, 100, 7, 15, 211]
cumpleAlMenosUno(array: numeros, condicion: menorA20)

let result = numeros.map { String($0) }
result

numeros.map { (numero: Int) -> Int in
    //let result = 3 * numero
    return 3 * numero //result
}

numeros.map { (num: Int) -> Int in
    if num % 2 == 1 { // Si es impar, devuelva 0
        return 0
    }
    return num
}

class NamedShape {
    var numLados: Int = 0
    var nombre: String
    
    init(nombre: String) {
        self.nombre = nombre
    }
    
    func describe() -> String {
        return "\(nombre) tiene \(numLados) lados"
    }
}

class Cuadrado: NamedShape {
    var length: Double
    
    init(length: Double, nombre: String) {
        self.length = length // para evitar confusiones con el parámetro usar self
        super.init(nombre: nombre)
        super.numLados = 4 // lo mismo que decir solamente numLados = 4
    }
    
    func area() -> Double {
        return length * length
    }
}

let cuadra1 = Cuadrado(length: 10, nombre: "Carlos")
cuadra1.area()
cuadra1.describe()

class Circulo: NamedShape {
    var radio: Double
    
    init(length: Double, nombre: String) {
        radio = length
        super.init(nombre: nombre)
        // recordar que para este caso el número de lados es cero
    }
    
    func area() -> Double {
        let resultado = String(format: "%.2f", 3.1415 * radio * radio)
        return Double(resultado)!
    }
    
    override func describe() -> String {
        return "\(nombre) como círculo, tiene \(area()) m 2"
    }
}

let culito1 = Circulo(length: 123, nombre: "Bob")
culito1.area()
culito1.describe()

class Triangulo: NamedShape {
    var length: Double = 0.0
    init(length: Double, nombre: String) {
        super.init(nombre: nombre)  // Pascal's Inherited
        numLados = 3
        self.length = length
    }
    var perimetro: Double { // la forma de get/set de una propiedad ;)
        get {
            return (self.length * Double(super.numLados))
        }
        set {
            self.length = newValue / Double(super.numLados)
        }
    }
    override func describe() -> String {
        return "Triángulo \(nombre) perímetro: \(perimetro)"
    }
}

let tria1: Triangulo? = Triangulo(length: 203, nombre: "isóceles")
tria1?.perimetro = 302
tria1?.describe()


// ENUMS

enum Rank: Int { // Cuando el enum espera un tipo de dato.
    case AS = 1  // Los enum por lo general comienzan desde cero.
    case Dos, Tres, Cuatro, Cinco, Seis, Siete, Ocho, Nueve, Diez
    case Jota, Reina, Rey
    func describe() -> String {
        switch self {
        case .AS:
            return "AS"
        case .Jota:
            return "Jota"
        case .Reina:
            return "Reina"
        case .Rey:
            return "Rey"
        default:
            return "\(self.rawValue)"
        }
    }
    var cartaB: String { // como propiedad en un enum, es excelente...
        get {
            return "\(self.rawValue)"
        }
        set { // intentamos convertir de string al valor nuevo, en este caso, Int
            guard let newValue = Int(newValue) else {
                self = .AS
                return
            }
            self = Rank(rawValue: newValue)! // reasignamos el valor
//            if let newValue = Int(newValue) { // Esto también funciona!
//                self = Rank(rawValue: newValue) ?? .AS
//            } else {
//                self = .AS
//            }
            print("EDGAR, CORROBORA!: \(newValue)")
        }
    }
}
var AS = Rank.Rey
AS.cartaB
AS.cartaB = "10"

let valorAS = AS.describe()
let H_valorAS = AS.hashValue // hashValue muestra el número desde 0, no desde 1
let R_valorAS = AS.rawValue

let constructorRank: Rank! = Rank.init(rawValue: 6)
var convertedRank: Rank! = Rank(rawValue: 2)!
convertedRank = Rank.init(rawValue: 3)! // El constructor puede ser Optional,
convertedRank = Rank.init(rawValue: 4)  // o siéndolo, podemos no especificarlo
convertedRank?.describe()
let fifthDescription = Rank.init(rawValue: 5)?.describe()

// en vez de compareRanks hay una mejor implementación, más abajo la escribo
func compareRanks(A: Rank, B: Rank) -> Int {
    if A.rawValue < B.rawValue {
        return -1
    }
    if A.rawValue > B.rawValue {
        return 1
    }
    return 0
}
compareRanks(A: Rank.Jota, B: Rank.Reina)

extension Rank: Comparable { // extender el enum es mejor implementación
    public static func < (lhs: Rank, rhs: Rank) -> Bool {
        switch (lhs, rhs) {
        case (_, _) where lhs == rhs: 
            return false // ninguno de los elementos puede igualarse
//        case (.Rey, _): // para este ejemplo, el Rey es el máximo
//            return false
        default: return lhs.rawValue < rhs.rawValue
        }
    }
}
let ra1 = Rank.AS
let ra2 = Rank.Jota

if ra1 < ra2 { // basado en la extensión anterior podemos hacer esta comparación.
  str = "\(ra1) menor que \(ra2)"
}
if ra1 > ra2 {
  str = "\(ra1) mAYor que \(ra2)"
}
if ra1 == ra2 {
  str = "\(ra1) IGUAL A \(ra2)"
}

// excelente ejemplo sobre enums y formas de construirlos
let raK = Rank(rawValue: 13)! // Si no definimos el optional aquí, !, habrá que definirlo cada vez que llamemos a raK
let raQ = Rank.init(rawValue: 12)

if raK < raQ! { // por ejemplo, no se especifica raK! como Optional, se hace antes
    str = "\(raK) menor que \(raQ!)"
}
if raK > raQ! {
    str = "\(raK) mayor que \(raQ!)"
}
if raK == raQ { // interesante, averigua el porqué de esto.
    str = "\(raK) es igualito que \(raQ!)"
}

enum CColors: String {
    case rojo = "Rojo"
    case negro = "Negro"
}

enum TipoCarta {
    case Picas, Corazones, Diamantes, Treboles

    func describe() -> String {  // mejor usar var que func
        switch self {
        case .Picas: return "Picas"
        case .Corazones: return "Corazones"
        case .Diamantes: return "Diamantes"
        default: return "Trébol"
        }
    }
    
    func color() -> CColors {
        switch self {
        case .Picas, .Treboles:
            return CColors.negro
        default:
            return CColors.rojo
        }
        
    }

    var colour: String { // Podría manejarse con CColors
        get {
            switch self {
            case .Corazones, .Diamantes:
                return "\(CColors.rojo)"
            default:
                return "\(CColors.negro)"
            }
        }
        set {
            switch newValue.uppercased() {
            case "PICAS":
                self = .Picas
            case "CORAZONES":
                self = .Corazones
            case "DIAMANTES":
                self = .Diamantes
            default:
                self = .Treboles
            }
        }
    }
}

var TC: TipoCarta = .Diamantes
str = TC.color().rawValue
TC.colour = "trEbolEs"
str = TC.colour
TC = .Corazones
TC.colour
str = TC.describe()
TC


struct Carta {
    var rango: Rank
    var tipo: TipoCarta

    var describe: String { // Campo Computado
        get {
            return "\(rango.describe()) de \(tipo.describe()) es \(tipo.color())"
        }
    }
    
    func fullDeck() -> String {
        var result: String = ""
        for R in 1...13 {
            let R1: Rank! = Rank.init(rawValue: R)!
            for T in [TipoCarta.Picas, .Corazones, .Diamantes, .Treboles] {
                result.append("\(R1!.describe()) de \(T.describe()) \(T.color())\t\t")
            }
            result.append("\n")
        }
        return result
    }
}
let tresPicas = Carta(rango: .AS, tipo: .Corazones)
str = tresPicas.describe
str = tresPicas.fullDeck()

var AAA = [Character]() // Array of Chars
for chars in "As de Corazones".characters { //
    AAA.append(chars)
}
AAA

enum RespuestaServidorZ {
    case Resultado(A: String, B: String) // puede estar sin A ni B
    case Error(String)
    case fecha(Date)
}

var bien = RespuestaServidorZ.Resultado(A: "8:00 am", B: "4:00 pm")

bien = .Error("No hay pepinillos")  // .Error, pues ya hay referencia anterior de RespuestaServidorZ

let formFecha = DateFormatter()
// formFecha.locale = Locale(identifier: "es_ES")
formFecha.dateFormat = "dd/MM/yyyy"
if let fecha = formFecha.date(from: "26/10/1971") {
    bien = .fecha(fecha)
}

// Entienda el siguiente switch-case-let así: intente asignar a la variable "bien" tácitamente .fecha(cuando), y si lo hace, asigne a str "Mi nacimiento..."
switch bien { // esta variable toma el tipo enum RespuestaServidorZ
case let .Resultado(morning, afternoon): // se crean 2 variables
    str = "Desayunos a las \(morning), cena a las \(afternoon)"
case let .Error(falla): // basado en lo que vale "bien" se asigna el valor dentro de "bien" a la variable falla
    str = "Desastre por la falta: \(falla)"
case .fecha(let cuando): // también se puede hacer esto
    str = "He nacido el \(formFecha.string(from: cuando))"
}

let numero42 = 42

// El siguiente switch-case-let se puede leer así: intente asignar tácitamente para cada caso a m la variable numero42, y si cumple el caso "where", ejecute. Resulta que m se puede usar pues es generado mediante let.
switch numero42 {
case let m where m < 0:
    str = "El número \(numero42) es negativo"
case let m where m > 0:
    str = "El número \(m) es muy positivo"
default:
    str = "El número \(numero42) es cero"
}


enum ActividadM {
    case aburrido
    case hablando(sobre: String)
    case jugando(num_apuesta: Int)
    case durmiendo(sonnando: Bool)
}

var que_haceS = ActividadM.hablando(sobre: "Futbol")
que_haceS = .durmiendo(sonnando: true)
que_haceS = .jugando(num_apuesta: 2034)


enum Tamanios: Int, Comparable {
    case S, M, L, XL, XXL
    static func < (ihs: Tamanios, dhs: Tamanios) -> Bool {
        return ihs.hashValue < dhs.hashValue
    }
    static func == (ihs: Tamanios, dhs: Tamanios) -> Bool {
        return ihs.hashValue == dhs.hashValue
    }
}

let peque = Tamanios.S
let grand = Tamanios.L

if Tamanios.L != .L {
    print("mayor")
}
if peque < grand {
    str = "\(peque) es más pequeño que \(grand)"
}


// Dado un arreglo de enteros, revise si hay 2 elementos que sumados sean iguales a suma B

func sumaParIguales(_ A: [Int], B: Int) -> Bool {
    var hashA = [Int: Bool]()

    for a in A {
        hashA[a] = true
    }

    for a in A {
        if hashA[B-a] == true {
            return true
        }
    }

    return false
}

sumaParIguales([1, 2, 3, 9, 5], B: 8)


// Suma de Prefijos
// Usar suma de prefijos es una forma de construir un arreglo consistente de todas las sumas en i, junto con todas las sumas que le preceden.

/*
    a0      a1      a2                  an
    a0  a0 + a1  a0 + a1 + a2     a0+a1+...+an-1
*/
func sumaPrefijo(_ A: [Int]) -> [Int] {
    var prefijo = Array<Int>(repeating: 0, count: A.count) // FillChar!
    prefijo[0] = A[0]  // Pointer like
    for i in 1..<A.count {
        prefijo[i] = prefijo[i - 1] + A[i]
    }
    return prefijo
}
sumaPrefijo([1, 2, 3, 4, 5])

// Luego una vez tenemos esto, puedes hacer cálculos como el total de una sección velozmente.

func totalCuenta(_ P: [Int], _ x: Int, _ y: Int) -> Int {
    return P[x] - P[y]
}
let prefijo = sumaPrefijo([1, 2, 3, 4])
let midTotal = totalCuenta(prefijo, 3, 1) // 7 = 10 - 3


// LÍDER
// El líder es el elemento de un arreglo que se repite n/2 veces.

/*
 Si la secuencia está ordenada, los valores idénticos son adyacentes entre sí.
 El líder debe ser de tipo n/2 - el elemento central.

 4 6 6 6 6 8 8
 *
*/

func liderVeloz(_ A: [Int]) -> Int {
    var lider = -1

    let n = A.count
    let B = A.sorted()

    let candidato = B[n/2]

    var contador = 0
    for i in 0..<B.count {
        if B[i] == candidato {
            contador += 1
        }
    }

    if contador > n / 2 {
        lider = candidato
    }
    return lider
}
liderVeloz([4, 6, 6, 8, 8, 8, 8])

// MÁXIMA PORCIÓN
/*
 Problema de Suma de Máxima Porción
 https://app.codility.com/programmers/lessons/9-maximum_slice_problem/

 Busque el corte con la suma más larga.

 5 -7 3 5 -2 4 -1
 --------

 Este es el máximo corte que podemos tener.  Note cómo contiene un número negativo?
 Esto es porque el elemento del arreglo posterior es tan grande que merece incluirse.

 Tampoco incluimos necesariamente todos los elementos (como el primer 5) porque cuando lo agregamos a la siguiente porción -7 hace la porción negativa, así que obviamos ambos hasta llegar al siguiente número positivo 3, y así continuamos sumando desde ahí.

 Aquí tenemos un algoritmo de veloz desempeño para resolver.
*/
func maxCorte(_ A: [Int]) -> Int {
    var maxFinal = A[0]
    var maxCorte = A[0]
    for i in 1 ..< A.count {
        maxFinal = max(A[i], maxFinal + A[i])
        maxCorte = max(maxCorte, maxFinal)
    }
    return maxCorte
}
maxCorte([5, -7, 3, 5, -2, 4, -1])

// PRIMOS Y NÚMEROS COMPUESTOS
// Este algoritmo es muy rápido encontrando los divisores de un número dado
func velozDivisores(_ n: Int) -> [Int] {
    var i = 1
    var resultado = Set<Int>()
    while i * i < n {
        if n % i == 0 {
            resultado.insert(i)
            resultado.insert(n/i)
        }
        i += 1
    }
    // Los cuadrados perfectos tienen un extra
    if i * i == n {
        resultado.insert(i * i)
    }
    return Array<Int>(resultado).sorted()
}
velozDivisores(10)

// Algoritmo de Euclides - MCD

// Por Sustracción: O(n)
func gcdResta(_ a: Int, _ b: Int) -> Int {
    if a == b { return b }
    if a > b {
        return gcdResta(a - b, b)
    } else {
        return gcdResta(a, b - a)
    }
}

// Por División: O(log(a+b))
func gcdDiv(_ a: Int, _ b: Int) -> Int {
    if a % b == 0 {
        return b
    } else {
        return gcdDiv(b, a % b)
    }
}

gcdResta(18, 24)
gcdDiv(24, 18)

// ORUGA
// Algorithm for crawling along and evaluating criteria each step of the way, before adjusting the front and back pointers of the caterpillar crawling the array.
// Algoritmo para rastrear y evaluar criterios en cada paso del camino, antes de ajustar los punteros de frente y atrás de la oruga que se arrastra por el arreglo.
func sumaOruga(_ A: [Int], _ s: Int) -> Bool {
    let n = A.count
    var frente = 0; var atras = 0; var total = 0

    for _ in 0 ..< n {
        while frente < n && total + A[frente] <= s {
            total += A[frente]
            frente += 1
        }
        if total == s { return true }
        total -= A[atras]
        atras += 1
    }
    return false
}
sumaOruga([6, 2, 7, 4, 1, 3, 6], 12)
sumaOruga([6, 2, 7, 3, 1, 3, 6], 12)
sumaOruga([1, 2, 1, 3, 1, 3, 6], 12)



var gaseosas: [String] = ["Castalia", "Postobon", "Hipinto", "Coca-Cola", "Pepsi", "Ron-Cola", "Ginger-Ale", "Glacial"]
gaseosas.append("Postobon")
gaseosas.append("Hipinto")
gaseosas.append("Kola Román")
gaseosas.count
// print(gaseosas[4..<gaseosas.count])

var vendidas: Set<String> = Set(gaseosas) // la mejor forma de simplificar un array
vendidas.count


// en vez de esto:
// let mayusculas = ClosedRange(uncheckedBounds: (lower: "A", upper: "Z"))
let mayusculas = "A"..."Z"  // Natural ClosedRange
mayusculas.contains("a")
mayusculas.contains("F")
mayusculas.isEmpty
mayusculas.upperBound
mayusculas.debugDescription

let rangoG = ClosedRange(uncheckedBounds: (lower: 0, upper: 10))

let R1 = rangoG.lowerBound
let R2 = rangoG.upperBound
let R3 = rangoG.count // ClosedRange es que permite contarlos mientras sean Int

let valMin = 0

var nombresFinales = [String]()
let rangoCCR = CountableClosedRange(rango) // let rango = 2..<9
rangoCCR.count

for R4 in rangoCCR {
    guard nombresFinales.count != 5 else { break }
    nombresFinales.insert(gaseosas[R4], at: 0)  // para invertirlos
}
nombresFinales

let titulo = "un software Swift elegante"
let rango_tit = titulo.range(of: "Swift")
let attribString = NSMutableAttributedString(string: titulo)
let rangoConvertido = NSRange(location: 0, length: 7)
rangoConvertido.toRange()

let text_Nuevo: NSString = "🚀 lanzador"
// print(text_Nuevo.substring(with: NSRange(location: 0, length: 8)))

let fin_idx = text_Nuevo.index(ofAccessibilityElement: titulo)

func dictUsuario() -> [String: String] {
    return [ "Edgar": "Fernando",
             "Dager": "Roldán"]
}

func tupleUsuario() -> (nombre: String, apell: String) {
    return ("Fernando", "Dager")
}

let usuari1: [String: String] = dictUsuario()
str = "Nombre \(usuari1["Edgar"]!), Ape \(usuari1["Dager"]!)"

let usuari2: (nombre: String, apell: String) = tupleUsuario()
let (apodo: nom1) = tupleUsuario().nombre
let ape1 = tupleUsuario().apell
let (nom2, ape2) = tupleUsuario()

str = "Nombre \(usuari2.nombre), Ape \(ape2)"

func buyCar(price: Int) {
    switch price {
    case 0...20_000:
        print("This seems cheap.")
    case 20_001...50_000:
        print("This seems like a reasonable car.")
    case 50_001...100_000:
        print("This had better be a good car.")
    case _:  // se convierte el switch en Exhaustive (cool)
        break
    }
}

func raiz(num: Int) throws -> Int? {
    let R: Range<Int> = 1..<1_000_001
    guard R.contains(num) else { throw Errorcito.rangoInvalido("El número debe estar entre 1 y 10.000") }
    var r = 1
    let CR = CountableRange(R)
    /*
     let tol = 1  // Helon
     while abs(r * r - num) > tol {
     r = (r + num / r) / 2
     if r <= 1 {
     return nil
     }
     } */
    for N in CR {
        if N * N == num {
            r = N; break
        }
    }
    if r == 1 && num > r { return nil }
    return r
}



do {
    guard let R: Int = try raiz(num: 1_000_000)
        else {
            throw Errorcito.sinRaiz("No hay ná")
    }
    ii = R
} catch let error{
    print(error.localizedDescription)
}

/******* C L O S U R E S *********/


let dimeHola = { (a: String) -> String in // in es como una asignación
    return "hola \(a)"
}

dimeHola(", cómo estás?")


func voyAVos(letra: String) -> Int {
    let S = "vilma palma \(letra)"
    return S.characters.count
}

let siVos: (String) -> Int = voyAVos // () es func y -> Void  devuelve "nada", es decir, es un método o procedimiento
siVos("te vas")

//let teVas: (_ num: Int) throws



func favoritaUltimo(gas1: String, gas2: String) -> Bool {
    if gas1 == "Ginger-Ale" {
        return true
    } else if gas2 == "Ginger-Ale" {
        return false
    }
    return gas1 < gas2
}

let gasFavor = gaseosas.sorted(by: favoritaUltimo)
let gasFavoR = gaseosas.sorted{ $0 > $1 }
str = gasFavoR.joined(separator: "-")

func animaciones(durac: Int, anime: () -> Void) {
    print("Inicia una en \(durac)")
    anime()
}

// animaciones(durac: 3, anime: { print("hey") })
/* animaciones(durac: 4) { // anime: es el cuerpo del closure
 print("you")
 } */

func reducelo(_ valores: [Int], closure: (Int, Int) -> Int) -> Int {
    var actual: Int = valores[0] // comienza con un total igual al primer elemento
    // es como si actual fuese un puntero y al apuntar al primer elemento, tomase su tipo Int.  El Closure también devuelve un Int con dos parámetros, internamente los arrays toman 2 parámetros del mismo tipo que coinciden con los descritos en el closure, y debe devolver un entero.
    
    let rango: CountableRange = 1..<valores.count
    for valor in valores[rango] {
        actual = closure(actual, valor)
    }
    return actual
}

let nums = [10, 20, 30, 40, 50, 60, 70, 80]

let Suma = reducelo(nums, closure: {(totEx: Int, N: Int) in return totEx + N})

let suma = reducelo(nums, closure: {(totEx, N) in return totEx + N})

let sumA = reducelo(nums, closure: {(T, N) in T + N})

let SumA = reducelo(nums, closure: { $0 + $1 })

let SUMA = reducelo(nums, closure: +) // WOW!

SUMA

let subNums:ArraySlice = nums[1...6]

func _suma(_ array: [Int]) -> Int {
    return array.reduce(0, +)
    //return array.reduce(<#T##initialResult: Result##Result#>, <#T##nextPartialResult: (Result, Int) throws -> Result##(Result, Int) throws -> Result#>)
}

// II = _suma(subNums) CRASH!!! porque ArraySlice ≠ Array

// Usando Swift 3 podría abusarse de la memoria tomando los elementos de subNums y convertirlos en Array (pero abajo es mejor usando Generics como en __suma)
let nuevoNums = Array(subNums)

ii = _suma(nuevoNums)

func __suma<T: Collection>(_ array: T) -> Int {
    var result: Int = 0
    for ele in array {
        result += ele as! Int
    }
    return result
}

ii = __suma(subNums)
ii = __suma(nums)


var cualquiera: [Any] = [26, 10.0, "1971", true, 10 as AnyObject]


/****** M A P S ******/  // Circula por un Collection y aplica la misma operación a cada elemento de la colección

let nums1 = nums.map({(valor: Int) -> Int in
    return valor * 2 })

let nums2 = nums.map({(valor: Int) in
    return valor * 2 })

let nums3 = nums.map({(valor: Int) in
    valor * 2 })

let nums4 = nums.map{
    $0 * 2 }

/****** F I L T E R S *******/  // Circula por un Collection y retorna un arreglo que contiene elementos que cumplen una condición

// Reto: Escribe los demás que deberían ir aquí.

let nums11 = nums.filter{
    $0 % 20 == 0 }

/******* R E D U C E ********/ // Combina todos los elementos en un Collection para crear un solo valor.  Los dos parámetros en una función reduce son el valor inicial y una función respectivamente

let nums22 = nums.reduce(0, {
    $0 + $1 })

let nums23 = nums.reduce(0, {(valI, valD: Int) in
    var result = 0
    result = valI + valD
    return result
})

let nums24 = nums.reduce(0, +)

let String1 = [" Mundo! ", " Cómo está?"].reduce("Hola,", {
    $0 + $1}) // reduce también aplica a Strings


/********* F L A T M A P **********/ // Cuando se implementa en secuencias (Sequences), "aplana" una colección de colecciones (Collections)

var arregloArreglos = [[["11", "12"],["22", "21"], ["29", "28"]],[["33", "32", "31"],["44", "43", "42"]],[["55", "54", "53"],["66", "65"]]]
arregloArreglos[1][1].append("88")

var arregloArepa: [[String?]] = arregloArreglos.flatMap({
    $0})

arregloArepa[1].insert(nil, at: 2)

var arregloOpt: [String?] = arregloArreglos.flatMap({
    $0.flatMap({$0})}) // Totalmente plano pero con nil, por tanto de tipo Optional
arregloOpt.insert(nil, at: 2) // se agregó un nil

var arregloLimpio = arregloOpt.flatMap({
    $0}) // flatMap quita los nil
/*
 var arregloAInt = arregloArreglos.map({ // convierte a Int cada elemento del array
 $0.map({
 $0.map({
 Int($0)! // Saca el valor con !
 })
 })
 })
 */
// convierte a Int cada elemento del array
var arregloAInt = arregloArreglos.map{ arrAnidado1 in
    arrAnidado1.map{ arrAnidado2 in
        arrAnidado2.map{ (I: String) -> Int in
            Int(I)!  // se puede obviar el return
        }
    }
}


/******** CHAINING *********/ // Combinemos lo anterior

// Agreguemos los cuadrados de todos los pares de un arreglo de arreglos
let cniaa = arregloAInt.flatMap{ // elevamos un grado de array: [[[ -> [[
    $0.flatMap{ // elevamos el otro grado para que quede así: [[ -> [
        $0}.filter{ // filtramos los números pares
            $0 % 2 == 0}.map{ // aplicamos mediante map la multiplicación
                $0 * $0} // reducimos a la sumatoria
}
let cniaA = "$\(cniaa.reduce(0, +))" // la sumatoria mediante reduce pudo haberse manejado en la línea anterior, pero mi compilador se quejó, por otro lado, lo convierto a texto para agregarle el símbolo de moneda



func generarNumAleatorio() -> () -> Int {
    var numAnterior: Int = 0
    return {
        var nuevoNum: Int
        
        repeat {
            nuevoNum = Int(arc4random() % 10)
        } while nuevoNum == numAnterior
        
        numAnterior = nuevoNum
        return nuevoNum
    }
}

let generador = generarNumAleatorio()

str = ""

for _ in 1..<24 {
    str = str + String(generador()) + ", "
}

str = str + String(generador())

//print(Str)

class Pokemon: CustomDebugStringConvertible {
    let nombre: String
    init(nombre: String) {
        self.nombre = nombre
    }
    var debugDescription: String { return "<Pokemon: \(nombre)>" } // wow
    deinit{print("\(self) escapó")}
}

func delay(_ segundos: Int, closure: @escaping () -> ()) {
    let hora = DispatchTime.now() + .seconds(segundos)
    DispatchQueue.main.asyncAfter(deadline: hora) {
        print("⏲")
        closure()
    }
}
// demo1 no funcionó
func demo1() {
    let poke = Pokemon(nombre: "pikachú")
    print("antes del closure: \(poke)")
    delay(1) {
        //print("Dentro del closure: \(poke)")
    }
    //print("chao!")
}

// demo1()


let pago = { (pagador: String) in
    print("pagó: \(pagador)...")
}

pago("Fer")


func tendGarden(activities: () -> Void) {
    print("I love gardening")
    activities()
}
tendGarden {
    print("Let's grow some roses!")
}


func brewTea(steps: () -> Void) {
    print("Get tea")
    print("Get milk")
    print("Get sugar")
    steps()
}

brewTea {
    print("Brew tea in teapot.")
    print("Add milk to cup")
    print("Pour tea into cup")
    print("Add sugar to taste.")
}


func repeatAction(count: Int, action: () -> Void) {
    for _ in 0..<count {
        action()
    }
}
repeatAction(count: 2) {
    print("Hello, world!")
}

func clean(tasks: () -> Void) {
    print("It's time to clean the house.")
    tasks()
}
clean {
    print("I'm going to clean the kitchen.")
    print("I'm going to tidy the study.")
    print("I'm going to nuke the kids' room.")
}

// Checkpoint 5

let luckyNumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]

let evenLuckyNums = luckyNumbers.filter{
    $0 % 2 == 1 }

let orderedELN = evenLuckyNums.sorted()

let strOELN = orderedELN.map{
    String($0) + " is a lucky number!" }

let printSOELN = orderedELN.map{
    print("\($0) is a lucky number!") }

let todoEnUno = luckyNumbers.filter{$0 % 2 == 1}.sorted().map{print("\($0) es un número suertudo!")}






struct Album {
    let cancion: String
    let autor: String
    let anio: Int16
    var genero: String {
        didSet {
            print("(didSet) el género cambió a \(genero) de \(oldValue)")
        }
        willSet {
            print("(willSet) el género parece que cambiará de \(genero) a \(newValue)")
        }
    }
    var general: String { // Propiedad con get y set
        get {
            let S = "GET: \(cancion): es de tipo \(genero)"; print(S)
            return S
        }
        set {
            print("SET: muestra que es \(genero)")
            genero = newValue
            print("SET: muestra que es \(genero)")
        }
    }
    func anios() -> Int16 {
        return 2023 - anio
    }
    var describe: String {  // calculado, funciona como un getter
        return "\(cancion), compuesta por \(autor) en \(anio)"
    } // si no tiene get, set, didSet, willSet se toma como PROPIEDAD CALCULADA
}


struct Empleado {
    let nombre: String
    var diasVacaciones: Int32
    
    mutating func tomaVacaciones(dias: Int32) {
        if diasVacaciones >= dias {
            diasVacaciones -= dias
            print("me voy de vacas\nme faltan \(diasVacaciones)")
        } else {
            print("No me dejaron ir")
        }
    }
}

var emp1 = Empleado(nombre: "Fer", diasVacaciones: 14)
emp1.diasVacaciones -= 3
emp1.tomaVacaciones(dias: 5)
emp1.diasVacaciones -= 3
emp1.diasVacaciones


// En Struct todos los elementos son por defecto públicos, por lo que se requerirá poner privados a discreción.
// (private): no permite a nadie fuera del struct lo use
// (fileprivate): no deja que nadie fuera de este archivo lo use
// (public): permite que cualquiera desde cualquier parte lo use
// (private(set)): permite que cualquiera desde cualquier parte lo pueda ver, pero sólo los métodos internos pueden escribir en él

struct CuentaBancaria {
    private(set) var fondos: IntMax = 0
    
    static var año: Int = { // interesante, parece un closure
        return 2023
    }()
    
    mutating func deposito(cant: Int) {
        fondos += cant
    }
    
    static let apertura = CuentaBancaria(fondos: 100) // Interesante forma de Inicializador, parece un Constructor cualquiera, pero en últimas es una propiedad que ejecuta el método init interno.
    
    mutating func retiro(cant: IntMax) -> Bool {
        if fondos < cant {
            return false
        } else {
            fondos -= cant
            return true
        }
    }
}

var cuentaFer = CuentaBancaria.apertura // se abre en 100
cuentaFer.deposito(cant: 300)

let retiroFer = cuentaFer.retiro(cant: 300)
cuentaFer.fondos
var cuentaCeros = CuentaBancaria() // se abre en ceros
cuentaCeros.fondos

var CC = CuentaBancaria.año // accedo a static cuando se asigna a una nueva variable

//  if retiroFer { print("Sí") } else { print("No") }

cuentaFer.fondos

struct Colegio {
    static var alumnosCount = 0
    
    static func ingreso(alumno: String) {
        if alumno.isEmpty { return }
        print("\(alumno) ha ingresado")
        alumnosCount += 1
    }
}

Colegio.ingreso(alumno: "ISA")
Colegio.alumnosCount


let str1 = "G"
let str2 = "B"
let GB = str1 + str2

extension String {
    subscript(i: Int) -> Character {
        return self[index(startIndex, offsetBy: i)]
    }
}

print(GB[0])  // sin la anterior extensión, esto no se puede usar: GB[1]



struct Bicycle {
    var currentGear: Int
    mutating func changeGear(to newGear: Int) {
        currentGear = newGear
        print("I'm now in gear \(currentGear).")
    }
}

var B = Bicycle(currentGear: 4)
B.changeGear(to: 3)


struct Players {
    var name: Array<String> = [String]() {
        willSet {
            print("Array contiene: \(name)\nNuevo valor: \(newValue))")
        }
        didSet {
            print("contenía \(oldValue)\n-van: (\(name.count))---------------------------------")
        }
    }
}

var jugadores = Players()
jugadores.name.append("Pibe")
jugadores.name.append("Leonel")
jugadores.name.append("Rondón")
jugadores.name.append("Asprilla")
jugadores.name.endIndex
jugadores.name.removeFirst()
jugadores.name


struct Employee {
    var name: String = ""
    var yearsActive = 0
    
    init() {
        self.name = "Anonymous"
        print("Creating an anonymous employee…")
    }
}

let fernando = Employee()

struct Student {
    var name: String
    var bestFriend: String
    
    init(name studentName: String, bestFriend studentBestFriend: String) {
        print("Enrolling \(studentName) in class…")
        name = studentName
        bestFriend = studentBestFriend
    }
}

let estud1 = Student(name: "Fer", bestFriend: "Ale")


struct Dictionary {
    var words = Set<String>()
}
var dictionary = Dictionary()

dictionary.words.insert("nuevo")
dictionary.words.insert("simulador")
dictionary.words.insert("de diccionario")
dictionary.words

struct Diccionario {
    static var palabras = Set<String>() // static permite tener acceso sin instanciar ningún Diccionario, es decir al propio Diccionario como se ve abajo
    static func escribir(_ palabra: String) {
        palabras.insert(palabra)
    }
}

Diccionario.palabras.insert("nuevo")
Diccionario.escribir("simulador")
Diccionario.palabras


var diccionario = Diccionario.palabras // Accedo al miembro static de Diccionario
diccionario.insert("nuevo")
diccionario.insert("simulador")
diccionario



struct Customer {
    var name: String
    private var creditCardNumber: Int
    init(name: String, creditCard: Int) {
        self.name = name
        self.creditCardNumber = creditCard
    }
}
let lottie = Customer(name: "Lottie Knights", creditCard: 1234567890)


struct App {
    var name: String
    private var sales = 0
    init(name: String) {
        self.name = name
    }
}
let spotify = App(name: "Spotify")


struct NewsStory {
    static var breakingNewsCount = 0
    static var regularNewsCount = 0
    var headline: String
    init(headline: String, isBreaking: Bool) {
        self.headline = headline
        if isBreaking {
            NewsStory.breakingNewsCount += 1
        } else {
            NewsStory.regularNewsCount += 1
        }
    }
}

struct Cat {
    static var allCats = [Cat]()
    init() {
        Cat.allCats.append(self)
    }
    static func chorus() {
        for _ in allCats {
            print("Meow!")
        }
    }
}
Cat.init()
Cat.chorus()

struct Person {
    static var population = 0
    var name: String
    init(personName: String) {
        name = personName
        Person.population += 1
    }
}

enum UpDown: Int8 {
    case Down = -1, Newtral, Up
}

struct Carro {
    let modelo: String
    let asientos: Int8  // alguien puede quitar los asientos...
    var cambioActual: Int8 = UpDown.Newtral.rawValue {
        willSet {
            print("Caja estaba en \(cambioActual) se pondrá en \(newValue)")
        }
        didSet {
            print("Caja puesta en \(cambioActual)")
        }
    }
    private let minCambio: Int8 = 0
    private let maxCambio: Int8 = 7
    init(modelo: String, asientos: Int8) {
        self.modelo = modelo
        self.asientos = asientos
        cambioActual = UpDown.Newtral.rawValue
    }
    mutating func cambiaCambio(método: UpDown) -> Bool {
        if método.rawValue != UpDown.Newtral.rawValue {
            if (cambioActual + método.rawValue) > minCambio && (cambioActual + método.rawValue) <= maxCambio {
                cambioActual = cambioActual + método.rawValue
                return true
            }
        }
        print("se intentó poner en \(cambioActual + método.rawValue)")
        cambioActual = UpDown.Newtral.rawValue
        return false
    }
}

var ferrari = Carro(modelo: "Rojo 2023", asientos: 2)

ferrari.cambiaCambio(método: UpDown.Down)
ferrari.cambiaCambio(método: UpDown.Up)
ferrari.cambiaCambio(método: UpDown.Up)
ferrari.cambiaCambio(método: UpDown.Up)
ferrari.cambiaCambio(método: UpDown.Up)
ferrari.cambiaCambio(método: UpDown.Up)
ferrari.cambiaCambio(método: UpDown.Up)
ferrari.cambiaCambio(método: UpDown.Up)
ferrari.cambiaCambio(método: UpDown.Up)

ferrari.cambioActual = 5

let lambo = ferrari // copia todos los datos actuales del struct ferrari, a diferencia de las clases, cuando se copia una instancia de clase, se comparte el bloque de datos.

lambo.cambioActual
ferrari.cambioActual = 6
lambo.cambioActual


class Empty { }
let nothing = Empty()


class VehiculoP {
    let esEléctrico: Bool
    init(esEléctrico: Bool) {
        self.esEléctrico = esEléctrico
    }
}

class CarreP: VehiculoP {
    let esConvertible: Bool
    init(esConvertible: Bool, esEléctrico: Bool) {
        self.esConvertible = esConvertible
        super.init(esEléctrico: esEléctrico)
    }
}

class MotoP: VehiculoP {
    let llantas: Int8 = 2
}

let teslaX = CarreP(esConvertible: false, esEléctrico: true)
let Honda = MotoP(esEléctrico: false)


class Food {
    var name: String
    var nutritionRating: Int
    init(name: String, nutritionRating: Int) {
        self.name = name
        self.nutritionRating = nutritionRating
    }
    func copia() -> Food {
        let CO = Food(name: name, nutritionRating: nutritionRating)
        return CO
    }
}

class Pizza: Food {
    init() {
        super.init(name: "Pizza", nutritionRating: 3)
    }
}


let pasta = Pizza()
pasta.name = "ravioli"
pasta.nutritionRating = 5
let spaguetti = pasta.copia()
spaguetti.name = "lasaña"
spaguetti.nutritionRating = 10

pasta.name
spaguetti.name


protocol Comprable {
    var nombre: String { get set }
}

struct Libro: Comprable {
    var nombre: String
    var autor: String
}

struct Pelicula: Comprable {
    var nombre: String
    var actores: [String]
}

struct Automovil: Comprable {
    var nombre: String
    var anio: Int16
}

struct Cafe: Comprable {
    var nombre: String
    var pesoKg: Double
}

func compraLibro(_ libro: Libro) {
    print("Estoy comprando un buen \(libro.nombre)")
}

func comprar(_ articulo: Comprable) {
    print("Estoy comprando un excelente \(articulo.nombre)")
}


class Vivo {
    let id: Int
    init(No: Int) {
        self.id = No
        //print("nació \(id)!")
    }
    deinit {
        //print("elemento \(id) muerto")
    }
}

var arr = [Vivo]()

for i in 1...3 {
    let V = Vivo(No: i)
    arr.append(V)
}

arr.removeAll()

enum ErrorRango: Error {
    case fueraRango
}

protocol Suena {
    var patas: UInt8 { get set }
    func speak()
}

class Animal: Suena {
    private var patasValue: UInt8 // se usa una variable alterna privada
    
    var patas: UInt8 {
        get { return self.patasValue }
        set {
            if newValue > 4 {
                self.patasValue = 4
                print("Taz LOco, esto no es un ciempiés, no le puedo poner \(newValue - self.patasValue) pata(s) de más se queda con \(self.patasValue)")
            } else {
                self.patasValue = newValue
            }
        }
    }
    
    internal func speak() {
        // empty
    }
    
    init(patas: UInt8) {
        self.patasValue = patas
    }
}

class Perro: Animal {
    init() {
        super.init(patas: 4)
    }
    override func speak() {
        print("Guau")
    }
}

class Corgi: Perro {
    override func speak() {
        print("Wow")
    }
}

class Puddle: Perro {
    override func speak() {
        print("Woof")
    }
}

class Gato: Animal {
    var isTame: Bool
    init(isTame: Bool) {
        self.isTame = isTame
        super.init(patas: 4)
    }
}

class Persian: Gato {
    init() {
        super.init(isTame: true)
    }
    override func speak() {
        print("meow")
    }
}

class León: Gato {
    init() {
        super.init(isTame: false)
    }
    override func speak() {
        print("Grooow")
    }
}

/*
 var p = Puddle()
 p.patas = 5
 p.speak()
 p.patas
 
 let L = León()
 L.speak()
 */



protocol VehicPers {
    var nombre: String { get }
    func TiempoEstimado(por distancia: Int) -> Int
    func Recorrido(por distancia: Int)
}

class Carrito: VehicPers {
    internal var nombre: String
    
    init(nombre: String) {
        self.nombre = nombre
    }
    
    internal func Recorrido(por distancia: Int) {
        print("Estamos recorriendo \(distancia) kms")
    }
    
    internal func TiempoEstimado(por distancia: Int) -> Int {
        return distancia / 80
    }
    
    func AbrirTecho() {
        print("tengas un bello día")
    }
}

class LaCicleta: VehicPers {
    internal var nombre: String
    
    init(nombre: String) {
        self.nombre = nombre
    }
    
    internal func Recorrido(por distancia: Int) {
        print("En cicleta he recorrido \(distancia) kms")
    }
    
    internal func TiempoEstimado(por distancia: Int) -> Int {
        return distancia / 20
    }
}

func conmutarVP(distancia: Int, usando vehiculo: VehicPers) {
    if vehiculo.TiempoEstimado(por: distancia) > 100 {
        print("muy lento! cambiaré de vehículo")
    } else {
        vehiculo.Recorrido(por: distancia)
    }
}

func getEstimadosViaje(usando vehiculos: [VehicPers], distancia: Int) {
    for VH in vehiculos {
        let estimado = VH.TiempoEstimado(por: distancia)
        print("\(VH.nombre): \(estimado) horas en \(distancia) kms")
    }
}
/*
 let lambo = Carrito(nombre: "lambo")
 conmutarVP(distancia: 10_000, usando: lambo)
 
 let cicla = LaCicleta(nombre: "Monark")
 conmutarVP(distancia: 300, usando: cicla)
 
 getEstimadosViaje(usando: [lambo, cicla], distancia: 10_300)
 */



protocol ProtocoloEje {
    var describe: String { get }
    mutating func ajuste()
}

enum Enumeralo: Int, ProtocoloEje {
    case D1 = 1, D2
    var describe: String {
        switch self {
        case .D1: return "Para nada"
        case .D2: return "Probablemente"
        }
    }
    mutating func ajuste() {
        var nuevaDescripcion = describe
        nuevaDescripcion += " <<Asustado>> \(describe)"
        self = Enumeralo(desc: self, describe: nuevaDescripcion)
    }
    var nuevaDescripcion: String {
        get { return describe } set { print(newValue) }
    }
    private init(desc: Enumeralo, describe: String) {
        switch desc {
        case .D1: self = .D1
        case .D2: self = .D2
        }
        print(describe)
        nuevaDescripcion = describe + " Petro Chau"
    }
}

var emma: Enumeralo = Enumeralo(rawValue: 1)! // No llama a private init
emma.describe
emma.ajuste()  // aquí llama a private init
emma.describe
emma = .D2
emma.describe
emma.nuevaDescripcion

enum Enumerado: Int, ProtocoloEje {
    case D1 = 1, D2
    
    var describe: String {
        switch self {
        case .D1:
            return "Para nada"
        case .D2:
            return "Probablemente"
        }
    }
    
    mutating func ajuste() {
        //_ = "\(describe) <<Asustado>>"
        self = Enumerado(rawValue: self.rawValue) ?? self
    }
}

var emme: Enumerado = .D2 // Enumerado(rawValue: 2)!
emme.describe
emme.ajuste()
emme.describe
emme = .D1
emme.describe


enum Enumeracion: ProtocoloEje {
    case desc1, desc2
    var describe: String {
        switch self {
        case .desc1:
            return " Para nada"
        case .desc2:
            return " Probablemente"
        }
    }
    mutating internal func ajuste() {
        var nuevadescripcion = describe
        nuevadescripcion += " <<Asustado>> \(self.describe)"
    }
}

var enummi: Enumeracion = .desc1
enummi.describe
enummi = .desc2
enummi.ajuste()
enummi.describe
enummi.hashValue



class SimpleClass: ProtocoloEje {
    // mutating internal
    func ajuste() {
        describe += " ahora 100% ajustada"
    }
    internal var otraProp: Int = 1991
    internal var describe: String = "Una clase básica"
}

let aaa = SimpleClass()
aaa.describe
aaa.ajuste()
let desc1 = aaa.describe

struct Estructura: ProtocoloEje {
    mutating internal func ajuste() {
        describe += " (ajustada)"
    }
    
    internal var describe: String = "Una simple estructura"
}

var bbb = Estructura(describe: "Amigo, ")
bbb.ajuste()
bbb.describe



extension Double: ProtocoloEje {
    mutating internal func ajuste() {
        self *= 3 // no es posible hacer 7.0.ajuste() debido a que los literales no son mutables, es mejor con una variable var doble.ajuste()
    }
    
    internal var describe: String {
        return "Número \(self * 10) x 10 pues era \(self)"
    }
    
    internal var absoluteValue: Double {
        get {
            if self < 0.0 {
                return self * -1
            } else {
                return self}
        }
    }
}

7.0.describe  // "Número 70.0 x 10 pues era 7.0"
var doble = -10.0 // -10
doble.ajuste()  // -30
doble.absoluteValue // 30


var protocolVal: ProtocoloEje = doble // -30
protocolVal.ajuste() // doble = -90
protocolVal.describe // doble = -900





func randomNum() -> Int {
    return Int(arc4random() % 100)
}

func randomNum2() -> Int {
    return Int(drand48() * 100)
}

func randomBool() -> Bool {
    return arc4random_uniform(2) == 0 // ? true : false
}

/*
 func ==<T: Equatable>(lhs: T, rhs: T) -> Bool {
 return lhs == rhs ? true : false
 }
 */

let R = randomNum()
let S = randomNum2()
let T = randomBool()

// print(R == S)

var fraseCeleb = "   La verdad es raramente pura  y nunca simple   "
let cortada = fraseCeleb.trimmingCharacters(in: .whitespacesAndNewlines)

extension String {
    mutating func trim() {
        self = self.trimmed()
    }
    func trimmed() -> String {
        return self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    var lines: [String] {
        return self.components(separatedBy: "  ")
    }
}
str = fraseCeleb
fraseCeleb.trim()
ii = str.trimmed().lines.count


struct LibroX {
    var titulo: String
    var paginas: Int
    var lectura: Int
}

extension LibroX {
    init(titulo: String, paginas: Int) {
        self.titulo = titulo; self.paginas = paginas; self.lectura = paginas / 50
    }
}

let cienAnios = LibroX(titulo: "100 años de Soledad", paginas: 2193, lectura: 50)
let laMaria = LibroX(titulo: "La María de J. Isaacs", paginas: 1900)

cienAnios.lectura
laMaria.lectura


extension Collection {
    var isNotEmpty: Bool {
        return isEmpty != true
    }
}

var invitados = ["Hugo", "Paco", "Luis"]

if invitados.isNotEmpty {
    for N in invitados {
        invitados.append(N)
    }
}


protocol Gentleman {
    var name: String { get }
    func dressWell(kind: String)
}

extension Gentleman {
    func dressWell(kind: String) {
        str = "\(name) dresses \(kind)"
    }
}

struct Empleadote: Gentleman {
    internal var name: String
}

let paco = Empleadote(name: "Paco")
paco.dressWell(kind: "Frac")


// En Swift 3 no existe Numeric como ancestro de Double e Int, la siguiente es la forma más compatible de crear para poder trabajar de forma complementaria entre los dos tipos.
// Actualización: 


protocol Numeric: Equatable {
    var doubleVal: Double { get }
}

extension Int: Numeric {
    internal var doubleVal: Double {
        return Double(self)
    }
}

extension Double: Numeric {
    internal var doubleVal: Double {
        return self
    }
}
/*
 func ==<T: Equatable>(lhs: T, rhs: T) -> Bool {
 return lhs == rhs ? true : false
 }
 */
extension Numeric {
    func cuadrao() -> Double {
        return self.doubleVal * self.doubleVal
    }
}

let cualInt:Int = 10
cualInt.cuadrao()

let cualDbl:Double = 10
cualDbl.cuadrao()

bb = cualInt.doubleVal == cualDbl.doubleVal

/*
 protocol Equatable { // esto es si sólo se usa Equatable
 static func ==(lhs: Self, rhs: Self) -> Bool  // WOW
 }
 */
struct Usuario: Equatable, Comparable { // se puede omitir Equatable, funciona!!!
    var name: String = ""
    
    static func ==(lhs: Usuario, rhs: Usuario) -> Bool {
        return lhs.name == rhs.name
    }
    
    static func <(lhs: Usuario, rhs: Usuario) -> Bool { // Comparable!!!
        return lhs.name < rhs.name
    }
}

let usu1 = Usuario(name: "Pepa")
let usu2 = Usuario(name: "Pepe")

bb = usu1 == usu2
bb = usu1 < usu2


let oddNumbers = [2, 4, 22, 44]


// Tomado del video de Apple 2015

protocol Ordered {
    func precedes(other: Self) -> Bool
}

struct Number: Ordered {
    var value: Double = 0
    func precedes(other: Number) -> Bool {
        return self.value < other.value
    }
}

func binarySearch<T: Ordered>(sortedKeys: [T], forKey K: T) -> Int {
    var lo = 0
    var hi = sortedKeys.count
    while hi > lo {
        let mid = lo + (hi - lo) / 2
        if sortedKeys[mid].precedes(other: K) { lo = mid + 1 }
        else { hi = mid }
    }
    return lo
}




enum ColorB: Int { case rojo = 100, verde, azul }
enum OrienB: Int { case izq = 10, der }
enum ColaB:  Int { case none, burbuja, punta }

let cola = ColaB.none
cola.hashValue

struct Atributos: Hashable {
    var color: ColorB
    var orien: OrienB
    var colaB: ColaB
    var hashValue: Int {
        return color.rawValue + orien.rawValue + colaB.hashValue
    }
    static func == (lhs: Atributos, rhs: Atributos) -> Bool {
        return lhs.colaB == rhs.colaB && lhs.color == rhs.color && lhs.orien == rhs.orien
    }
}
let ATT = Atributos(color: .azul, orien: .der, colaB: .burbuja)
ATT.hashValue

struct Personilla: Hashable {
    var name: String
    var age: Int
    
    var hashValue: Int {
        return name.hashValue ^ age.hashValue
    }
    
    static func ==(lhs: Personilla, rhs: Personilla) -> Bool {
        return lhs.name == rhs.name && lhs.age == rhs.age
    }
}

var personilla = Personilla(name: "Fernando", age: 51)
personilla.hashValue

var cache = [Atributos: UIImage]()

func creaGlobo(_ color: ColorB, orien: OrienB, cola: ColaB) -> UIImage {
    let K = Atributos(color: color, orien: orien, colaB: cola)
    if let imagen = cache[K] {
        return imagen
    }
    return UIImage()
}

extension String {
    var isMimeType: Bool {
        switch self {
        case "plain/text": return true
        case "image/png": return true
        case "image/jpg": return true
        case "image/gif": return true
        default: return false
        }
    }
}

enum MimeType {  // Estructura similar a la de arriba en funcionalidad
    case txt, png, jpg, gif
    init?(rawValue: String) { // sin embargo es más óptimo para procesador enum
        switch rawValue {     // que String, e incluso ahorra memoria
        case "plain/text": self = .txt
        case "image/png": self = .png
        case "image/jpg": self = .jpg
        case "image/gif": self = .gif
        default: return nil
        }
    }
}

struct Attachment {
    var file: URL
    var UUID: UUID
    var mime: String
    var mimeType: MimeType
    init?(file: URL, uuid: UUID, mime: String) {
        print("1 MimeType \(mime)")
        guard mime.isMimeType  // aquí sigue siendo String
            else { return nil } // como puede retornar nil, por guard se coloca ? en init así: init?
        if let mimeType = MimeType(rawValue: mime) { // aquí es mejor que guard
            self.mimeType = mimeType
        } else { return nil }
        print("3 mimeType \(mimeType)")
        self.file = file
        self.UUID = uuid
        self.mime = mime
        // self.mimeType = mimeType
    }
}

let ST = Attachment(file: URL(fileURLWithPath: "/"), uuid: UUID(uuidString: "87654321-1234-0123-1234-123456789012")!, mime: "plain/text")
ST!.UUID
ST?.file
ST?.mime
ST!.mimeType



struct ExistContDrawable {
    var valueBuffer: (uno: Int, dos: Int, tres: Int)
    /*    var vmt: VirtualWitnessTable
     var pmt: DrawableProtocolWitnessTable  */
}

let ECD: ExistContDrawable = ExistContDrawable(valueBuffer: (uno: 1, dos: 2, tres: 3))
ECD.valueBuffer.uno



// GENERICS ********

func repite<ItemType>(item: ItemType, veces: Int) -> [ItemType] {
    var result = [ItemType]()
    for _ in 0...veces {
        result.append(item)
    }
    return result
}

repite(item: "Knock", veces: 10)


enum ValorOpcional<T> {
    case Ninguno
    case Algunos(T)
}

var posibleEntero: ValorOpcional<Int> = .Ninguno
posibleEntero = .Algunos(100)

var posibleCadena: ValorOpcional<String> = .Ninguno
posibleCadena = .Algunos("valores")


func anyCommonElements<T: Sequence, U: Sequence>
    (_ lhs: T, _ rhs: U) -> [T.Iterator.Element] where
    T.Iterator.Element: Equatable,
    T.Iterator.Element == U.Iterator.Element {
        var aux: [T.Iterator.Element] = []
        for lhsItem in lhs {
            for rhsItem in rhs {
                if lhsItem == rhsItem {
                    aux.append(lhsItem)
                }
            }
        }
        return aux
}

anyCommonElements([true, false], [false])
anyCommonElements([9, 2, 3, 4, 5, 6], [3, 2, 8, 4, 9, 6, 1])
anyCommonElements(["alfa", "beta", "gama"], ["alfa", "gama"])
anyCommonElements([true, false], [])

protocol Building {
    var rooms: Int { get }
    var cost: Int { get set }
    var SAName: String { get }
    func salesSummary()
}

struct House: Building {
    var rooms: Int
    var cost: Int
    var SAName: String
    func salesSummary() {
        print("This House has \(rooms) rooms, very cheap: $\(cost), you can contact \(SAName) for more info")
    }
}

struct Office: Building {
    var rooms: Int
    var cost: Int
    var SAName: String
    func salesSummary() {
        print("This Office Building has \(rooms) rooms, very cheap: $\(cost), you can contact \(SAName) for more info")
    }
}

let agent1 = Office(rooms: 10, cost: 40_000, SAName: "Fernando Dager")
let agent2 = House(rooms: 4, cost: 200_000, SAName: "Alejandra Guzmán")






// Nota sobre Optionals, para entender los opcionales los debemos ver como cajas sin abrir ? o abiertas !.  Exclamación ! significa Caja Abierta (Unwrapped) e Interrogación ? significa Caja Cerrada (Wrapped).   En Pascal, un símil podría ser la prevención de usar punteros sin asignar
//      if Assigned(Str) then ...  // Str podría ser nil
// en Swift se entiende que una variable o cualquier tipo de dato puede o no contener un valor inicial.  (Podría entenderse que todo dato es puntero?)
//      var Str: String = "Hola mundo"  // Tiene valor
//      var Str: String = ""            // Vacío
//      var Str: String?  // nil        // No tiene valor o sea nil

//      var II: Int = 40_000    // tiene valor
//      var II: Int = 0         // vacío (0 es un valor)
//      var II: Int?            // no tiene valor o sea nil

//      var Arr: [Double] = [0.0]   // tiene 1 valor, 0.0
//      var Arr: [Double] = []      // vacío  ( var Arr = [Double]() )
//      var Arr: [Double]?          // no tiene valor o sea nil

//      "Swift no introdujo Optionals, introdujo Non-Optionals". @ZevEisenberg

// SoSpEcHo que Swift maneja todo como punteros en Stack, es decir, si se pone
//      var II: Int = 100_000 // se podría entender en pascal así:

//      var II: ^Integer = nil;
//      II^ := 100000;  // ya no es nil y lo abre a fuerza pues da error, debería usarse getmem(II, sizeof(Integer)), al final liberarlo con freemem(II) pero todo esto va en contra de la optimización al usar Stack y no Heap, a no ser que Swift haya hecho el trabajo sucio por debajo de la mesa para el usuario.



func anyCommonElementos<T: Sequence, U: Sequence>(_ lhs: T, _ rhs: U) -> Bool?
    where // T: Sequence, U: Sequence,
    T.Iterator.Element: Equatable,
    T.Iterator.Element == U.Iterator.Element  {
        if ![lhs].isEmpty && ![rhs].isEmpty { return nil }
        for lhsItem in lhs {
            for rhsItem in rhs {
                if lhsItem == rhsItem {
                    return true
                }
            }
        }
        return false
}

anyCommonElementos([true, false], [])


