import Foundation

var str = "Hello, playground"

print("hola mijo")
