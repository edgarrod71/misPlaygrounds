import Foundation
import UIKit
import PlaygroundSupport
// https://gist.github.com/erica/6f13f3043a330359c035e7660f3fe7f5
// Original Video: https://www.youtube.com/watch?v=TTmWUSgNOHk
// Video: https://www.youtube.com/watch?v=hmAB3WJOQTU
// Video: https://www.youtube.com/watch?v=DWtavuvmKdw (with zoom and fade)

/// Cadena para animar y sus atributos
var cadena = "Hola, Fercho!"
let fontSize: CGFloat = 38
let atributos: [String: Any] = [
    NSForegroundColorAttributeName: UIColor.black,
    NSFontAttributeName: UIFont.boldSystemFont(ofSize: fontSize)]
let testo = NSTextStorage(string: cadena, attributes: atributos)
let tamaTesto = testo.size()

/// Creamos una vista sobre la cual animar
var desplazaW: CGFloat = 50
let heightCuenta: CGFloat = 10
let tamVista = CGSize(
    width: tamaTesto.width + 2 * desplazaW, // 50 point padding
    height: tamaTesto.height * heightCuenta) // string height * count = view height
let view = UIView(frame: CGRect(origin:.zero, size: tamVista))
view.backgroundColor = UIColor.black

let destinoY = tamaTesto.height * (heightCuenta - 2) / 2

/// El administrador de diseño provee geometría de glifo
let layoutManager = NSLayoutManager()
layoutManager.addTextContainer(NSTextContainer(size: CGRect.infinite.size))
layoutManager.textStorage = testo
/// podríamos saber la cantidad de glifos mediante testo.length o cadena.count pero es mejor la última
testo.length
cadena.characters.count
let cuentaGlifo = Int(layoutManager.numberOfGlyphs)
/// Trae caracteres individuales con atributos
let arregloCharsConAtributos = (0 ..< cuentaGlifo)
    .map { testo.attributedSubstring(from: NSMakeRange($0, 1)) }

/// Colores agradables entre 35% y 75% de brillo
func randomColor() -> UIColor {
    func random() -> CGFloat {
        return 0.35 + 0.5 * CGFloat(arc4random()) / CGFloat(UInt32.max)
    }
    return UIColor(red: random(), green: random(), blue: random(), alpha: 1)
}

func randomSize() -> CGFloat {
    return fontSize + 10 * CGFloat(arc4random()) / CGFloat(UInt32.max)
}

/// Anima cada caracter en sitio
let formato = UIGraphicsImageRendererFormat()

arregloCharsConAtributos.enumerated().forEach { (idx, char) in

    let theChar: NSMutableAttributedString = char.mutableCopy() as! NSMutableAttributedString
    theChar.addAttribute(NSForegroundColorAttributeName, value: randomColor(), range: NSMakeRange(0, 1)) /// cambia el color
    let fuente = UIFont.systemFont(ofSize: randomSize())
    theChar.addAttribute(NSFontAttributeName, value: fuente, range: NSMakeRange(0, 1))

    let chSize = theChar.size(); defer { desplazaW += chSize.width + 2 }
//    let chSize = char.size(); defer { desplazaW += chSize.width + 2 }

    /// Crea una imagen de caracter
    let renderer = UIGraphicsImageRenderer(size: chSize, format: formato)
    let characterImage = renderer.image { _ in theChar.draw(at: .zero) }

    // Animación de p1 a p2
    let p1 = CGPoint(x: desplazaW, y: tamVista.height + 990)
    let p2 = CGPoint(x: desplazaW, y: destinoY)
    let destination = CGRect(origin: p2, size: chSize)

    // Construye UIImageView
    let charView = UIImageView(frame: CGRect(origin: p1, size: chSize))
    charView.image = characterImage; charView.alpha = 0.0
    view.addSubview(charView)

    // Animar con un retraso de 0.1s entre cada uno, incremente esto para bajar la velocidad de la animación.
    UIView.animate(withDuration: 1.5, // tiempo para el paso de la letra entera
        delay: Double(idx) * 0.1, // letra para demora de la letra
        usingSpringWithDamping: 0.6, // bajando velocidad
        initialSpringVelocity: 0.5, // velocidad inicial
        options: [],
        animations: {
            charView.frame = destination;
            charView.alpha = 1.0 },
        completion: nil)
}

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = view

