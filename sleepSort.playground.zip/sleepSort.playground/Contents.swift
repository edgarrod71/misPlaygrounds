//: Playground - noun: a place where people can play
import UIKit
import PlaygroundSupport

import Foundation
import Dispatch

public struct SleepSort {
    /// Dispatches a block after `secs` seconds
    static func despachar(en segs: Double, bloque: @escaping () -> Void) {
        #if os(Linux)
            let demora = Double(CLOCKS_PER_SEC) * segs
        #else
            let demora = Double(NSEC_PER_SEC) * segs
        #endif
        let dT = DispatchTime(uptimeNanoseconds: DispatchTime.now().rawValue + UInt64(demora))
        if #available(OSX 10.10, *) {
            DispatchQueue
                .global(qos: .default)
                .asyncAfter(deadline:  dT, execute: bloque)
        }
    }

    // Return sleep-sorted integer array
    public static func ordena(_ nums: [Int]) -> [Int] {
        var resultado: [Int] = []
        let maxItem = nums.max() ?? 0
        let semaforo = DispatchSemaphore(value: 0) // Creamos un semáforo de despacho con valor inicial de 0
        let dTime = 0.25
        // definimos la cola
        let accessQueue = DispatchQueue(label: /*"org.sadun.sortIsolation"*/ "colaCualquiera", qos: .default, attributes: [.concurrent], autoreleaseFrequency: .inherit)

        self.despachar(en: Double(maxItem + 1) * dTime) {
            semaforo.signal() // aumenta el contador del semáforo y desbloquea hilos que esperan
        }
        nums.forEach { numero in
            self.despachar(en: Double(numero) * dTime) { /// numero * dTime ordena en sí mismo
                accessQueue.sync(flags: [.barrier]) { // barrier hace que se ejecute el bloque de código de forma síncrona después de que todas las tareas previas en la cola de despacho concurrente se completen, y que ninguna tarea posterior comenzará hasta que el bloque de código de barrera se complete.
                    resultado.append(contentsOf: [numero])
                }
            }
        }
        let _ = semaforo.wait(timeout: DispatchTime.distantFuture) // disminuye el contador del semáforo bloqueando el hilo
        return resultado
    }
}

extension Array { // Scramble array members

    func barajalo() -> [Iterator.Element] {
        var coleccion = self
        let cuantos = coleccion.count
        for offset in 0 ..< (cuantos - 1) {
            #if os(Linux)
                let r = offset + Int(rand() % (numericCast(elementCount - offset)))
            #else
                let r = offset + Int(arc4random_uniform(numericCast(cuantos - offset)))
            #endif
            guard r != offset else { continue }
            swap(&coleccion[offset], &coleccion[r])
        }
        return coleccion
    }
}

let array = Array(1...40).barajalo()
print(array)
print(SleepSort.ordena(array))
