//: Playground - noun: a place where people can play
import CoreGraphics
import Foundation
import UIKit
import GameplayKit
// import PlayGroundSupport

var str = "Hello, playground"


var rutita = UIBezierPath()
for i in 0...180 {
    let teta = CGFloat(i) / CGFloat(M_PI)
    let C = 1.0 + cos(teta)
    let x = 50 * sin(teta) * C
    let y = 50 * cos(teta) * C
    let punto = CGPoint(x: x, y: y)
    if i == 0 {
        rutita.move(to: punto)
    }
    rutita.addLine(to: punto)
}

class BezierCircle {
    var color : UIColor
    var path : UIBezierPath
    var radius : Double
    init (_ radius : Double, _ color : UIColor = .red) {
        path = UIBezierPath(ovalIn: CGRect(x: 0, y: 0, width: 4 * radius, height: 4 * radius))
        self.radius = radius
        self.color = color
    }
    func debugQuickLookObject() -> AnyObject? {
        let tam = CGSize(width: radius * 4.0, height: radius * 4.0)
        UIGraphicsBeginImageContext(tam)
        color.set(); path.fill()
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
}

var circulito: BezierCircle = BezierCircle(10, .blue)
circulito.debugQuickLookObject()


enum QuickLookObject {
    case Text(String)
    case Int(Int64)
    case UInt(UInt64)
    case Float(Double)
    case Image(Any)
    case Sound(Any)
    case Color(Any)
    case BezierPath(Any)
    case AttributedString(Any)
    case Rectangle(Double, Double, Double, Double)
    case Point(Double, Double)
    case Size(Double, Double)
    case Logical(Bool)
    case Range(UInt64, UInt64)
    case View(Any)
    case Sprite(Any)
    case URL(String)
    case _Raw([UInt8], String)
}

var miCGRect = CGRect(x: 0, y: 0, width: 100, height: 200)
let (_, _, w, h) = (miCGRect.origin.x, miCGRect.origin.y, miCGRect.width, miCGRect.height)
w
h

extension CGRect {
    func __conversion() -> (Double, Double, Double, Double) {
            return (Double(self.origin.x), Double(self.origin.y), Double(self.width), Double(self.height))
        }
}

var otherCGRect = CGRect(x: 0, y: 0, width: 100, height: 200)
let (_, _, an, al) = otherCGRect.__conversion()
an
al


struct GeneradorEspirografico {
    var pointOffset, dTheta, dR, radioMenor, radioMayor: Double
    var theta = 0.0
    typealias Element = CGPoint

    init(radioMayor: Double, radioMenor: Double, pointOffset: Double, muestras: Double) {
        self.pointOffset = pointOffset
        self.radioMayor = radioMayor
        self.radioMenor = radioMenor
        self.dR = radioMayor - radioMenor
        self.dTheta = M_PI * 2.0 / muestras
    }
    mutating func siguiente() -> CGPoint? {
        let xT = dR * cos(theta) + pointOffset * cos (dR * dTheta / radioMenor)
        let yT = dR * sin(theta) + pointOffset * sin (dR * dTheta / radioMenor)
        theta = theta + dTheta
        return CGPoint(x: xT, y: yT)
    }
//    func debugQuickLookObject() -> AnyObject? {
//        let tam = CGSize(width: radius * 4.0, height: radius * 4.0)
//        UIGraphicsBeginImageContext(tam)
//        color.set(); path.fill()
//        let image = UIGraphicsGetImageFromCurrentImageContext()
//        UIGraphicsEndImageContext()
//        return image
//    }
}

let espirograf01 = GeneradorEspirografico(radioMayor: 10, radioMenor: 3, pointOffset: 4, muestras: 4)

// TODO: Aprender a graficarlo en Playground


public func TiraDados(muestras: Int) -> [Int] {
    // Construimos una fuente
    let fuente = GKARC4RandomSource()

    // Lanzamos los primeros n > 768 valores
    fuente.dropValues(1024)

    // Construimos una Distribución
    let distribucion = GKGaussianDistribution(randomSource: fuente, lowestValue: 0, highestValue: 100)

    // Accedemos a valores aleatorios
    var cuentas = Array(repeating: 0, count: 101)
    for _ in 1...muestras {
        cuentas[distribucion.nextInt()] += 1
    }
    return cuentas
}

TiraDados(muestras: 1000)


// Erica Sadun


/*
 let crayonDictionary = ["Sepia": NUMERALcolorLiteral(red: 0.6171875, green: 0.35546875, blue: 0.25, alpha: 1.0),
 "Beaver": NUMERALcolorLiteral(red: 0.5703125, green: 0.43359375, blue: 0.35546875, alpha: 1.0),
 "Caribbean Green": NUMERALcolorLiteral(red: 0.0, green: 0.796875, blue: 0.59765625, alpha: 1.0),
 "Electric Lime": NUMERALcolorLiteral(red: 0.796875, green: 0.99609375, blue: 0.0, alpha: 1.0),
 "Gray": NUMERALcolorLiteral(red: 0.54296875, green: 0.5234375, blue: 0.5, alpha: 1.0),
 "Pacific Blue": NUMERALcolorLiteral(red: 0.0, green: 0.61328125, blue: 0.765625, alpha: 1.0),
 "Burnt Sienna": NUMERALcolorLiteral(red: 0.91015625, green: 0.453125, blue: 0.31640625, alpha: 1.0),
 "Manatee": NUMERALcolorLiteral(red: 0.55078125, green: 0.5625, blue: 0.62890625, alpha: 1.0),
 "Screamin' Green": NUMERALcolorLiteral(red: 0.3984375, green: 0.99609375, blue: 0.3984375, alpha: 1.0),
 "Granny Smith Apple": NUMERALcolorLiteral(red: 0.61328125, green: 0.875, blue: 0.57421875, alpha: 1.0),
 "Atomic Tangerine": NUMERALcolorLiteral(red: 0.99609375, green: 0.59765625, blue: 0.3984375, alpha: 1.0),
 "Cotton Candy": NUMERALcolorLiteral(red: 0.99609375, green: 0.71484375, blue: 0.83203125, alpha: 1.0),
 "Razzmatazz": NUMERALcolorLiteral(red: 0.88671875, green: 0.04296875, blue: 0.359375, alpha: 1.0),
 "Tumbleweed": NUMERALcolorLiteral(red: 0.8671875, green: 0.6484375, blue: 0.50390625, alpha: 1.0),
 "Macaroni And Cheese": NUMERALcolorLiteral(red: 0.99609375, green: 0.72265625, blue: 0.48046875, alpha: 1.0),
 "Vivid Tangerine": NUMERALcolorLiteral(red: 0.99609375, green: 0.59765625, blue: 0.5, alpha: 1.0),
 "Cornflower": NUMERALcolorLiteral(red: 0.57421875, green: 0.796875, blue: 0.9140625, alpha: 1.0),
 "Outer Space": NUMERALcolorLiteral(red: 0.17578125, green: 0.21875, blue: 0.2265625, alpha: 1.0),
 "Fern": NUMERALcolorLiteral(red: 0.38671875, green: 0.71484375, blue: 0.421875, alpha: 1.0),
 "Silver": NUMERALcolorLiteral(red: 0.78515625, green: 0.75, blue: 0.73046875, alpha: 1.0),
 "Olive Green": NUMERALcolorLiteral(red: 0.70703125, green: 0.69921875, blue: 0.359375, alpha: 1.0),
 "Mahogany": NUMERALcolorLiteral(red: 0.7890625, green: 0.203125, blue: 0.20703125, alpha: 1.0),
 "Red Violet": NUMERALcolorLiteral(red: 0.73046875, green: 0.19921875, blue: 0.51953125, alpha: 1.0),
 "Purple Heart": NUMERALcolorLiteral(red: 0.39453125, green: 0.17578125, blue: 0.75390625, alpha: 1.0),
 "Cadet Blue": NUMERALcolorLiteral(red: 0.66015625, green: 0.6953125, blue: 0.76171875, alpha: 1.0),
 "Fuchsia": NUMERALcolorLiteral(red: 0.75390625, green: 0.328125, blue: 0.75390625, alpha: 1.0),
 "Blue Green": NUMERALcolorLiteral(red: 0.0, green: 0.58203125, blue: 0.7109375, alpha: 1.0),
 "Maroon": NUMERALcolorLiteral(red: 0.76171875, green: 0.12890625, blue: 0.28125, alpha: 1.0),
 "Timberwolf": NUMERALcolorLiteral(red: 0.84765625, green: 0.8359375, blue: 0.80859375, alpha: 1.0),
 "Yellow Green": NUMERALcolorLiteral(red: 0.76953125, green: 0.87890625, blue: 0.4765625, alpha: 1.0),
 "Magic Mint": NUMERALcolorLiteral(red: 0.6640625, green: 0.9375, blue: 0.81640625, alpha: 1.0),
 "Jazzberry Jam": NUMERALcolorLiteral(red: 0.64453125, green: 0.04296875, blue: 0.3671875, alpha: 1.0),
 "Laser Lemon": NUMERALcolorLiteral(red: 0.99609375, green: 0.99609375, blue: 0.3984375, alpha: 1.0),
 "Gold": NUMERALcolorLiteral(red: 0.8984375, green: 0.7421875, blue: 0.5390625, alpha: 1.0),
 "Blue Violet": NUMERALcolorLiteral(red: 0.390625, green: 0.3359375, blue: 0.71484375, alpha: 1.0),
 "Cranberry": NUMERALcolorLiteral(red: 0.85546875, green: 0.3125, blue: 0.47265625, alpha: 1.0),
 "Neon Carrot": NUMERALcolorLiteral(red: 0.99609375, green: 0.59765625, blue: 0.19921875, alpha: 1.0),
 "Mulberry": NUMERALcolorLiteral(red: 0.76953125, green: 0.29296875, blue: 0.546875, alpha: 1.0),
 "Raw Sienna": NUMERALcolorLiteral(red: 0.8203125, green: 0.48828125, blue: 0.2734375, alpha: 1.0),
 "Orange": NUMERALcolorLiteral(red: 0.99609375, green: 0.40625, blue: 0.12109375, alpha: 1.0),
 "Pine Green": NUMERALcolorLiteral(red: 0.00390625, green: 0.47265625, blue: 0.43359375, alpha: 1.0),
 "Denim": NUMERALcolorLiteral(red: 0.08203125, green: 0.375, blue: 0.73828125, alpha: 1.0),
 "Ultra Red": NUMERALcolorLiteral(red: 0.98828125, green: 0.35546875, blue: 0.46875, alpha: 1.0),
 "Chestnut": NUMERALcolorLiteral(red: 0.72265625, green: 0.3046875, blue: 0.28125, alpha: 1.0),
 "Midnight Blue": NUMERALcolorLiteral(red: 0.0, green: 0.19921875, blue: 0.3984375, alpha: 1.0),
 "Pink Flamingo": NUMERALcolorLiteral(red: 0.99609375, green: 0.3984375, blue: 0.99609375, alpha: 1.0),
 "Shocking Pink": NUMERALcolorLiteral(red: 0.99609375, green: 0.43359375, blue: 0.99609375, alpha: 1.0),
 "Shadow": NUMERALcolorLiteral(red: 0.51171875, green: 0.4375, blue: 0.3125, alpha: 1.0),
 "Sunglow": NUMERALcolorLiteral(red: 0.99609375, green: 0.796875, blue: 0.19921875, alpha: 1.0),
 "Vivid Violet": NUMERALcolorLiteral(red: 0.5, green: 0.21484375, blue: 0.5625, alpha: 1.0),
 "Tan": NUMERALcolorLiteral(red: 0.9765625, green: 0.61328125, blue: 0.3515625, alpha: 1.0),
 "Brick Red": NUMERALcolorLiteral(red: 0.7734375, green: 0.17578125, blue: 0.2578125, alpha: 1.0),
 "Copper": NUMERALcolorLiteral(red: 0.8515625, green: 0.5390625, blue: 0.40234375, alpha: 1.0),
 "Indigo": NUMERALcolorLiteral(red: 0.30859375, green: 0.41015625, blue: 0.7734375, alpha: 1.0),
 "Asparagus": NUMERALcolorLiteral(red: 0.48046875, green: 0.625, blue: 0.35546875, alpha: 1.0),
 "Red": NUMERALcolorLiteral(red: 0.92578125, green: 0.0390625, blue: 0.24609375, alpha: 1.0),
 "Turquoise Blue": NUMERALcolorLiteral(red: 0.421875, green: 0.8515625, blue: 0.90234375, alpha: 1.0),
 "Navy Blue": NUMERALcolorLiteral(red: 0.0, green: 0.3984375, blue: 0.796875, alpha: 1.0),
 "Radical Red": NUMERALcolorLiteral(red: 0.99609375, green: 0.20703125, blue: 0.3671875, alpha: 1.0),
 "Magenta": NUMERALcolorLiteral(red: 0.9609375, green: 0.32421875, blue: 0.6484375, alpha: 1.0),
 "Mango Tango": NUMERALcolorLiteral(red: 0.90234375, green: 0.4453125, blue: 0.0, alpha: 1.0),
 "Wisteria": NUMERALcolorLiteral(red: 0.78515625, green: 0.625, blue: 0.859375, alpha: 1.0),
 "Green Yellow": NUMERALcolorLiteral(red: 0.94140625, green: 0.90234375, blue: 0.53125, alpha: 1.0),
 "Violet (Purple)": NUMERALcolorLiteral(red: 0.51171875, green: 0.34765625, blue: 0.63671875, alpha: 1.0),
 "Blue": NUMERALcolorLiteral(red: 0.0, green: 0.3984375, blue: 0.99609375, alpha: 1.0),
 "Plum": NUMERALcolorLiteral(red: 0.515625, green: 0.19140625, blue: 0.47265625, alpha: 1.0),
 "Tropical Rain Forest": NUMERALcolorLiteral(red: 0.0, green: 0.45703125, blue: 0.3671875, alpha: 1.0),
 "Flesh": NUMERALcolorLiteral(red: 0.99609375, green: 0.79296875, blue: 0.640625, alpha: 1.0),
 "Periwinkle": NUMERALcolorLiteral(red: 0.76171875, green: 0.80078125, blue: 0.8984375, alpha: 1.0),
 "Melon": NUMERALcolorLiteral(red: 0.9921875, green: 0.7265625, blue: 0.67578125, alpha: 1.0),
 "Brink Pink": NUMERALcolorLiteral(red: 0.98046875, green: 0.375, blue: 0.49609375, alpha: 1.0),
 "Inch Worm": NUMERALcolorLiteral(red: 0.6875, green: 0.88671875, blue: 0.07421875, alpha: 1.0),
 "Antique Brass": NUMERALcolorLiteral(red: 0.78125, green: 0.5390625, blue: 0.39453125, alpha: 1.0),
 "Mauvelous": NUMERALcolorLiteral(red: 0.9375, green: 0.56640625, blue: 0.66015625, alpha: 1.0),
 "Robin's Egg Blue": NUMERALcolorLiteral(red: 0.0, green: 0.796875, blue: 0.796875, alpha: 1.0),
 "Yellow Orange": NUMERALcolorLiteral(red: 0.99609375, green: 0.6796875, blue: 0.2578125, alpha: 1.0),
 "Fuzzy Wuzzy Brown": NUMERALcolorLiteral(red: 0.765625, green: 0.3359375, blue: 0.33203125, alpha: 1.0),
 "Sunset Orange": NUMERALcolorLiteral(red: 0.9921875, green: 0.296875, blue: 0.25, alpha: 1.0),
 "Mountain Meadow": NUMERALcolorLiteral(red: 0.1015625, green: 0.69921875, blue: 0.51953125, alpha: 1.0),
 "Desert Sand": NUMERALcolorLiteral(red: 0.92578125, green: 0.78515625, blue: 0.68359375, alpha: 1.0),
 "Tickle Me Pink": NUMERALcolorLiteral(red: 0.984375, green: 0.5, blue: 0.64453125, alpha: 1.0),
 "Canary": NUMERALcolorLiteral(red: 0.99609375, green: 0.99609375, blue: 0.59765625, alpha: 1.0),
 "Happy Ever After": NUMERALcolorLiteral(red: 0.421875, green: 0.8515625, blue: 0.21484375, alpha: 1.0),
 "Scarlet": NUMERALcolorLiteral(red: 0.98828125, green: 0.0546875, blue: 0.20703125, alpha: 1.0),
 "Sea Green": NUMERALcolorLiteral(red: 0.57421875, green: 0.87109375, blue: 0.71875, alpha: 1.0),
 "Dandelion": NUMERALcolorLiteral(red: 0.9921875, green: 0.84375, blue: 0.36328125, alpha: 1.0),
 "Orchid": NUMERALcolorLiteral(red: 0.8828125, green: 0.609375, blue: 0.8203125, alpha: 1.0),
 "Hot Magenta": NUMERALcolorLiteral(red: 0.99609375, green: 0.0, blue: 0.796875, alpha: 1.0),
 "Goldenrod": NUMERALcolorLiteral(red: 0.984375, green: 0.8359375, blue: 0.40234375, alpha: 1.0),
 "Razzle Dazzle Rose": NUMERALcolorLiteral(red: 0.99609375, green: 0.19921875, blue: 0.796875, alpha: 1.0),
 "Brown": NUMERALcolorLiteral(red: 0.68359375, green: 0.34765625, blue: 0.2421875, alpha: 1.0),
 "Forest Green": NUMERALcolorLiteral(red: 0.37109375, green: 0.65234375, blue: 0.46484375, alpha: 1.0),
 "Banana Mania": NUMERALcolorLiteral(red: 0.98046875, green: 0.90234375, blue: 0.6953125, alpha: 1.0),
 "Aquamarine": NUMERALcolorLiteral(red: 0.44140625, green: 0.84765625, blue: 0.8828125, alpha: 1.0),
 "Spring Green": NUMERALcolorLiteral(red: 0.921875, green: 0.91796875, blue: 0.73828125, alpha: 1.0),
 "White": NUMERALcolorLiteral(red: 0.99609375, green: 0.99609375, blue: 0.99609375, alpha: 1.0),
 "Lavender": NUMERALcolorLiteral(red: 0.98046875, green: 0.6796875, blue: 0.8203125, alpha: 1.0),
 "Burnt Orange": NUMERALcolorLiteral(red: 0.99609375, green: 0.4375, blue: 0.203125, alpha: 1.0),
 "Red Orange": NUMERALcolorLiteral(red: 0.99609375, green: 0.24609375, blue: 0.203125, alpha: 1.0),
 "Royal Purple": NUMERALcolorLiteral(red: 0.41796875, green: 0.24609375, blue: 0.625, alpha: 1.0),
 "Jungle Green": NUMERALcolorLiteral(red: 0.16015625, green: 0.66796875, blue: 0.52734375, alpha: 1.0),
 "Almond": NUMERALcolorLiteral(red: 0.9296875, green: 0.84765625, blue: 0.765625, alpha: 1.0),
 "Black": NUMERALcolorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0),
 "Purple Mountain's Majesty": NUMERALcolorLiteral(red: 0.5859375, green: 0.46875, blue: 0.7109375, alpha: 1.0),
 "Wild Blue Yonder": NUMERALcolorLiteral(red: 0.4765625, green: 0.53515625, blue: 0.71875, alpha: 1.0),
 "Violet Red": NUMERALcolorLiteral(red: 0.96484375, green: 0.2734375, blue: 0.5390625, alpha: 1.0),
 "Bittersweet": NUMERALcolorLiteral(red: 0.9921875, green: 0.43359375, blue: 0.3671875, alpha: 1.0),
 "Carnation Pink": NUMERALcolorLiteral(red: 0.99609375, green: 0.6484375, blue: 0.78515625, alpha: 1.0),
 "Sky Blue": NUMERALcolorLiteral(red: 0.4609375, green: 0.83984375, blue: 0.9140625, alpha: 1.0),
 "Outrageous Orange": NUMERALcolorLiteral(red: 0.99609375, green: 0.375, blue: 0.21484375, alpha: 1.0),
 "Green": NUMERALcolorLiteral(red: 0.00390625, green: 0.63671875, blue: 0.40625, alpha: 1.0),
 "Salmon": NUMERALcolorLiteral(red: 0.99609375, green: 0.56640625, blue: 0.640625, alpha: 1.0),
 "Blizzard Blue": NUMERALcolorLiteral(red: 0.63671875, green: 0.88671875, blue: 0.92578125, alpha: 1.0),
 "Wild Strawberry": NUMERALcolorLiteral(red: 0.99609375, green: 0.19921875, blue: 0.59765625, alpha: 1.0),
 "Pig Pink": NUMERALcolorLiteral(red: 0.98828125, green: 0.83984375, blue: 0.890625, alpha: 1.0),
 "Blue Bell": NUMERALcolorLiteral(red: 0.59765625, green: 0.59765625, blue: 0.796875, alpha: 1.0),
 "Cerise": NUMERALcolorLiteral(red: 0.8515625, green: 0.1953125, blue: 0.52734375, alpha: 1.0),
 "Shamrock": NUMERALcolorLiteral(red: 0.19921875, green: 0.796875, blue: 0.59765625, alpha: 1.0),
 "Yellow": NUMERALcolorLiteral(red: 0.98046875, green: 0.90625, blue: 0.4375, alpha: 1.0),
 "Apricot": NUMERALcolorLiteral(red: 0.98828125, green: 0.83203125, blue: 0.69140625, alpha: 1.0),
 "Cerulean": NUMERALcolorLiteral(red: 0.0078125, green: 0.640625, blue: 0.82421875, alpha: 1.0),
 "Eggplant": NUMERALcolorLiteral(red: 0.37890625, green: 0.25, blue: 0.31640625, alpha: 1.0),
 ]
 */

let crayonDictionary = ["Sepia": #colorLiteral(red: 0.6171875, green: 0.35546875, blue: 0.25, alpha: 1.0),
                        "Beaver": #colorLiteral(red: 0.5703125, green: 0.43359375, blue: 0.35546875, alpha: 1.0),
                        "Caribbean Green": #colorLiteral(red: 0.0, green: 0.796875, blue: 0.59765625, alpha: 1.0),
                        "Electric Lime": #colorLiteral(red: 0.796875, green: 0.99609375, blue: 0.0, alpha: 1.0),
                        "Gray": #colorLiteral(red: 0.54296875, green: 0.5234375, blue: 0.5, alpha: 1.0),
                        "Pacific Blue": #colorLiteral(red: 0.0, green: 0.61328125, blue: 0.765625, alpha: 1.0),
                        "Burnt Sienna": #colorLiteral(red: 0.91015625, green: 0.453125, blue: 0.31640625, alpha: 1.0),
                        "Manatee": #colorLiteral(red: 0.55078125, green: 0.5625, blue: 0.62890625, alpha: 1.0),
                        "Screamin' Green": #colorLiteral(red: 0.3984375, green: 0.99609375, blue: 0.3984375, alpha: 1.0),
                        "Granny Smith Apple": #colorLiteral(red: 0.61328125, green: 0.875, blue: 0.57421875, alpha: 1.0),
                        "Atomic Tangerine": #colorLiteral(red: 0.99609375, green: 0.59765625, blue: 0.3984375, alpha: 1.0),
                        "Cotton Candy": #colorLiteral(red: 0.99609375, green: 0.71484375, blue: 0.83203125, alpha: 1.0),
                        "Razzmatazz": #colorLiteral(red: 0.88671875, green: 0.04296875, blue: 0.359375, alpha: 1.0),
                        "Tumbleweed": #colorLiteral(red: 0.8671875, green: 0.6484375, blue: 0.50390625, alpha: 1.0),
                        "Macaroni And Cheese": #colorLiteral(red: 0.99609375, green: 0.72265625, blue: 0.48046875, alpha: 1.0),
                        "Vivid Tangerine": #colorLiteral(red: 0.99609375, green: 0.59765625, blue: 0.5, alpha: 1.0),
                        "Cornflower": #colorLiteral(red: 0.57421875, green: 0.796875, blue: 0.9140625, alpha: 1.0),
                        "Outer Space": #colorLiteral(red: 0.17578125, green: 0.21875, blue: 0.2265625, alpha: 1.0),
                        "Fern": #colorLiteral(red: 0.38671875, green: 0.71484375, blue: 0.421875, alpha: 1.0),
                        "Silver": #colorLiteral(red: 0.78515625, green: 0.75, blue: 0.73046875, alpha: 1.0),
                        "Olive Green": #colorLiteral(red: 0.70703125, green: 0.69921875, blue: 0.359375, alpha: 1.0),
                        "Mahogany": #colorLiteral(red: 0.7890625, green: 0.203125, blue: 0.20703125, alpha: 1.0),
                        "Red Violet": #colorLiteral(red: 0.73046875, green: 0.19921875, blue: 0.51953125, alpha: 1.0),
                        "Purple Heart": #colorLiteral(red: 0.39453125, green: 0.17578125, blue: 0.75390625, alpha: 1.0),
                        "Cadet Blue": #colorLiteral(red: 0.66015625, green: 0.6953125, blue: 0.76171875, alpha: 1.0),
                        "Fuchsia": #colorLiteral(red: 0.75390625, green: 0.328125, blue: 0.75390625, alpha: 1.0),
                        "Blue Green": #colorLiteral(red: 0.0, green: 0.58203125, blue: 0.7109375, alpha: 1.0),
                        "Maroon": #colorLiteral(red: 0.76171875, green: 0.12890625, blue: 0.28125, alpha: 1.0),
                        "Timberwolf": #colorLiteral(red: 0.84765625, green: 0.8359375, blue: 0.80859375, alpha: 1.0),
                        "Yellow Green": #colorLiteral(red: 0.76953125, green: 0.87890625, blue: 0.4765625, alpha: 1.0),
                        "Magic Mint": #colorLiteral(red: 0.6640625, green: 0.9375, blue: 0.81640625, alpha: 1.0),
                        "Jazzberry Jam": #colorLiteral(red: 0.64453125, green: 0.04296875, blue: 0.3671875, alpha: 1.0),
                        "Laser Lemon": #colorLiteral(red: 0.99609375, green: 0.99609375, blue: 0.3984375, alpha: 1.0),
                        "Gold": #colorLiteral(red: 0.8984375, green: 0.7421875, blue: 0.5390625, alpha: 1.0),
                        "Blue Violet": #colorLiteral(red: 0.390625, green: 0.3359375, blue: 0.71484375, alpha: 1.0),
                        "Cranberry": #colorLiteral(red: 0.85546875, green: 0.3125, blue: 0.47265625, alpha: 1.0),
                        "Neon Carrot": #colorLiteral(red: 0.99609375, green: 0.59765625, blue: 0.19921875, alpha: 1.0),
                        "Mulberry": #colorLiteral(red: 0.76953125, green: 0.29296875, blue: 0.546875, alpha: 1.0),
                        "Raw Sienna": #colorLiteral(red: 0.8203125, green: 0.48828125, blue: 0.2734375, alpha: 1.0),
                        "Orange": #colorLiteral(red: 0.99609375, green: 0.40625, blue: 0.12109375, alpha: 1.0),
                        "Pine Green": #colorLiteral(red: 0.00390625, green: 0.47265625, blue: 0.43359375, alpha: 1.0),
                        "Denim": #colorLiteral(red: 0.08203125, green: 0.375, blue: 0.73828125, alpha: 1.0),
                        "Ultra Red": #colorLiteral(red: 0.98828125, green: 0.35546875, blue: 0.46875, alpha: 1.0),
                        "Chestnut": #colorLiteral(red: 0.72265625, green: 0.3046875, blue: 0.28125, alpha: 1.0),
                        "Midnight Blue": #colorLiteral(red: 0.0, green: 0.19921875, blue: 0.3984375, alpha: 1.0),
                        "Pink Flamingo": #colorLiteral(red: 0.99609375, green: 0.3984375, blue: 0.99609375, alpha: 1.0),
                        "Shocking Pink": #colorLiteral(red: 0.99609375, green: 0.43359375, blue: 0.99609375, alpha: 1.0),
                        "Shadow": #colorLiteral(red: 0.51171875, green: 0.4375, blue: 0.3125, alpha: 1.0),
                        "Sunglow": #colorLiteral(red: 0.99609375, green: 0.796875, blue: 0.19921875, alpha: 1.0),
                        "Vivid Violet": #colorLiteral(red: 0.5, green: 0.21484375, blue: 0.5625, alpha: 1.0),
                        "Tan": #colorLiteral(red: 0.9765625, green: 0.61328125, blue: 0.3515625, alpha: 1.0),
                        "Brick Red": #colorLiteral(red: 0.7734375, green: 0.17578125, blue: 0.2578125, alpha: 1.0),
                        "Copper": #colorLiteral(red: 0.8515625, green: 0.5390625, blue: 0.40234375, alpha: 1.0),
                        "Indigo": #colorLiteral(red: 0.30859375, green: 0.41015625, blue: 0.7734375, alpha: 1.0),
                        "Asparagus": #colorLiteral(red: 0.48046875, green: 0.625, blue: 0.35546875, alpha: 1.0),
                        "Red": #colorLiteral(red: 0.92578125, green: 0.0390625, blue: 0.24609375, alpha: 1.0),
                        "Turquoise Blue": #colorLiteral(red: 0.421875, green: 0.8515625, blue: 0.90234375, alpha: 1.0),
                        "Navy Blue": #colorLiteral(red: 0.0, green: 0.3984375, blue: 0.796875, alpha: 1.0),
                        "Radical Red": #colorLiteral(red: 0.99609375, green: 0.20703125, blue: 0.3671875, alpha: 1.0),
                        "Magenta": #colorLiteral(red: 0.9609375, green: 0.32421875, blue: 0.6484375, alpha: 1.0),
                        "Mango Tango": #colorLiteral(red: 0.90234375, green: 0.4453125, blue: 0.0, alpha: 1.0),
                        "Wisteria": #colorLiteral(red: 0.78515625, green: 0.625, blue: 0.859375, alpha: 1.0),
                        "Green Yellow": #colorLiteral(red: 0.94140625, green: 0.90234375, blue: 0.53125, alpha: 1.0),
                        "Violet (Purple)": #colorLiteral(red: 0.51171875, green: 0.34765625, blue: 0.63671875, alpha: 1.0),
                        "Blue": #colorLiteral(red: 0.0, green: 0.3984375, blue: 0.99609375, alpha: 1.0),
                        "Plum": #colorLiteral(red: 0.515625, green: 0.19140625, blue: 0.47265625, alpha: 1.0),
                        "Tropical Rain Forest": #colorLiteral(red: 0.0, green: 0.45703125, blue: 0.3671875, alpha: 1.0),
                        "Flesh": #colorLiteral(red: 0.99609375, green: 0.79296875, blue: 0.640625, alpha: 1.0),
                        "Periwinkle": #colorLiteral(red: 0.76171875, green: 0.80078125, blue: 0.8984375, alpha: 1.0),
                        "Melon": #colorLiteral(red: 0.9921875, green: 0.7265625, blue: 0.67578125, alpha: 1.0),
                        "Brink Pink": #colorLiteral(red: 0.98046875, green: 0.375, blue: 0.49609375, alpha: 1.0),
                        "Inch Worm": #colorLiteral(red: 0.6875, green: 0.88671875, blue: 0.07421875, alpha: 1.0),
                        "Antique Brass": #colorLiteral(red: 0.78125, green: 0.5390625, blue: 0.39453125, alpha: 1.0),
                        "Mauvelous": #colorLiteral(red: 0.9375, green: 0.56640625, blue: 0.66015625, alpha: 1.0),
                        "Robin's Egg Blue": #colorLiteral(red: 0.0, green: 0.796875, blue: 0.796875, alpha: 1.0),
                        "Yellow Orange": #colorLiteral(red: 0.99609375, green: 0.6796875, blue: 0.2578125, alpha: 1.0),
                        "Fuzzy Wuzzy Brown": #colorLiteral(red: 0.765625, green: 0.3359375, blue: 0.33203125, alpha: 1.0),
                        "Sunset Orange": #colorLiteral(red: 0.9921875, green: 0.296875, blue: 0.25, alpha: 1.0),
                        "Mountain Meadow": #colorLiteral(red: 0.1015625, green: 0.69921875, blue: 0.51953125, alpha: 1.0),
                        "Desert Sand": #colorLiteral(red: 0.92578125, green: 0.78515625, blue: 0.68359375, alpha: 1.0),
                        "Tickle Me Pink": #colorLiteral(red: 0.984375, green: 0.5, blue: 0.64453125, alpha: 1.0),
                        "Canary": #colorLiteral(red: 0.99609375, green: 0.99609375, blue: 0.59765625, alpha: 1.0),
                        "Happy Ever After": #colorLiteral(red: 0.421875, green: 0.8515625, blue: 0.21484375, alpha: 1.0),
                        "Scarlet": #colorLiteral(red: 0.98828125, green: 0.0546875, blue: 0.20703125, alpha: 1.0),
                        "Sea Green": #colorLiteral(red: 0.57421875, green: 0.87109375, blue: 0.71875, alpha: 1.0),
                        "Dandelion": #colorLiteral(red: 0.9921875, green: 0.84375, blue: 0.36328125, alpha: 1.0),
                        "Orchid": #colorLiteral(red: 0.8828125, green: 0.609375, blue: 0.8203125, alpha: 1.0),
                        "Hot Magenta": #colorLiteral(red: 0.99609375, green: 0.0, blue: 0.796875, alpha: 1.0),
                        "Goldenrod": #colorLiteral(red: 0.984375, green: 0.8359375, blue: 0.40234375, alpha: 1.0),
                        "Razzle Dazzle Rose": #colorLiteral(red: 0.99609375, green: 0.19921875, blue: 0.796875, alpha: 1.0),
                        "Brown": #colorLiteral(red: 0.68359375, green: 0.34765625, blue: 0.2421875, alpha: 1.0),
                        "Forest Green": #colorLiteral(red: 0.37109375, green: 0.65234375, blue: 0.46484375, alpha: 1.0),
                        "Banana Mania": #colorLiteral(red: 0.98046875, green: 0.90234375, blue: 0.6953125, alpha: 1.0),
                        "Aquamarine": #colorLiteral(red: 0.44140625, green: 0.84765625, blue: 0.8828125, alpha: 1.0),
                        "Spring Green": #colorLiteral(red: 0.921875, green: 0.91796875, blue: 0.73828125, alpha: 1.0),
                        "White": #colorLiteral(red: 0.99609375, green: 0.99609375, blue: 0.99609375, alpha: 1.0),
                        "Lavender": #colorLiteral(red: 0.98046875, green: 0.6796875, blue: 0.8203125, alpha: 1.0),
                        "Burnt Orange": #colorLiteral(red: 0.99609375, green: 0.4375, blue: 0.203125, alpha: 1.0),
                        "Red Orange": #colorLiteral(red: 0.99609375, green: 0.24609375, blue: 0.203125, alpha: 1.0),
                        "Royal Purple": #colorLiteral(red: 0.41796875, green: 0.24609375, blue: 0.625, alpha: 1.0),
                        "Jungle Green": #colorLiteral(red: 0.16015625, green: 0.66796875, blue: 0.52734375, alpha: 1.0),
                        "Almond": #colorLiteral(red: 0.9296875, green: 0.84765625, blue: 0.765625, alpha: 1.0),
                        "Black": #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0),
                        "Purple Mountain's Majesty": #colorLiteral(red: 0.5859375, green: 0.46875, blue: 0.7109375, alpha: 1.0),
                        "Wild Blue Yonder": #colorLiteral(red: 0.4765625, green: 0.53515625, blue: 0.71875, alpha: 1.0),
                        "Violet Red": #colorLiteral(red: 0.96484375, green: 0.2734375, blue: 0.5390625, alpha: 1.0),
                        "Bittersweet": #colorLiteral(red: 0.9921875, green: 0.43359375, blue: 0.3671875, alpha: 1.0),
                        "Carnation Pink": #colorLiteral(red: 0.99609375, green: 0.6484375, blue: 0.78515625, alpha: 1.0),
                        "Sky Blue": #colorLiteral(red: 0.4609375, green: 0.83984375, blue: 0.9140625, alpha: 1.0),
                        "Outrageous Orange": #colorLiteral(red: 0.99609375, green: 0.375, blue: 0.21484375, alpha: 1.0),
                        "Green": #colorLiteral(red: 0.00390625, green: 0.63671875, blue: 0.40625, alpha: 1.0),
                        "Salmon": #colorLiteral(red: 0.99609375, green: 0.56640625, blue: 0.640625, alpha: 1.0),
                        "Blizzard Blue": #colorLiteral(red: 0.63671875, green: 0.88671875, blue: 0.92578125, alpha: 1.0),
                        "Wild Strawberry": #colorLiteral(red: 0.99609375, green: 0.19921875, blue: 0.59765625, alpha: 1.0),
                        "Pig Pink": #colorLiteral(red: 0.98828125, green: 0.83984375, blue: 0.890625, alpha: 1.0),
                        "Blue Bell": #colorLiteral(red: 0.59765625, green: 0.59765625, blue: 0.796875, alpha: 1.0),
                        "Cerise": #colorLiteral(red: 0.8515625, green: 0.1953125, blue: 0.52734375, alpha: 1.0),
                        "Shamrock": #colorLiteral(red: 0.19921875, green: 0.796875, blue: 0.59765625, alpha: 1.0),
                        "Yellow": #colorLiteral(red: 0.98046875, green: 0.90625, blue: 0.4375, alpha: 1.0),
                        "Apricot": #colorLiteral(red: 0.98828125, green: 0.83203125, blue: 0.69140625, alpha: 1.0),
                        "Cerulean": #colorLiteral(red: 0.0078125, green: 0.640625, blue: 0.82421875, alpha: 1.0),
                        "Eggplant": #colorLiteral(red: 0.37890625, green: 0.25, blue: 0.31640625, alpha: 1.0),
]



struct ColorHelper {
    static let shared = ColorHelper()  // Aquí se inicializa internamente

    var model: [String: [String]] = [:]
    var modelKeys: [String] = []

    private init() {
        func setupModel() {
            for (num, (name)) in crayonDictionary.enumerated() {
                //let first = String(name.uppercased()[name.startIndex])
                let nombre = name.key // qué implementación!!! ;)
                let finIdx = nombre.index(nombre.startIndex, offsetBy: 3)
                let substring = name.key[nombre.startIndex..<finIdx]
                let first = String(substring)!.uppercased()
//                model[first] = model[first] ?? [] + [nombre]
                if let firstItem = model[first] {
                    model[first] = firstItem + [nombre]
                } else {
                    model[first] = [nombre]
                    print("\(num). \(first)")
                }
                //model[nombre] = [nombre]
            }
            modelKeys = Array(model.keys).sorted()
        }
        setupModel()
    }

    var sectionCount: Int {
        return model.keys.count
    }

    func keyFor(indexPath: IndexPath) -> String {
        return modelKeys[indexPath.section]
    }

    func nameFor(indexPath: IndexPath) -> String {
        let key = keyFor(indexPath: indexPath)
        let values = model[key] ?? []
        return values[indexPath.row]
    }

    func colorFor(indexPath: IndexPath) -> UIColor {
        let key = keyFor(indexPath: indexPath)
        let items = model[key] ?? []
        let name = items[indexPath.row]
        return crayonDictionary[name]!
    }

    func rowsFor(section: Int) -> Int {
        guard section >= 0, section < model.keys.count else {
            fatalError("Invalid section number")
        }
        let key = modelKeys[section]
        return model[key]?.count ?? 0
    }
}

let colorHelper = ColorHelper.shared
let numSecciones = colorHelper.sectionCount

// IndexPath representa la ruta de un nodo específico en un árbol o colección de arreglo anidado.  Cada índice en un IndexPath representa al índice de un arreglo de hijos de un nodo en el árbol en otro nodo más profundo.
let indexPath = IndexPath(row: 0, section: 96)
let sectionKey = colorHelper.keyFor(indexPath: indexPath)
let colorName = colorHelper.nameFor(indexPath: indexPath)
let color = colorHelper.colorFor(indexPath: indexPath)




// Random Color

extension UIColor {
    static func randomLightColor() -> UIColor {
        let rojo = CGFloat(arc4random_uniform(50) + 50) / 100.0
        let verde = CGFloat(arc4random_uniform(50) + 50) / 100.0
        let azul = CGFloat(arc4random_uniform(50) + 50) / 100.0
        return UIColor(red: rojo,
                       green: verde,
                       blue: azul,
                       alpha: 1.0)
    }
}

let randomColor1 = UIColor.randomLightColor()
let randomColor2 = UIColor.randomLightColor()
let randomColor3 = UIColor.randomLightColor()
let randomColor4 = UIColor.randomLightColor()
let randomColor5 = UIColor.randomLightColor()
let randomColor6 = UIColor.randomLightColor()
let randomColor7 = UIColor.randomLightColor()
let randomColor8 = UIColor.randomLightColor()
let randomColor9 = UIColor.randomLightColor()
let randomColor0 = UIColor.randomLightColor()
let randomColora = UIColor.randomLightColor()
let randomColorb = UIColor.randomLightColor()
let randomColorc = UIColor.randomLightColor()
let randomColord = UIColor.randomLightColor()
let randomColore = UIColor.randomLightColor()
let randomColorf = UIColor.randomLightColor()
let randomColorg = UIColor.randomLightColor()





extension UIView {
    func addSubviewWithFlair(_ view: UIView) {
        self.addSubview(view)
        view.transform = CGAffineTransform(scaleX: 0.0001, y: 0.0001)
        UIView.animate(withDuration: 1.0, delay: 0.0, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.0, options: [], animations: { view.transform = .identity }, completion: nil)
    }

    var hasShadow: Bool {
        get {
            return self.layer.shadowPath != nil
        }
        set(newValue) {
            switch newValue {
            case true: // add shadow
                self.layer.shadowRadius = 4
                self.layer.shadowOffset = CGSize(width: 4, height: 4)
                self.layer.shadowOpacity = 0.5
                self.layer.shadowPath = UIBezierPath(roundedRect: self.bounds, cornerRadius: self.layer.cornerRadius).cgPath
            case false: // remove shadow
                self.layer.shadowRadius = 0
                self.layer.shadowOffset = .zero
                self.layer.shadowOpacity = 0
                self.layer.shadowPath = nil
            }
        }
    }
}


let containerView = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 400))
containerView.backgroundColor = UIColor.randomLightColor()

let subview = UIView(frame: CGRect(x: 50, y: 50, width: 100, height: 300))
subview.backgroundColor = UIColor.randomLightColor()

containerView.addSubviewWithFlair(subview)

containerView.hasShadow = true

let unCirculo = BezierCircle(25)
if let image = unCirculo.debugQuickLookObject() as? UIImage {
    if let imageData = UIImagePNGRepresentation(image) {

//        containerView.provideImageData(imageData.base64EncodedData(), bytesPerRow: imageData.count, origin: (10, 10), size: (100, 100), userInfo: nil)
    }
}


// Agrega containerView a tu vista principal
//self.view.addSubview(containerView)

PlaygroundQuickLook.view(containerView)

// PlaygroundPage.current.liveView = containerView


extension String {

    func toAttributed() -> NSAttributedString { // convierte la cadena en la clase NSAttributedString para poder operar Atributos de Fuente.
//        let attrib = NSAttributedString(string: self)
        return NSAttributedString(string: self)
    }
}

extension NSAttributedString {

    func enImagen(withAlpha alpha: CGFloat = 1.0) -> UIImage {
        return UIGraphicsImageRenderer(size: self.size())
            .image { contexto in
                contexto.cgContext.setAlpha(alpha)
                self.draw(at: .zero)
        }
    }

    func renderToAttachment(withAlpha alpha: CGFloat = 1.0) -> NSAttributedString {
        let imagen = self.enImagen()
        let adjunto: NSTextAttachment = {
            // $0.bounds = CGRect(origin: .zero, size: CGSize(width: imagen.size.width * 2, height: imagen.size.height * 13)) //  imagen.size)
            $0.image = imagen
            return $0
        }(NSTextAttachment())

        return NSAttributedString(attachment: adjunto)
    }
}

let string = NSMutableAttributedString(string: "")
string.append("😀😀😀".toAttributed().renderToAttachment())
string.append("😀😀😀".toAttributed().renderToAttachment(withAlpha: 0.5))
string




/// Ojo que lo siguiente sólo necesita UIKit

/// Alta precedencia
precedencegroup AltaPrecedencia { higherThan: BitwiseShiftPrecedence }

/// Operador de Exponenciación
infix operator **: AltaPrecedencia

extension CGFloat {
    /// Retorna base ^^ exp
    /// parámetro base: el valor base
    /// parámetro exp: la exponenciación
    public static func **(base: CGFloat, expo: CGFloat) -> CGFloat {
        return pow(base, expo)
    }
    public static var pi = Double.pi
    public static var tau = CGFloat(pi * 2)
}

let numExpo: CGFloat
numExpo = 10.2 ** 4
CGFloat.pi
CGFloat.tau

/// representación de segmento de línea de 2 puntos
public struct Segmento {
    public let (p1, p2): (CGPoint, CGPoint)
    public var dx: CGFloat { return p2.x - p1.x }
    public var dy: CGFloat { return p2.y - p1.y }
    public var long: CGFloat { return sqrt(dx ** 2 + dy ** 2) }
}

/// representación de Centro/Radio en círculo
public struct Circulo {
    public let centro: CGPoint
    public let radio: CGFloat

    /// retorna un segmento de línea que representa los dos puntos
    /// de interseccion entre sí mismo y otro círculo
    public func intersecta(con otro: Circulo) -> Segmento? {
        // Mucho más conveniente romper esto en términos convencionales,
        // que los que se usan a través de este método corto
        let (x1, y1, r1) = (self.centro.x, self.centro.y, self.radio)
        let (x2, y2, r2) = (otro.centro.x, otro.centro.y, otro.radio)

        // calcula la distancia entre centro1 y centro 2
        let R = Segmento(p1: self.centro, p2: otro.centro).long

        /// probamos la intersección
        guard abs(r1 - r2) <= R, R <= (r1 + r2)
            else { return nil }

        let (R2, R4) = (R ** 2, R ** 4)
        let dCuads = r1 * r1 - r2 * r2
        let a = dCuads / (2 * R2)
        let c = sqrt(2 * (r1 * r1 + r2 * r2) / R2 - (dCuads * dCuads) / R4 - 1)

        let (fx, fy) = ((x1 + x2) / 2 + a * (x2 - x1), (y1 + y2) / 2 + a * (y2 - y1))
        let (gx, gy) = (c * (y2 - y1) / 2, c * (x1 - x2) / 2)

        return Segmento(p1: CGPoint(x: fx + gx, y: fy + gy),
                        p2: CGPoint(x: fx - gx, y: fy - gy))
    }

    /// Retorna los 2 ángulos que representan la proyección del centro
    /// del círculo a los puntos finales de un segmento de línea.
    /// (Este método no prueba isNaN)

    public func angulos(para segmento: Segmento) -> (primero: CGFloat, segundo: CGFloat) {
        let S1 = Segmento(p1: self.centro, p2: segmento.p1)
        let S2 = Segmento(p1: self.centro, p2: segmento.p2)
        return (atan2(S1.dy, S1.dx), atan2(S2.dy, S2.dx))
    }

    /// Devuelve una ruta de Bezier que se extiende entre dos ángulos.
    public func ruta(desde anguloInicial: CGFloat = 0, hasta anguloFinal: CGFloat = CGFloat.tau, manecillaReloj: Bool = true) -> UIBezierPath {
        return UIBezierPath(arcCenter: centro, radius: radio,
                            startAngle: anguloInicial,
                            endAngle: anguloFinal,
                            clockwise: manecillaReloj)
    }

    /// Error de Intersección (esta forma de manejo de error con Struct es cool)
    public struct ErrorInterseccion: Error {
        let mensaje: String
    }

    /// Retorna la ruta de un Bezier que representa mover de círculo2 desde circulo1
    public static func - (c1: Circulo, c2: Circulo) throws -> UIBezierPath {
        /// probamos la intersección
        guard let segmento = c1.intersecta(con: c2)
            else { throw ErrorInterseccion(mensaje: "\(c1) no intersecta \(c2)") }

        let (A1, A2) = (c1.angulos(para: segmento), c2.angulos(para: segmento))

        let ruta = UIBezierPath()
        ruta.append(c1.ruta(desde: A1.primero, hasta: A1.segundo, manecillaReloj: false))
        ruta.append(c2.ruta(desde: A2.primero, hasta: A2.segundo, manecillaReloj: false))
        ruta.usesEvenOddFillRule = true
        return ruta
    }
}

func probandoCirculos(_ c1: Circulo, _ c2: Circulo) -> UIImage {
    let tam = CGSize(width: 400, height: 400)
    let renderizador = UIGraphicsImageRenderer(size: tam)
    let imagen = renderizador.image { contexto in
        /// reubicamos el centro para el contexto del dibujo
        contexto.cgContext.translateBy(x: tam.width / 2.0, y: tam.height / 2.0)

        /// dibujamos los círculos
        c1.ruta().stroke(); c2.ruta().stroke()

        /// probamos la intersección
        guard let segmento = c1.intersecta(con: c2)
            else { return }

        /// dibujamos los puntos en rojo
        UIColor.red.set()

        let p1 = Circulo(centro: segmento.p1, radio: 1.5)
        p1.ruta().fill()

        let p2 = Circulo(centro: segmento.p2, radio: 3.5)
        p2.ruta().fill()

        /// dibujemos!
        UIColor.blue.set()
        let ruta = try! c1 - c2
        ruta.fill()

        /// dibujamos una versión más pequeña de c2
        UIColor.yellow.set()
        let c3 = Circulo(centro: c2.centro, radio: c2.radio * 0.75)
        c3.ruta().fill()
    }
    return imagen
}

let C1 = Circulo(centro: CGPoint(x: 50, y: 50), radio: 80)
let C2 = Circulo(centro: CGPoint(x: 25, y: 25), radio: 45)
let C3 = Circulo(centro: CGPoint(x: -40, y: 10), radio: 100)

probandoCirculos(C1, C2)
probandoCirculos(C2, C3)


