//: Playground - noun: a place where people can play
import UIKit
import PlaygroundSupport

public enum Result<T> {
    case success(valor: T)
    case failure(error: Error)
}

func fetchDatos(completion: (Result<String>) -> Void) {
    let exito = true

    if exito {
        completion(.success(valor: "Recuperado con éxito"))
    } else {
        let error = NSError(domain: "com.ejemplo", code: 500, userInfo: [NSLocalizedDescriptionKey: "Error al recuperar los datos"])
        completion(.failure(error: error))
    }
}

fetchDatos(completion: { result in
    switch result {
    case .success(let valor):
        Swift.print("Exito: \(valor)")
    case .failure(let error):
        Swift.print("Error: \(error.localizedDescription)")
    }
})

public extension Result {
    public typealias BoxedValue = T

    public func unwrap() -> T? {
        guard case .success(let value) = self
            else { return nil }
        return value
    }
}

/// Ejemplo de uso de la extensión
let resultadoExitoso: Result<String> = .success(valor: "Funcionó")
let resultadoFallido: Result<String> = .failure(error: NSError(domain: "com.example", code: 500, userInfo: [NSLocalizedDescriptionKey: "Error"]))

/// Desenvolvemos el resultado exitoso
if let valorUnwrappedExitoso = resultadoExitoso.unwrap() {
    "Valor Desenvuelto exitoso: \(valorUnwrappedExitoso)"
} else {
    "No se pudo desenvolver el valor"
}

/// Desenvolvemos el resultado fallido
if let valorUnwrappedFallido = resultadoFallido.unwrap() {
    "valor desenvuelto fallido: \(valorUnwrappedFallido)"
} else {
    "No se pudo desenvolver el valor"
}


public enum Either<Left, Right> {
    case left(Left)
    case right(Right)
}

/// Ejemplo de uso
func procesaResultado(resultado: Either<Int, String>) {
    switch resultado {
    case let .left(valInt):
        print("Valor Izquierdo: \(valInt)")
    case .right(let valString):
        print("Valor Derecho: \(valString)")
    }
}

/// Llamado a la función con distintos tipos de resultados
let resultIzq: Either<Int, String> = .left(-10)
var resultDer: Either<Int, String> = .right("Ya vamos llegando")

/// procesamos resultados con los parámetros de arriba
procesaResultado(resultado: resultIzq)
procesaResultado(resultado: resultDer)


extension Either {
    public typealias BoxedValue = Right

    public func unwrap() -> Right? {
        guard case .right(let value) = self
            else { return nil }
        return value
    }
}

resultDer = .right("Buen día Verónica")

let boxedDer: Either<Int, String>.BoxedValue = resultDer.unwrap()!

if let unwrappedVal = String(boxedDer) {  // Cool
    print("valor desenvuelto: \(unwrappedVal)")
}


public enum EitherOr<T> {
    case left(T), right(T)
}

let izqui: EitherOr<Double> = .left(-20.222)
let derek: EitherOr<Bool> = .right(true)


public extension EitherOr {
    public typealias BoxedValue = T
    public func unwrap() -> T? {
        switch self {
        case .left(let value): return value
        case .right(let value): return value
        }
    }
}

if let algunoIz = izqui.unwrap() {
    "valor izq desenv... \(algunoIz)"
} else {
    "No se pudo sacar el valor"
}

let valIzqui: EitherOr<Double>.BoxedValue = izqui.unwrap()!
let valDerek: EitherOr<Bool>.BoxedValue = derek.unwrap()!
let probando: EitherOr<Int>.BoxedValue = Int(izqui.unwrap()!)
let probanda: EitherOr<String>.BoxedValue = String(derek.unwrap()!)


