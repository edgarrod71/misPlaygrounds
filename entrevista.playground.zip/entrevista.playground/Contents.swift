import Foundation

/**
 La tarea es implementar el protocolo Tienda 
    - No se necesita base de datos ni algún otro medio de almacenamiento, sólo guardar datos en memoria
    - Nada de búsquedas inteligentes, use el método String "contains" 
    - Las optimizaciones de desempeño para listProductsByName y listProductsByProducer son opcionales
 */

struct Producto {
    let id: String  // identificador único
    let nombre: String
    let productor: String
}

protocol Tienda {
    /*
     Añada un nuevo objeto product a la tienda (Shop)
     - Parámetro product: producto a añadir a la tienda
     - Retorna: falso si el producto con el mismo id ya existe en tienda, verdadero - en caso contrario.
     */
    func agregarProducto(producto: Producto) -> Bool

    /*
     Borra el producto con el id especificado desde la tienda (Shop).
     - Retorna: verdadero si el producto con el mismo id existía en tienda (Shop), falso - en caso contrario
     */
    func borrarProducto(id: String) -> Bool

    /*
     - Retorna: 10 nombres de producto que contienen la cadena dada.
     Si hay varios productos con el mismo nombre, el nombre del productor se añade al nombre del producto 
     en formato "<producer> - <product>", de otra forma retorne simplemente "<product>".
     */
    func listarProductosPorNombre(buscaCad: String) -> Set<String>

    /*
     - Retorna: 10 nombres de producto cuyo productor contiene la cadena dada, 
     el resultado es ordenado por productores.
     */
    func listarProductosPorProductor(buscaCad: String) -> [String]
}

class ImplementaTienda: Tienda {

    // necesitamos los arreglos y sets que servirán como "tablas"
    var productosPorId: Set<String> = [] // guarda identificadores únicos, actúa como índice
    var productosTodos: [String: Producto] = [String: Producto]()

    func agregarProducto(producto: Producto) -> Bool {
        if productosPorId.contains(producto.id) { // si existe,
            return false         // salga
        } else {      // si no, añada el producto en el set y el diccionario
            productosPorId.insert(producto.id)
            productosTodos[producto.id] = producto
        }
        return true
    }

    func borrarProducto(id: String) -> Bool {
        if !productosPorId.contains(id) {
            return false
        } else {
            productosTodos.removeValue(forKey: id)
            productosPorId.remove(id)
        }
        return true
    }

    func listarProductosPorNombre(buscaCad: String) -> Set<String> {
        var resultado: Set<String> = []   // Me encanta el viejo estilo de etiquetar tipos
        var productosPorNombre: [String: [Producto]] = [:]

        if buscaCad.isEmpty { return resultado }

        for (_, producto) in productosTodos {  // agrupémoslos todos primero dentro del Diccionario productosPorNombre
            let nombre = producto.nombre

            if nombre.contains(buscaCad) {
                if productosPorNombre[nombre] != nil {  // si existe repetido el nombre, añada
                    productosPorNombre[nombre]?.append(producto)
                } else {   // si no, asigne
                    productosPorNombre[nombre] = [producto]
                }
            }
        }

        for (nombre, productos) in productosPorNombre { // construye la lista de productos a partir de productosPorNombre 
            if resultado.count > 9 { break }
            if productos.count == 1 {
                resultado.insert(nombre)
            } else {
                for P in productos {
                    let fNombre = "\(P.productor) - \(P.nombre)"
                    if !resultado.contains(fNombre) {
                        resultado.insert(fNombre)
                    }
                }
            }
        }
        return resultado
    }

    func listarProductosPorProductor(buscaCad: String) -> [String] {
        var resultado: [String] = [String]()
        var productosPorProductor: [String: [Producto]] = [:]

        if buscaCad.isEmpty { return resultado }

        for (_, prod) in productosTodos {  // agrupémoslos primero
            let productor = prod.productor

            if productor.contains(buscaCad) {
                if productosPorProductor[productor] != nil {
                    productosPorProductor[productor]?.append(prod)
                } else {
                    productosPorProductor[productor] = [prod]
                }
            }
        }

        // Ordenar productos por productor
        var productosOrdenados: [[Producto]] = []
        let productoresOrdenados = productosPorProductor.keys.sorted() // ordenamos el arreglo keys del diccionario productosPorProductor
        for productor in productoresOrdenados {
            if let productos = productosPorProductor[productor] {
                productosOrdenados.append(productos.sorted { $0.nombre < $1.nombre })
            }
        }

        for productos in productosOrdenados {
            if resultado.count > 9 { break }

            if productos.count == 1 {
                resultado.append(productos[0].nombre)
            } else {
                for P in productos {
                    let fNombre = "\(P.nombre)"
                    if !resultado.contains(fNombre) {
                        resultado.append(fNombre)
                    }
                }
            }
        }
        return resultado
    }

}

func prueba(clase: Tienda) {
    assert(!clase.borrarProducto(id: "1"))
    assert(clase.agregarProducto(producto: Producto(id: "1", nombre: "1", productor: "Lex")))
    assert(!clase.agregarProducto(producto: Producto(id: "1", nombre: "cualquier nombre, pues estamos checando el id solamente", productor: "any producer")))
    assert(clase.borrarProducto(id: "1"))
    assert(clase.agregarProducto(producto: Producto(id: "3", nombre: "Some Product3", productor: "Some Producer2")))
    assert(clase.agregarProducto(producto: Producto(id: "4", nombre: "Some Product1", productor: "Some Producer3")))
    assert(clase.agregarProducto(producto: Producto(id: "2", nombre: "Some Product2", productor: "Some Producer2")))
    assert(clase.agregarProducto(producto: Producto(id: "1", nombre: "Some Product1", productor: "Some Producer1")))
    assert(clase.agregarProducto(producto: Producto(id: "5", nombre: "Other Product5", productor: "Other Producer4")))
    assert(clase.agregarProducto(producto: Producto(id: "6", nombre: "Other Product6", productor: "Other Producer4")))
    assert(clase.agregarProducto(producto: Producto(id: "7", nombre: "Other Product7", productor: "Other Producer4")))
    assert(clase.agregarProducto(producto: Producto(id: "8", nombre: "Other Product8", productor: "Other Producer4")))
    assert(clase.agregarProducto(producto: Producto(id: "9", nombre: "Other Product9", productor: "Other Producer4")))
    assert(clase.agregarProducto(producto: Producto(id: "10", nombre: "Other Product10", productor: "Other Producer4")))
    assert(clase.agregarProducto(producto: Producto(id: "11", nombre: "Other Product11", productor: "Other Producer4")))

    var byNames: Set<String> = clase.listarProductosPorNombre(buscaCad: "Product")
    assert(byNames.count == 10)

    byNames = clase.listarProductosPorNombre(buscaCad: "Some Product")
    assert(byNames.count == 4)
    assert(byNames.contains("Some Producer3 - Some Product1"))
    assert(byNames.contains("Some Product2"))
    assert(byNames.contains("Some Product3"))
    assert(!byNames.contains("Some Product1"))
    assert(byNames.contains("Some Producer1 - Some Product1"))

    var porProductor: [String] = clase.listarProductosPorProductor(buscaCad: "Producer")
    assert(porProductor.count == 10)

    porProductor = clase.listarProductosPorProductor(buscaCad: "Some Producer")
    assert(porProductor.count == 4)
    assert(porProductor[0] == "Some Product1")
    assert(porProductor[1] == "Some Product2" || porProductor[1] == "Some Product3")
    assert(porProductor[2] == "Some Product2" || porProductor[2] == "Some Product3")
    assert(porProductor[3] == "Some Product1")
}

prueba(clase: ImplementaTienda())
